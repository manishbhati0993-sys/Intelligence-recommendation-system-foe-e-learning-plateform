import React from 'react';
import {
  ShieldAlert,
  Users,
  Building2,
  GraduationCap,
  Briefcase,
  CheckCircle2,
  Activity,
  FileCheck,
  Server
} from 'lucide-react';

export default function AdminPanel() {
  return (
    <div class="max-w-6xl mx-auto py-4 space-y-6">
      
      {/* Header */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div class="flex items-center gap-2">
          <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
            SIH Central Cell Admin
          </span>
          <span class="text-xs text-slate-400">• National Skill Governance</span>
        </div>
        <h1 class="text-2xl sm:text-3xl font-extrabold text-white">
          System Administration & Audit Control
        </h1>
        <p class="text-xs sm:text-sm text-slate-300">
          Manage platform verifications, monitor AI assessment integrity, audit recruiter-college partnerships, and review national student placement conversions.
        </p>
      </div>

      {/* System Stats */}
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div class="text-xs font-bold text-slate-400 uppercase">Registered Students</div>
          <div class="text-2xl font-black text-white mt-2">1,240</div>
          <p class="text-[11px] text-emerald-400 mt-1">98% Verified Portfolios</p>
        </div>

        <div class="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div class="text-xs font-bold text-slate-400 uppercase">Affiliated Colleges</div>
          <div class="text-2xl font-black text-cyan-400 mt-2">42 Universities</div>
          <p class="text-[11px] text-cyan-300 mt-1">NITs, IITs, State Colleges</p>
        </div>

        <div class="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div class="text-xs font-bold text-slate-400 uppercase">Recruiting Companies</div>
          <div class="text-2xl font-black text-amber-400 mt-2">85 Tech Giants</div>
          <p class="text-[11px] text-amber-300 mt-1">210 Active Postings</p>
        </div>

        <div class="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div class="text-xs font-bold text-slate-400 uppercase">AI Engine Status</div>
          <div class="text-2xl font-black text-emerald-400 mt-2">99.98% Uptime</div>
          <p class="text-[11px] text-emerald-300 mt-1">Avg Latency: 120ms</p>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 space-y-4">
        <h3 class="text-base font-bold text-white flex items-center gap-2">
          <Activity class="w-5 h-5 text-cyan-400" /> Platform Security & Activity Audit Log
        </h3>

        <div class="space-y-2 text-xs">
          <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
            <span class="text-slate-300"><strong class="text-cyan-400">Aarav Sharma</strong> completed Java & Backend Skill Assessment (Score: 85%)</span>
            <span class="text-slate-500 text-[10px]">10 mins ago</span>
          </div>
          <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
            <span class="text-slate-300"><strong class="text-emerald-400">Infosys Innovation Labs</strong> scheduled technical interview with candidate CAN-01</span>
            <span class="text-slate-500 text-[10px]">1 hour ago</span>
          </div>
          <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
            <span class="text-slate-300"><strong class="text-purple-400">NIT Karnataka</strong> signed new AI/ML CoE MoU with Wipro Innovation</span>
            <span class="text-slate-500 text-[10px]">3 hours ago</span>
          </div>
        </div>
      </div>

    </div>
  );
}
