import React, { useState } from 'react';
import {
  BrainCircuit,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  TrendingUp,
  Target,
  Zap,
  ShieldCheck,
  Award,
  Users,
  Star,
  Play,
  Flame,
  Lock,
  Mail,
  User,
} from 'lucide-react';
import { coursesData } from '../data/mockData';

export default function LandingPage({ onLoginAsDemo, onLoginCustom }) {
  const [authMode, setAuthMode] = useState('login'); // 'login' or 'signup'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [targetRole, setTargetRole] = useState('AI / Machine Learning Engineer');
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleSubmitAuth = (e) => {
    e.preventDefault();
    if (onLoginCustom) {
      onLoginCustom({
        name: name || 'Learner',
        email: email || 'learner@edupulse.ai',
        targetRole,
      });
    } else {
      onLoginAsDemo();
    }
  };

  const sampleCourse = coursesData.find((c) => c.id === 'c2') || coursesData[1];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-indigo-500 selection:text-white">
      {/* Top Hero Navbar */}
      <nav className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-teal-400 p-0.5 shadow-lg shadow-indigo-600/30">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <BrainCircuit className="w-5 h-5 text-indigo-400" />
              </div>
            </div>
            <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              EduPulse<span className="text-indigo-400">.AI</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setAuthMode('login');
                setShowAuthModal(true);
              }}
              className="text-xs font-semibold text-slate-300 hover:text-white px-3 py-2 rounded-xl transition-colors"
            >
              Log In
            </button>
            <button
              onClick={() => {
                setAuthMode('signup');
                setShowAuthModal(true);
              }}
              className="text-xs font-semibold px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
            >
              Sign Up
            </button>
            <button
              onClick={onLoginAsDemo}
              className="text-xs font-bold px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-1.5 hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Explore Demo</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-16 pb-24 overflow-hidden">
        {/* Glow Ambient Blobs */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[350px] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-[400px] h-[300px] bg-teal-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Headline */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold shadow-inner">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span>Next-Gen Neural Recommendation Engine v4.2</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-100 leading-[1.15]">
                Personalized Learning{' '}
                <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-teal-300 bg-clip-text text-transparent">
                  Powered by AI
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Stop wasting time on generic course catalogs. EduPulse AI maps your existing competencies, spots precise skill gaps, and continuously generates a bespoke roadmap to your target tech career.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={onLoginAsDemo}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 hover:scale-105 active:scale-95 group"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Launch Student Dashboard</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => {
                    setAuthMode('signup');
                    setShowAuthModal(true);
                  }}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold text-sm border border-slate-700/80 transition-all flex items-center justify-center gap-2"
                >
                  <span>Create Free Account</span>
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>250+ Multidimensional Vector Embeddings</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Real-time Skill Gap Closure</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Target Role Alignment</span>
                </div>
              </div>
            </div>

            {/* Right Interactive AI Recommendation Preview Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md">
                {/* Floating AI Match Pill */}
                <div className="absolute -top-4 -left-4 z-20 px-3.5 py-2 rounded-2xl bg-slate-900/95 border border-emerald-500/40 shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs font-bold text-emerald-300 animate-float">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>98% Cosine Vector Match</span>
                </div>

                {/* Floating Skill Gap Pill */}
                <div className="absolute -bottom-4 -right-4 z-20 px-3.5 py-2 rounded-2xl bg-slate-900/95 border border-indigo-500/40 shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs font-bold text-indigo-300 animate-float [animation-delay:2s]">
                  <Target className="w-4 h-4 text-indigo-400" />
                  <span>Closes Deep Learning Gap (+24%)</span>
                </div>

                {/* Card Container */}
                <div className="rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl overflow-hidden p-5 space-y-4 backdrop-blur-xl relative">
                  {/* Top Bar */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                        <BrainCircuit className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-bold text-slate-200">AI Recommendation Engine</span>
                    </div>
                    <span className="text-[11px] font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      Rank #1 Pick
                    </span>
                  </div>

                  {/* Course Image */}
                  <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-800">
                    <img
                      src={sampleCourse.thumbnail}
                      alt={sampleCourse.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    <div className="absolute bottom-2.5 left-2.5 right-2.5 flex justify-between items-center text-[11px] text-slate-200">
                      <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-800 font-semibold">
                        {sampleCourse.category}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-800 font-medium">
                        {sampleCourse.duration}
                      </span>
                    </div>
                  </div>

                  {/* Course Content */}
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        Advanced
                      </span>
                      <div className="flex items-center text-amber-400 text-xs font-semibold">
                        <Star className="w-3 h-3 fill-current mr-0.5" />
                        <span>4.95</span>
                      </div>
                    </div>
                    <h4 className="font-bold text-slate-100 text-sm">{sampleCourse.title}</h4>
                    <p className="text-xs text-indigo-300/90 font-medium mt-1">
                      🎯 Why: Bridges your #1 gap in PyTorch for AI Engineer role
                    </p>
                  </div>

                  {/* Vector Match Breakdown Mini bar */}
                  <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5 text-[11px]">
                    <div className="flex justify-between text-slate-400">
                      <span>Prerequisite Alignment</span>
                      <span className="text-emerald-400 font-mono font-bold">100%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div className="bg-emerald-400 h-full rounded-full" style={{ width: '100%' }} />
                    </div>
                  </div>

                  {/* CTA Button */}
                  <button
                    onClick={onLoginAsDemo}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5"
                  >
                    <span>Test Drive Live Platform</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* KPI Stats Bar */}
      <section className="py-12 border-y border-slate-800/80 bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="p-4">
              <p className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 font-mono">
                98.4%
              </p>
              <p className="text-xs font-semibold text-slate-400 mt-1">AI Recommendation Accuracy</p>
            </div>
            <div className="p-4">
              <p className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-emerald-400 font-mono">
                2.4x
              </p>
              <p className="text-xs font-semibold text-slate-400 mt-1">Faster Skill Gap Mastery</p>
            </div>
            <div className="p-4">
              <p className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400 font-mono">
                45,000+
              </p>
              <p className="text-xs font-semibold text-slate-400 mt-1">Learners Upskilled</p>
            </div>
            <div className="p-4">
              <p className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 font-mono">
                250+
              </p>
              <p className="text-xs font-semibold text-slate-400 mt-1">Competency Vector Benchmarks</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Showcase */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-widest text-indigo-400">
              The Personalized AI Advantage
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-slate-100">
              How EduPulse Replaces One-Size-Fits-All Learning
            </p>
            <p className="text-sm text-slate-400">
              Traditional courses assume everyone starts from zero. EduPulse AI dynamically computes your exact knowledge vectors and suggests the optimal next step.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-indigo-500/40 transition-all hover:shadow-xl hover:shadow-indigo-500/10 group">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 mb-2">Vector Competency Mapping</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Calculates multidimensional skill vectors (Python, Deep Learning, MLOps, SQL) with live radar graph tracking compared against real industry benchmarks.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-teal-500/40 transition-all hover:shadow-xl hover:shadow-teal-500/10 group">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-teal-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 mb-2">Instant Skill Gap Remediation</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Identifies deficits blocking your career transition and recommends bite-sized courses and labs that offer the highest return on study time.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-purple-500/40 transition-all hover:shadow-xl hover:shadow-purple-500/10 group">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 mb-2">Adaptive Learning Roadmaps</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                As you pass quizzes and complete labs, your recommendation feed re-ranks in real-time, unlocking higher tier capstones and certifications.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Auth Modal (Login / Signup) */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setShowAuthModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
            >
              ✕
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 p-0.5 mx-auto mb-3 shadow-lg shadow-indigo-600/30">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <BrainCircuit className="w-6 h-6 text-indigo-400" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-100">
                {authMode === 'login' ? 'Welcome Back to EduPulse' : 'Start Your AI-Powered Journey'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {authMode === 'login'
                  ? 'Sign in to access your personalized recommendation feed'
                  : 'Join 45,000+ engineers building personalized skills'}
              </p>
            </div>

            {/* Quick Demo Test Drive Button */}
            <div className="mb-5">
              <button
                type="button"
                onClick={() => {
                  setShowAuthModal(false);
                  onLoginAsDemo();
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-200" />
                <span>1-Click Test Drive (Demo Profile: Alex Morgan)</span>
              </button>
              <div className="flex items-center gap-3 my-4">
                <div className="h-px bg-slate-800 flex-1" />
                <span className="text-[10px] text-slate-500 font-bold uppercase">Or continue with email</span>
                <div className="h-px bg-slate-800 flex-1" />
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmitAuth} className="space-y-4">
              {authMode === 'signup' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Alex Morgan"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {authMode === 'signup' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Target Career Goal</label>
                  <select
                    value={targetRole}
                    onChange={(e) => setTargetRole(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="AI / Machine Learning Engineer">AI / Machine Learning Engineer</option>
                    <option value="Full Stack Web & AI Systems Engineer">Full Stack Web & AI Systems Engineer</option>
                    <option value="Cloud Platform & MLOps Architect">Cloud Platform & MLOps Architect</option>
                  </select>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all mt-2"
              >
                {authMode === 'login' ? 'Sign In & Load Recommendations' : 'Create Account & Map Skills'}
              </button>
            </form>

            <div className="mt-5 text-center text-xs text-slate-400">
              {authMode === 'login' ? (
                <p>
                  Don't have an account?{' '}
                  <button
                    onClick={() => setAuthMode('signup')}
                    className="text-indigo-400 hover:text-indigo-300 font-bold"
                  >
                    Sign Up Free
                  </button>
                </p>
              ) : (
                <p>
                  Already have an account?{' '}
                  <button
                    onClick={() => setAuthMode('login')}
                    className="text-indigo-400 hover:text-indigo-300 font-bold"
                  >
                    Sign In
                  </button>
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
