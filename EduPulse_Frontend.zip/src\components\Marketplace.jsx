import React, { useState } from 'react';
import {
  Briefcase,
  Search,
  Filter,
  Sparkles,
  MapPin,
  Clock,
  CheckCircle2,
  DollarSign,
  Building2,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  X,
  SlidersHorizontal,
  Info
} from 'lucide-react';

export default function Marketplace({
  internships = [],
  jobs = [],
  onApplyJob,
  activeRole
}) {
  const [activeSubTab, setActiveSubTab] = useState('internships');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState('All');
  const [selectedWorkMode, setSelectedWorkMode] = useState('All');
  const [minMatchThreshold, setMinMatchThreshold] = useState(60);
  const [selectedItemForModal, setSelectedItemForModal] = useState(null);

  const rawList = activeSubTab === 'internships' ? internships : jobs;

  const domains = [
    'All',
    'Backend Engineering',
    'Full Stack',
    'Artificial Intelligence',
    'Healthcare Informatics',
    'Software Development'
  ];

  const workModes = ['All', 'Hybrid', 'Remote', 'On-site'];

  // Match calculator simulation for Aarav's verified skills
  const studentVerifiedSkills = ['Java', 'SQL / PostgreSQL', 'React.js', 'JavaScript (ES6+)', 'Git & GitHub', 'Problem Solving'];

  const filteredList = rawList.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.requiredSkills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesDomain = selectedDomain === 'All' || item.domain === selectedDomain;
    
    const matchesWorkMode = selectedWorkMode === 'All' || item.location.toLowerCase().includes(selectedWorkMode.toLowerCase());

    return matchesSearch && matchesDomain && matchesWorkMode;
  });

  return (
    <div className="max-w-6xl mx-auto py-4 space-y-6">
      
      {/* 1. HEADER & CONTROLS */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/85 border border-slate-800 space-y-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-0.5 text-xs font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                Verified Talent Marketplace
              </span>
              <span className="text-xs text-slate-400">• Multi-Criteria Smart Matching</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-2">
              Internships & Career Openings
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Explore pre-vetted corporate openings matched against your verified skill vector.
            </p>
          </div>

          {/* Sub-tab toggle: Internships vs Jobs */}
          <div className="flex items-center p-1 bg-slate-950 rounded-2xl border border-slate-800 self-start sm:self-auto">
            <button
              onClick={() => setActiveSubTab('internships')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition ${
                activeSubTab === 'internships'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Internships ({internships.length})
            </button>
            <button
              onClick={() => setActiveSubTab('jobs')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition ${
                activeSubTab === 'jobs'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Graduate Jobs ({jobs.length})
            </button>
          </div>
        </div>

        {/* 2. ADVANCED SEARCH & MULTI-FILTER BAR */}
        <div className="space-y-3 pt-2 border-t border-slate-800/80">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            
            {/* Search Input */}
            <div className="md:col-span-6 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by role, company, or tech stack (e.g. Java, Docker, Python)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
              />
            </div>

            {/* Domain Dropdown */}
            <div className="md:col-span-3">
              <select
                value={selectedDomain}
                onChange={(e) => setSelectedDomain(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-semibold text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {domains.map((d, idx) => (
                  <option key={idx} value={d}>Domain: {d}</option>
                ))}
              </select>
            </div>

            {/* Work Mode Dropdown */}
            <div className="md:col-span-3">
              <select
                value={selectedWorkMode}
                onChange={(e) => setSelectedWorkMode(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-semibold text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {workModes.map((m, idx) => (
                  <option key={idx} value={m}>Work Mode: {m}</option>
                ))}
              </select>
            </div>

          </div>

          {/* Quick Filter Tags */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pt-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold text-slate-300">Quick Filters:</span>
              <button
                onClick={() => { setSearchQuery(''); setSelectedDomain('All'); setSelectedWorkMode('All'); }}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 transition"
              >
                Reset Filters
              </button>
              <button
                onClick={() => setSelectedDomain('Backend Engineering')}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-cyan-400 transition"
              >
                Backend
              </button>
              <button
                onClick={() => setSelectedDomain('Artificial Intelligence')}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-purple-400 transition"
              >
                AI / ML
              </button>
              <button
                onClick={() => setSelectedWorkMode('Remote')}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-emerald-400 transition"
              >
                Remote Only
              </button>
            </div>

            <div className="text-slate-400 text-[11px]">
              Showing <strong className="text-white">{filteredList.length}</strong> matching openings
            </div>
          </div>
        </div>

      </div>

      {/* 3. OPPORTUNITIES GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredList.map((item) => {
          // Calculate matching skills vs missing skills
          const matchingSkills = item.requiredSkills.filter(sk =>
            studentVerifiedSkills.some(v => v.toLowerCase().includes(sk.toLowerCase()) || sk.toLowerCase().includes(v.toLowerCase()))
          );
          const missingSkills = item.requiredSkills.filter(sk => !matchingSkills.includes(sk));
          const matchPercent = Math.round((matchingSkills.length / item.requiredSkills.length) * 40 + 55);

          return (
            <div
              key={item.id}
              className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition flex flex-col justify-between space-y-4 group shadow-xl"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.logo}
                      alt={item.company}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700 group-hover:border-cyan-400 transition shadow-md"
                    />
                    <div>
                      <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition">
                        {item.title}
                      </h3>
                      <p className="text-xs text-slate-400 font-medium">
                        {item.company} • <span className="text-slate-300 font-semibold">{item.location}</span>
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 text-xs font-black rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> {matchPercent}% Match
                    </span>
                    <div className="text-[10px] text-slate-400 mt-1">{item.type || 'Internship'}</div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>

                {/* Skill Match Breakdown */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 uppercase font-semibold">
                    <span>Skills Compatibility Analysis:</span>
                    <span className="text-emerald-400 font-bold">{matchingSkills.length} Matched</span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {item.requiredSkills.map((sk, idx) => {
                      const isMatched = matchingSkills.includes(sk);
                      return (
                        <span
                          key={idx}
                          className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-medium flex items-center gap-1 ${
                            isMatched
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
                          }`}
                        >
                          {isMatched ? <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" /> : '✕'}
                          {sk}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Stipend / CTC</div>
                  <div className="text-xs font-black text-white">{item.stipend || item.salary}</div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedItemForModal(item)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 transition"
                  >
                    Details
                  </button>
                  <button
                    onClick={() => onApplyJob(item.id)}
                    className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-1"
                  >
                    1-Click Apply
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* 4. DETAIL MODAL */}
      {selectedItemForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in">
          <div className="p-6 sm:p-8 max-w-2xl w-full rounded-3xl bg-slate-900 border border-cyan-500/40 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={selectedItemForModal.logo}
                  alt={selectedItemForModal.company}
                  className="w-14 h-14 rounded-2xl object-cover border border-slate-700"
                />
                <div>
                  <h3 className="text-xl font-bold text-white">{selectedItemForModal.title}</h3>
                  <p className="text-xs text-cyan-400 font-semibold">{selectedItemForModal.company} • {selectedItemForModal.location}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedItemForModal(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800/80 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Role Description</div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {selectedItemForModal.description}
              </p>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Required Skills & Tech Stack</div>
              <div className="flex flex-wrap gap-2">
                {selectedItemForModal.requiredSkills?.map((sk, idx) => (
                  <span key={idx} className="px-3 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-bold font-mono">
                    {sk}
                  </span>
                ))}
              </div>
            </div>

            {selectedItemForModal.perks && (
              <div className="space-y-2">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Perks, Stipend & PPO Terms</div>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {selectedItemForModal.perks.map((p, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Compensation</div>
                <div className="text-base font-black text-cyan-300">
                  {selectedItemForModal.stipend || selectedItemForModal.salary}
                </div>
              </div>

              <button
                onClick={() => {
                  onApplyJob(selectedItemForModal.id);
                  setSelectedItemForModal(null);
                }}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 hover:opacity-95 text-slate-950 font-black text-xs transition shadow-lg shadow-cyan-500/20 flex items-center gap-1.5"
              >
                Submit Verified 1-Click Application <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
