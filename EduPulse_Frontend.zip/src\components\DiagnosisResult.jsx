import React from 'react';
import { ShieldAlert, CheckCircle, FileText, UserCheck, AlertTriangle, Activity, ArrowRight, Download, Sparkles } from 'lucide-react';

export default function DiagnosisResult({ diagnosisResult, onSelectDoctorTab, onOpenReportModal }) {
  if (!diagnosisResult || !diagnosisResult.primaryDiagnosis) {
    return (
      <div class="glass-panel p-8 text-center space-y-4 border border-slate-800">
        <div class="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mx-auto flex items-center justify-center">
          <Activity class="w-6 h-6" />
        </div>
        <div class="space-y-1 max-w-md mx-auto">
          <h3 class="text-lg font-bold text-white">No Diagnostic Run Executed Yet</h3>
          <p class="text-xs text-slate-400">Select symptoms from the AI Symptom Questionnaire or click an organ on the 3D Anatomical canvas, then click "Execute AI Clinical Diagnosis".</p>
        </div>
      </div>
    );
  }

  const { primaryDiagnosis, differentialDiagnoses = [], recommendedDoctor, analysisId, inputSummary } = diagnosisResult;

  const getUrgencyBadge = (urgency) => {
    switch (urgency) {
      case 'Emergency':
        return <span class="px-3 py-1 text-xs font-black rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse flex items-center gap-1"><AlertTriangle class="w-3.5 h-3.5" /> Emergency SOS Triage</span>;
      case 'High':
        return <span class="px-3 py-1 text-xs font-extrabold rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/40 flex items-center gap-1"><ShieldAlert class="w-3.5 h-3.5" /> High Priority Clinical</span>;
      case 'Moderate':
        return <span class="px-3 py-1 text-xs font-extrabold rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center gap-1"><Activity class="w-3.5 h-3.5" /> Moderate / Routine</span>;
      default:
        return <span class="px-3 py-1 text-xs font-extrabold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1"><CheckCircle class="w-3.5 h-3.5" /> Low Risk / Self-Care</span>;
    }
  };

  return (
    <div class="glass-panel p-6 sm:p-8 space-y-6 border border-cyan-500/30 relative overflow-hidden">
      
      {/* Background Cyber Accent Glow */}
      <div class="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

      {/* Result Header */}
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-[10px] font-mono text-cyan-400 bg-cyan-500/10 rounded border border-cyan-500/20">
              ANALYSIS ID: {analysisId}
            </span>
            <span class="text-xs text-slate-400">PubMed ICD-10 Standard</span>
          </div>
          <h2 class="text-2xl sm:text-3xl font-black text-white mt-1">
            {primaryDiagnosis.name}
          </h2>
        </div>

        <div class="flex items-center gap-3">
          {getUrgencyBadge(primaryDiagnosis.urgency)}
          
          <button
            type="button"
            onClick={onOpenReportModal}
            class="px-4 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bold transition flex items-center gap-2"
          >
            <Download class="w-4 h-4" /> Doctor PDF Report
          </button>
        </div>
      </div>

      {/* Primary Diagnosis Details Grid */}
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Main Diagnosis Summary & Recommendations */}
        <div class="lg:col-span-2 space-y-6">
          
          {/* Confidence Score Bar */}
          <div class="glass-card p-4 space-y-2">
            <div class="flex items-center justify-between text-xs font-bold">
              <span class="text-slate-300 flex items-center gap-1.5">
                <Sparkles class="w-4 h-4 text-cyan-400" /> AI Diagnostic Match Confidence:
              </span>
              <span class="text-cyan-400 font-extrabold text-base">{primaryDiagnosis.confidence}%</span>
            </div>
            <div class="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800 p-0.5">
              <div
                class="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-1000"
                style={{ width: `${primaryDiagnosis.confidence}%` }}
              />
            </div>
            <div class="flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>ICD-10 CODE: <strong class="text-white">{primaryDiagnosis.icd10}</strong></span>
              <span>SPECIALIST: <strong class="text-emerald-400">{primaryDiagnosis.specialist}</strong></span>
            </div>
          </div>

          {/* Clinical Summary */}
          <div class="space-y-2">
            <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400">Clinical Etiology & Summary:</h4>
            <p class="text-sm text-slate-200 leading-relaxed bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              {primaryDiagnosis.summary}
            </p>
          </div>

          {/* Recommendations List */}
          <div class="space-y-3">
            <h4 class="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <CheckCircle class="w-4 h-4" /> Recommended Clinical Protocol & Next Steps:
            </h4>
            <ul class="space-y-2">
              {primaryDiagnosis.recommendations?.map((rec, idx) => (
                <li key={idx} class="text-xs text-slate-300 bg-slate-900/70 p-3 rounded-xl border border-slate-800/80 flex items-start gap-2.5">
                  <span class="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span class="leading-relaxed">{rec}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Pharmacological Safety Notice */}
          <div class="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs leading-relaxed flex items-start gap-2.5">
            <AlertTriangle class="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
            <div>
              <strong class="font-bold text-amber-200">Pharmacological Precaution:</strong> {primaryDiagnosis.medicationNotice}
            </div>
          </div>

        </div>

        {/* Right Col: Differential Diagnoses & Recommended Specialist */}
        <div class="space-y-6">
          
          {/* Differential Diagnoses Card */}
          <div class="glass-card p-4 space-y-3">
            <h4 class="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Activity class="w-4 h-4 text-cyan-400" /> Differential Diagnoses:
            </h4>
            <div class="space-y-2">
              {differentialDiagnoses.map((diff) => (
                <div key={diff.id} class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                  <div class="flex items-center justify-between text-xs">
                    <span class="font-bold text-white">{diff.name}</span>
                    <span class="text-cyan-400 font-mono text-[11px]">{diff.confidence}%</span>
                  </div>
                  <div class="flex items-center justify-between text-[10px] text-slate-400">
                    <span>ICD-10: {diff.icd10}</span>
                    <span class="text-slate-300 font-semibold">{diff.urgency}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Specialist Recommendation Card */}
          {recommendedDoctor && (
            <div class="glass-card p-4 space-y-3 border-cyan-500/40">
              <h4 class="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                <UserCheck class="w-4 h-4" /> Matched Specialist Physician:
              </h4>

              <div class="flex items-center gap-3">
                <img
                  src={recommendedDoctor.avatar}
                  alt={recommendedDoctor.name}
                  class="w-12 h-12 rounded-xl object-cover border border-cyan-500/40"
                />
                <div>
                  <h5 class="text-sm font-extrabold text-white">{recommendedDoctor.name}</h5>
                  <p class="text-xs text-cyan-400 font-medium">{recommendedDoctor.specialty}</p>
                  <p class="text-[10px] text-slate-400">{recommendedDoctor.hospital}</p>
                </div>
              </div>

              <button
                type="button"
                onClick={onSelectDoctorTab}
                class="w-full py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 transition flex items-center justify-center gap-1.5"
              >
                Book Telehealth Consultation <ArrowRight class="w-3.5 h-3.5" />
              </button>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
