import React, { useState } from 'react';
import { USER_ROLES } from '../data/portalData';
import { Briefcase, MapPin, Clock, DollarSign, Sparkles, Filter, CheckCircle2, PlusCircle, ArrowUpRight, Search, Send, User } from 'lucide-react';

export default function InternshipBoard({
  internships = [],
  applications = [],
  activeRole = USER_ROLES.STUDENT,
  onApplyJob,
  onPostJob
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedJobForModal, setSelectedJobForModal] = useState(null);
  const [showPostModal, setShowPostModal] = useState(false);
  const [appliedJobsSet, setAppliedJobsSet] = useState(new Set());

  // Post Job Form State (Industry Role)
  const [newJobForm, setNewJobForm] = useState({
    title: '',
    company: 'Dabur Ayush Research Labs',
    location: 'Ghaziabad, NCR / Hybrid',
    type: 'Internship (6 Months)',
    stipend: '₹22,000 / month',
    domain: 'Phytomedicine R&D',
    skillsRequired: 'Ayurvedic Pharmacognosy, HPLC',
    description: ''
  });

  const domains = ['All', 'Phytomedicine R&D', 'HealthTech & AI', 'Clinical Operations', 'Pharmaceutical Manufacturing', 'IPR & Regulatory Affairs'];

  const filteredInternships = internships.filter((job) => {
    const matchesQuery = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.skillsRequired.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDomain = selectedDomain === 'All' || job.domain === selectedDomain;
    const matchesType = selectedType === 'All' || job.type.toLowerCase().includes(selectedType.toLowerCase());

    return matchesQuery && matchesDomain && matchesType;
  });

  const handleConfirmApply = (jobId) => {
    if (onApplyJob) {
      onApplyJob(jobId);
    }
    setAppliedJobsSet((prev) => new Set(prev).add(jobId));
    setSelectedJobForModal(null);
  };

  const handlePostSubmit = (e) => {
    e.preventDefault();
    if (onPostJob) {
      onPostJob({
        ...newJobForm,
        skillsRequired: newJobForm.skillsRequired.split(',').map(s => s.trim())
      });
    }
    setShowPostModal(false);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Top Hero Banner */}
      <div className="glass-panel p-6 sm:p-8 border border-cyan-500/30 relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" /> Core Feature #3 & #9 • AI Internship Board & Match Engine
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Ayush Industry <span className="gradient-text">Internship & Job Board</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Discover verified industrial internships, apprenticeships, and entry-level research positions. Applications are ranked in real-time by an ML compatibility engine based on your validated skill profile.
          </p>
        </div>

        {activeRole === USER_ROLES.INDUSTRY && (
          <button
            type="button"
            onClick={() => setShowPostModal(true)}
            className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-500 text-slate-950 font-extrabold text-xs hover:opacity-95 transition shadow-lg shadow-emerald-500/20 flex items-center gap-2 shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Post New Internship</span>
          </button>
        )}
      </div>

      {/* Application Tracker Pipeline (If student has active applications) */}
      {applications.length > 0 && activeRole === USER_ROLES.STUDENT && (
        <div className="glass-panel p-6 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Active Application Tracker Pipeline</span>
            </h3>
            <span className="text-xs text-slate-400">{applications.length} Submitted Applications</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {applications.map((app) => (
              <div key={app.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-xs font-bold text-white">{app.jobTitle}</h4>
                    <p className="text-[11px] text-cyan-400 font-semibold">{app.company}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                    {app.matchScore}% Match
                  </span>
                </div>

                {/* Pipeline Step Progress */}
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                    <span>Status: {app.status}</span>
                    <span>Applied: {app.appliedDate}</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden flex gap-0.5">
                    <div className={`h-full flex-1 ${app.statusStep >= 1 ? 'bg-cyan-400' : 'bg-slate-700'}`} />
                    <div className={`h-full flex-1 ${app.statusStep >= 2 ? 'bg-cyan-400' : 'bg-slate-700'}`} />
                    <div className={`h-full flex-1 ${app.statusStep >= 3 ? 'bg-emerald-400' : 'bg-slate-700'}`} />
                    <div className={`h-full flex-1 ${app.statusStep >= 4 ? 'bg-emerald-400' : 'bg-slate-700'}`} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter & Search Controls */}
      <div className="glass-panel p-4 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Search input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search titles, skills, companies..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Domain Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
          {domains.map((dom) => (
            <button
              key={dom}
              onClick={() => setSelectedDomain(dom)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                selectedDomain === dom
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {dom}
            </button>
          ))}
        </div>

      </div>

      {/* Internship Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredInternships.map((job) => {
          const isApplied = appliedJobsSet.has(job.id);
          return (
            <div
              key={job.id}
              className="glass-panel p-6 border border-slate-800 hover:border-cyan-500/40 transition-all space-y-4 relative group flex flex-col justify-between"
            >
              <div className="space-y-3">
                
                {/* Header Info */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={job.logo}
                      alt={job.company}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-800 shadow-md"
                    />
                    <div>
                      <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition">
                        {job.title}
                      </h3>
                      <p className="text-xs font-semibold text-cyan-400">{job.company}</p>
                    </div>
                  </div>

                  {/* ML Match Compatibility Badge */}
                  <div className="px-3 py-1 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-center shrink-0">
                    <span className="text-[10px] text-slate-400 block uppercase font-bold">ML Match</span>
                    <span className="text-sm font-black text-cyan-400">{job.matchScore}%</span>
                  </div>
                </div>

                {/* Job Metadata Tags */}
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 font-medium pt-1">
                  <span className="flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                    {job.location}
                  </span>
                  <span className="flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    <Clock className="w-3.5 h-3.5 text-emerald-400" />
                    {job.type}
                  </span>
                  <span className="flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 text-emerald-400 font-bold">
                    <DollarSign className="w-3.5 h-3.5" />
                    {job.stipend}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                  {job.description}
                </p>

                {/* Required Skill Tags */}
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Required Skills:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {job.skillsRequired.map((sk, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-900 text-slate-300 border border-slate-800"
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Bottom Card Footer */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
                <div className="text-[11px] text-slate-400">
                  <span>🎯 {job.spotsAvailable} Openings</span> • <span>👥 {job.applicantsCount} Applicants</span>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedJobForModal(job)}
                  disabled={isApplied}
                  className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                    isApplied
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20'
                  }`}
                >
                  {isApplied ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Applied
                    </>
                  ) : (
                    <>
                      <span>Apply Now</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* ================= 1-CLICK APPLICATION MODAL ================= */}
      {selectedJobForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="max-w-lg w-full glass-panel p-6 sm:p-8 border border-cyan-500/40 rounded-2xl shadow-2xl space-y-5 relative">
            
            <div className="flex items-start justify-between">
              <div>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Direct Application
                </span>
                <h3 className="text-xl font-bold text-white mt-1">{selectedJobForModal.title}</h3>
                <p className="text-xs font-semibold text-cyan-400">{selectedJobForModal.company}</p>
              </div>
              <button
                onClick={() => setSelectedJobForModal(null)}
                className="text-slate-400 hover:text-white text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 bg-slate-900/80 p-4 rounded-xl border border-slate-800 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Applicant:</span>
                <span className="font-bold text-white">Aarav Sharma (B.Pharm Ayurveda)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Attached Resume:</span>
                <span className="font-bold text-cyan-400">Aarav_Sharma_Ayush_Verified.pdf</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">ML Compatibility Score:</span>
                <span className="font-bold text-emerald-400">{selectedJobForModal.matchScore}% Match</span>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={() => setSelectedJobForModal(null)}
                className="w-1/2 py-2.5 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleConfirmApply(selectedJobForModal.id)}
                className="w-1/2 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Confirm Application</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ================= RECRUITER POST JOB MODAL ================= */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="max-w-xl w-full glass-panel p-6 sm:p-8 border border-cyan-500/40 rounded-2xl shadow-2xl space-y-5 relative">
            
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xl font-bold text-white">Post New Industry Internship / Job</h3>
                <p className="text-xs text-slate-400">Publish open positions to matched Ayush student candidates</p>
              </div>
              <button onClick={() => setShowPostModal(false)} className="text-slate-400 hover:text-white font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handlePostSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Position Title</label>
                <input
                  type="text"
                  required
                  value={newJobForm.title}
                  onChange={(e) => setNewJobForm({ ...newJobForm, title: e.target.value })}
                  placeholder="e.g. Phytochemistry R&D Intern"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Domain</label>
                  <select
                    value={newJobForm.domain}
                    onChange={(e) => setNewJobForm({ ...newJobForm, domain: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
                  >
                    {domains.filter(d => d !== 'All').map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Stipend / Package</label>
                  <input
                    type="text"
                    value={newJobForm.stipend}
                    onChange={(e) => setNewJobForm({ ...newJobForm, stipend: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Required Skills (Comma separated)</label>
                <input
                  type="text"
                  value={newJobForm.skillsRequired}
                  onChange={(e) => setNewJobForm({ ...newJobForm, skillsRequired: e.target.value })}
                  placeholder="HPLC, Pharmacognosy, GMP"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Job Description & Responsibilities</label>
                <textarea
                  rows={3}
                  value={newJobForm.description}
                  onChange={(e) => setNewJobForm({ ...newJobForm, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-xs font-bold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-xs"
                >
                  Publish Posting
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
