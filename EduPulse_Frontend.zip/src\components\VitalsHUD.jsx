import React, { useEffect, useRef } from 'react';
import { HeartPulse, Thermometer, ShieldAlert, Activity, Sliders, Zap } from 'lucide-react';

export default function VitalsHUD({ vitals, onUpdateVitals }) {
  const canvasRef = useRef(null);

  // Animated Real-Time ECG Waveform Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let x = 0;
    const points = [];
    const maxPoints = 200;

    const renderECG = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerY = height / 2;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.2)';
      ctx.fillRect(0, 0, width, height);

      // Grid Lines
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
      ctx.lineWidth = 1;
      for (let i = 0; i < width; i += 20) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
      }

      // Generate ECG Spike mathematically based on Heart Rate
      let y = centerY;
      const pulseSpeed = (vitals.heartRate / 60) * 0.05;
      const step = (x * 0.15) % (Math.PI * 2);

      if (step > 1.8 && step < 2.0) {
        y = centerY - 25; // P wave
      } else if (step > 2.8 && step < 3.0) {
        y = centerY + 15; // Q wave
      } else if (step > 3.0 && step < 3.3) {
        y = centerY - 65; // R spike peak
      } else if (step > 3.3 && step < 3.5) {
        y = centerY + 30; // S wave
      } else if (step > 4.2 && step < 4.6) {
        y = centerY - 20; // T wave
      } else {
        y = centerY + (Math.random() - 0.5) * 3; // Baseline noise
      }

      points.push({ x, y });
      if (points.length > maxPoints) {
        points.shift();
      }

      // Draw Waveform Glow Line
      ctx.beginPath();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 10;

      for (let i = 0; i < points.length - 1; i++) {
        const pt1 = points[i];
        const pt2 = points[i + 1];
        ctx.moveTo(pt1.x, pt1.y);
        ctx.lineTo(pt2.x, pt2.y);
      }
      ctx.stroke();

      x = (x + 3) % width;
      animationFrameId = requestAnimationFrame(renderECG);
    };

    renderECG();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [vitals.heartRate]);

  const getRiskAssessment = () => {
    if (vitals.spo2 < 92 || vitals.bpSystolic > 160 || vitals.heartRate > 120) {
      return { level: 'High Risk / Severe', color: 'text-rose-400 border-rose-500/30 bg-rose-500/10' };
    }
    if (vitals.spo2 < 95 || vitals.bpSystolic > 135 || vitals.temp > 100.4) {
      return { level: 'Elevated / Guarded', color: 'text-amber-400 border-amber-500/30 bg-amber-500/10' };
    }
    return { level: 'Normal Sinus Rhythm', color: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10' };
  };

  const risk = getRiskAssessment();

  return (
    <div class="glass-panel p-5 space-y-4 relative overflow-hidden border border-slate-800">
      
      {/* Vitals Header */}
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2.5">
          <div class="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <HeartPulse class="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 class="text-base font-extrabold text-white">Live Patient Vitals Telemetry</h3>
            <p class="text-xs text-slate-400">Continuous 12-lead ECG telemetry & hemodynamic monitoring</p>
          </div>
        </div>

        <span class={`px-3 py-1 text-xs font-bold rounded-full border ${risk.color}`}>
          {risk.level}
        </span>
      </div>

      {/* ECG Canvas Waveform */}
      <div class="relative w-full h-24 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-inner flex items-center justify-center">
        <canvas ref={canvasRef} width={650} height={96} class="w-full h-full" />
        <div class="absolute top-2 left-3 flex items-center gap-2">
          <span class="pulse-dot"></span>
          <span class="text-[10px] font-mono text-cyan-400 tracking-wider">ECG LEAD II - 25mm/s</span>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        
        {/* Heart Rate */}
        <div class="glass-card p-3 space-y-1">
          <div class="flex items-center justify-between text-slate-400">
            <span class="text-xs font-medium">Heart Rate</span>
            <Activity class="w-4 h-4 text-rose-400" />
          </div>
          <div class="flex items-baseline gap-1">
            <span class="text-2xl font-black text-white">{vitals.heartRate}</span>
            <span class="text-xs text-slate-400 font-bold">BPM</span>
          </div>
          <input
            type="range"
            min="50"
            max="160"
            value={vitals.heartRate}
            onChange={(e) => onUpdateVitals({ ...vitals, heartRate: parseInt(e.target.value) })}
            class="w-full accent-rose-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

        {/* Oxygen SpO2 */}
        <div class="glass-card p-3 space-y-1">
          <div class="flex items-center justify-between text-slate-400">
            <span class="text-xs font-medium">Blood Oxygen</span>
            <Zap class="w-4 h-4 text-cyan-400" />
          </div>
          <div class="flex items-baseline gap-1">
            <span class="text-2xl font-black text-white">{vitals.spo2}%</span>
            <span class="text-xs text-slate-400 font-bold">SpO2</span>
          </div>
          <input
            type="range"
            min="85"
            max="100"
            value={vitals.spo2}
            onChange={(e) => onUpdateVitals({ ...vitals, spo2: parseInt(e.target.value) })}
            class="w-full accent-cyan-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

        {/* Blood Pressure */}
        <div class="glass-card p-3 space-y-1">
          <div class="flex items-center justify-between text-slate-400">
            <span class="text-xs font-medium">Blood Pressure</span>
            <ShieldAlert class="w-4 h-4 text-amber-400" />
          </div>
          <div class="flex items-baseline gap-1">
            <span class="text-xl font-black text-white">{vitals.bpSystolic}/{vitals.bpDiastolic}</span>
            <span class="text-[10px] text-slate-400 font-bold">mmHg</span>
          </div>
          <input
            type="range"
            min="90"
            max="180"
            value={vitals.bpSystolic}
            onChange={(e) => onUpdateVitals({ ...vitals, bpSystolic: parseInt(e.target.value) })}
            class="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

        {/* Body Temperature */}
        <div class="glass-card p-3 space-y-1">
          <div class="flex items-center justify-between text-slate-400">
            <span class="text-xs font-medium">Body Temp</span>
            <Thermometer class="w-4 h-4 text-emerald-400" />
          </div>
          <div class="flex items-baseline gap-1">
            <span class="text-2xl font-black text-white">{vitals.temp}°F</span>
          </div>
          <input
            type="range"
            min="96.0"
            max="104.0"
            step="0.2"
            value={vitals.temp}
            onChange={(e) => onUpdateVitals({ ...vitals, temp: parseFloat(e.target.value) })}
            class="w-full accent-emerald-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

      </div>

    </div>
  );
}
