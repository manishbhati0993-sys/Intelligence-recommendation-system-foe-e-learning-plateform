import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  Star,
  Clock,
  Sparkles,
  ArrowRight,
  Bookmark,
  Layers,
} from 'lucide-react';
import CourseCard from '../components/CourseCard';
import EmptyState from '../components/EmptyState';
import { coursesData } from '../data/mockData';

export default function CourseCatalogPage({
  user,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');

  const categories = [
    'All',
    'AI & Machine Learning',
    'MLOps & Cloud Infrastructure',
    'Full Stack Web Development',
    'Data Engineering & Big Data',
    'Cybersecurity & Secure AI',
    'UI/UX & AI-Assisted Design',
    'Mobile App Development',
  ];

  const levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  let filteredCourses = coursesData.filter((course) => {
    const matchesSearch =
      searchQuery.trim() === '' ||
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory =
      selectedCategory === 'All' || course.category === selectedCategory;

    const matchesLevel = selectedLevel === 'All' || course.level === selectedLevel;

    return matchesSearch && matchesCategory && matchesLevel;
  });

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        <div className="relative z-10 space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-bold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Curated Curriculum</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
            Complete Course Catalog
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Browse all verified courses taught by staff engineers and researchers across AI, Cloud, Systems, and Full Stack.
          </p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search all courses by title, topic, or keyword..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
            >
              <option value="All">Level: All Levels</option>
              {levels.filter((l) => l !== 'All').map((l) => (
                <option key={l} value={l}>Level: {l}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Category chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full text-xs no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 font-bold'
                  : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.length > 0 ? (
          filteredCourses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              onSelectCourse={onSelectCourse}
              onToggleBookmark={onToggleBookmark}
              onEnroll={onEnroll}
              isBookmarked={user.bookmarkedCourseIds?.includes(course.id)}
              isEnrolled={user.enrolledCourses?.some((enc) => enc.courseId === course.id)}
              enrolledProgress={
                user.enrolledCourses?.find((enc) => enc.courseId === course.id)?.progress || 0
              }
              showAiMatch={false}
            />
          ))
        ) : (
          <EmptyState
            title="No Courses Found"
            description="No courses matched your current filter criteria."
            onReset={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setSelectedLevel('All');
            }}
          />
        )}
      </div>
    </div>
  );
}
