import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  User,
  HelpCircle,
  ArrowRight,
  RotateCcw,
  Zap
} from 'lucide-react';

export default function AIChatbot({ currentUser, setActiveTab }) {
  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      text: `Hello ${currentUser?.name || 'Aarav'}! I am your **AI Career & Placement Assistant**. I have analyzed your assessment scores (Java: 85%, SQL: 80%) and current target role (**Backend Developer**). How can I assist your career journey today?`,
      actionSuggestions: [
        'How to crack Spring Boot interviews?',
        'What are my biggest skill gaps?',
        'Recommend best internships for my profile',
        'Review my resume for ATS optimization'
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatBottomRef = useRef(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend) => {
    const query = (textToSend || inputValue).trim();
    if (!query) return;

    // Add user message
    const newMsgList = [...messages, { sender: 'user', text: query }];
    setMessages(newMsgList);
    setInputValue('');
    setIsTyping(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          context: {
            studentName: currentUser?.name,
            targetRole: currentUser?.targetRole,
            skills: currentUser?.skills
          }
        })
      });
      const data = await res.json();
      if (data.success) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: data.reply,
            actionSuggestions: data.actionSuggestions || []
          }
        ]);
      }
    } catch (err) {
      console.error('Error fetching chat response:', err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div class="max-w-4xl mx-auto py-4 space-y-6">
      
      {/* Header Banner */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div class="flex items-center gap-3">
          <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20">
            <div class="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Bot class="w-6 h-6 text-cyan-400" />
            </div>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h1 class="text-xl sm:text-2xl font-extrabold text-white">AI Career Assistant & Mentor</h1>
              <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Online v4.2
              </span>
            </div>
            <p class="text-xs text-slate-400">Personalized career guidance, resume suggestions, and technical interview preparation</p>
          </div>
        </div>
      </div>

      {/* Chat Messages Container */}
      <div class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col h-[520px] justify-between">
        
        {/* Messages Scroll Area */}
        <div class="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              class={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div class={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                msg.sender === 'user' ? 'bg-cyan-500 text-slate-950 font-bold text-xs' : 'bg-slate-800 text-cyan-400 border border-slate-700'
              }`}>
                {msg.sender === 'user' ? <User class="w-4 h-4" /> : <Bot class="w-4 h-4" />}
              </div>

              <div class={`max-w-xl space-y-3 ${msg.sender === 'user' ? 'text-right' : ''}`}>
                <div class={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-cyan-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-950/80 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}>
                  {msg.text}
                </div>

                {/* Quick Action Suggestions from AI */}
                {msg.actionSuggestions && msg.actionSuggestions.length > 0 && (
                  <div class="flex flex-wrap gap-1.5 pt-1">
                    {msg.actionSuggestions.map((sug, sIdx) => (
                      <button
                        key={sIdx}
                        onClick={() => handleSendMessage(sug)}
                        class="px-3 py-1 rounded-full bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-[11px] font-semibold text-cyan-300 transition"
                      >
                        {sug}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div class="flex items-center gap-2 text-xs text-cyan-400 font-medium italic">
              <Bot class="w-4 h-4 animate-bounce" /> AI Assistant is evaluating career data...
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Input Bar */}
        <div class="pt-4 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            class="flex gap-2"
          >
            <input
              type="text"
              placeholder="Ask anything about skill gaps, resume tips, or interview questions..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              class="flex-1 px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              class="px-5 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
            >
              <Send class="w-4 h-4" /> Send
            </button>
          </form>
        </div>

      </div>

    </div>
  );
}
