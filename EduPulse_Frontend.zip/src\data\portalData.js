/**
 * Academia–Industry Collaboration Portal (SIH Project Dataset)
 * Comprehensive Data Dictionary & Knowledge Base for Students, Colleges, and Industry Recruiters
 */

export const USER_ROLES = {
  STUDENT: 'student',
  INDUSTRY: 'industry',
  COLLEGE: 'college',
  ADMIN: 'admin'
};

export const MOCK_USERS = {
  student: {
    id: 'USR-STU-101',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@nitte.edu.in',
    role: USER_ROLES.STUDENT,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    college: 'National Institute of Technology Karnataka (NITK)',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech - 7th Semester',
    cgpa: 8.74,
    graduationYear: 2027,
    location: 'Bangalore, Karnataka',
    targetRole: 'Full Stack / Backend Engineer',
    bio: 'Passionate computer science undergrad specializing in distributed backend systems, REST APIs, and Cloud architectures. Looking for high-impact internship opportunities.',
    resumeUrl: 'Aarav_Sharma_Resume_Verified.pdf',
    skills: [
      { name: 'Java', level: 85, category: 'Backend', verified: true },
      { name: 'SQL / PostgreSQL', level: 80, category: 'Database', verified: true },
      { name: 'HTML5 / CSS3', level: 90, category: 'Frontend', verified: true },
      { name: 'JavaScript (ES6+)', level: 82, category: 'Frontend', verified: true },
      { name: 'React.js', level: 75, category: 'Frontend', verified: true },
      { name: 'Git & GitHub', level: 78, category: 'DevOps', verified: true },
      { name: 'Spring Boot', level: 45, category: 'Backend', verified: false },
      { name: 'RESTful APIs', level: 60, category: 'Backend', verified: false },
      { name: 'Docker & Microservices', level: 35, category: 'DevOps', verified: false },
      { name: 'Problem Solving', level: 88, category: 'Soft Skill', verified: true },
      { name: 'Team Collaboration', level: 85, category: 'Soft Skill', verified: true }
    ],
    projects: [
      {
        id: 'PRJ-1',
        title: 'Distributed Task Queue Engine',
        description: 'Built an asynchronous task scheduling worker pool in Java and Redis handling 5,000 requests/sec with retry mechanisms.',
        techStack: ['Java', 'Redis', 'PostgreSQL', 'Docker'],
        github: 'https://github.com/aarav/task-engine',
        demo: 'https://task-engine.demo.io'
      },
      {
        id: 'PRJ-2',
        title: 'Smart Health Diagnostics Portal',
        description: 'Developed an interactive medical diagnosis web platform with dynamic symptom evaluation and vitals monitoring HUD.',
        techStack: ['React', 'Tailwind CSS', 'Node.js', 'Express'],
        github: 'https://github.com/aarav/medipulse-ai',
        demo: 'https://medipulse.demo.io'
      }
    ],
    certifications: [
      {
        id: 'CERT-1',
        title: 'Oracle Certified Professional: Java SE 11 Developer',
        issuer: 'Oracle University',
        date: 'June 2025',
        credentialId: 'OCP-889212'
      },
      {
        id: 'CERT-2',
        title: 'PostgreSQL Advanced Query Optimization',
        issuer: 'Coursera & Stanford Online',
        date: 'March 2026',
        credentialId: 'COUR-STAN-443'
      }
    ]
  },

  industry: {
    id: 'USR-IND-201',
    name: 'Priya Nambiar',
    title: 'Head of University Relations & Technical Talent',
    company: 'Infosys Innovation Labs',
    role: USER_ROLES.INDUSTRY,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    email: 'priya.nambiar@infosys.com',
    location: 'Electronic City, Bangalore',
    companyLogo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=150&q=80',
    industrySector: 'Enterprise Software & Cloud AI',
    activeListingsCount: 8,
    totalApplicants: 142,
    shortlistedCount: 28
  },

  college: {
    id: 'USR-COL-301',
    name: 'Dr. Ramesh Sundaram',
    title: 'Dean of Academic Partnerships & TPO Head',
    college: 'National Institute of Technology Karnataka (NITK)',
    role: USER_ROLES.COLLEGE,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    email: 'tpo.dean@nitk.edu.in',
    department: 'Training & Placement Office',
    totalStudents: 1240,
    placedStudents: 980,
    activeMoUs: 14,
    avgPackageLPA: 12.8
  },

  admin: {
    id: 'USR-ADM-001',
    name: 'Super Admin (SIH Central Cell)',
    role: USER_ROLES.ADMIN,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    email: 'admin@skillbridge.gov.in',
    title: 'National Skill Development & SIH Coordinator'
  }
};

export const TARGET_ROLE_BENCHMARKS = [
  {
    role: 'Backend Developer / Java Specialist',
    domain: 'Software Engineering',
    avgSalary: '₹8.5 - ₹16 LPA',
    requiredSkills: [
      { name: 'Java', priority: 'High', minLevel: 80 },
      { name: 'Spring Boot', priority: 'High', minLevel: 75 },
      { name: 'SQL / PostgreSQL', priority: 'High', minLevel: 75 },
      { name: 'RESTful APIs', priority: 'High', minLevel: 80 },
      { name: 'Git & GitHub', priority: 'Medium', minLevel: 70 },
      { name: 'Docker & Microservices', priority: 'Medium', minLevel: 65 }
    ]
  },
  {
    role: 'Full Stack Web Developer (MERN / Next.js)',
    domain: 'Web & Cloud',
    avgSalary: '₹7.5 - ₹15 LPA',
    requiredSkills: [
      { name: 'React.js', priority: 'High', minLevel: 80 },
      { name: 'Node.js', priority: 'High', minLevel: 75 },
      { name: 'TypeScript', priority: 'High', minLevel: 70 },
      { name: 'MongoDB / SQL', priority: 'Medium', minLevel: 70 },
      { name: 'Tailwind CSS', priority: 'Medium', minLevel: 75 },
      { name: 'RESTful APIs', priority: 'High', minLevel: 80 }
    ]
  },
  {
    role: 'AI / Machine Learning Engineer',
    domain: 'Artificial Intelligence',
    avgSalary: '₹10 - ₹22 LPA',
    requiredSkills: [
      { name: 'Python', priority: 'High', minLevel: 85 },
      { name: 'PyTorch / TensorFlow', priority: 'High', minLevel: 75 },
      { name: 'Data Structures & Algorithms', priority: 'High', minLevel: 80 },
      { name: 'LLM Prompting / LangChain', priority: 'Medium', minLevel: 70 },
      { name: 'Docker & Cloud Deployment', priority: 'Medium', minLevel: 65 }
    ]
  },
  {
    role: 'Ayush HealthTech Product Engineer',
    domain: 'Healthcare Informatics',
    avgSalary: '₹8 - ₹18 LPA',
    requiredSkills: [
      { name: 'Healthcare Data Standards (FHIR / HL7)', priority: 'High', minLevel: 75 },
      { name: 'Python / Java', priority: 'High', minLevel: 80 },
      { name: 'Bioinformatics Algorithms', priority: 'Medium', minLevel: 70 },
      { name: 'Cloud Security & HIPAA Compliance', priority: 'High', minLevel: 75 }
    ]
  }
];

export const SKILL_BENCHMARKS = [
  { name: 'Java', category: 'Backend', avgIndustryDemand: 88, studentAvg: 72, growthRate: '+14% YoY' },
  { name: 'Spring Boot', category: 'Backend', avgIndustryDemand: 85, studentAvg: 48, growthRate: '+26% YoY' },
  { name: 'SQL / PostgreSQL', category: 'Database', avgIndustryDemand: 82, studentAvg: 70, growthRate: '+10% YoY' },
  { name: 'RESTful APIs', category: 'Backend', avgIndustryDemand: 90, studentAvg: 58, growthRate: '+18% YoY' },
  { name: 'React.js', category: 'Frontend', avgIndustryDemand: 86, studentAvg: 74, growthRate: '+22% YoY' },
  { name: 'Docker & Microservices', category: 'DevOps', avgIndustryDemand: 80, studentAvg: 38, growthRate: '+34% YoY' },
  { name: 'Cloud Architecture (AWS / GCP)', category: 'Cloud', avgIndustryDemand: 84, studentAvg: 42, growthRate: '+28% YoY' },
  { name: 'Python & AI Engineering', category: 'AI/ML', avgIndustryDemand: 92, studentAvg: 62, growthRate: '+45% YoY' }
];

export const ASSESSMENT_QUESTIONS = [
  {
    id: 'Q1',
    category: 'Backend & System Design',
    skillTested: 'Java',
    difficulty: 'Intermediate',
    question: 'Which garbage collector in Java 17+ is optimized for multi-gigabyte heaps with pause times strictly under 10ms?',
    options: [
      'Serial Garbage Collector',
      'Z Garbage Collector (ZGC)',
      'Parallel Mark-Sweep',
      'CMS (Concurrent Mark Sweep)'
    ],
    correctOption: 1,
    weight: 20
  },
  {
    id: 'Q2',
    category: 'Backend & System Design',
    skillTested: 'RESTful APIs',
    difficulty: 'Intermediate',
    question: 'Which HTTP method is required by REST specifications to be idempotent for complete resource replacement?',
    options: [
      'POST',
      'PUT',
      'PATCH',
      'CONNECT'
    ],
    correctOption: 1,
    weight: 20
  },
  {
    id: 'Q3',
    category: 'Databases & Query Optimization',
    skillTested: 'SQL / PostgreSQL',
    difficulty: 'Advanced',
    question: 'When optimizing a high-read PostgreSQL table with multi-column queries, which index type is most suitable for range lookups on multiple attributes?',
    options: [
      'B-Tree Composite Index',
      'Hash Index',
      'GiST Geometric Index',
      'GIN Full-Text Index'
    ],
    correctOption: 0,
    weight: 20
  },
  {
    id: 'Q4',
    category: 'Frameworks & Microservices',
    skillTested: 'Spring Boot',
    difficulty: 'Intermediate',
    question: 'In Spring Boot, which annotation is used to declare a centralized exception handler across all REST controllers?',
    options: [
      '@ExceptionHandler',
      '@ControllerAdvice / @RestControllerAdvice',
      '@ServiceAdvice',
      '@GlobalErrorHandler'
    ],
    correctOption: 1,
    weight: 20
  },
  {
    id: 'Q5',
    category: 'DevOps & Version Control',
    skillTested: 'Git & GitHub',
    difficulty: 'Basic',
    question: 'What is the primary difference between `git rebase` and `git merge` when integrating feature branches?',
    options: [
      'Rebase creates a new merge commit while merge squashes commits',
      'Rebase rewrites commit history linearly, while merge preserves commit history and creates a merge commit',
      'Merge deletes the source branch automatically',
      'Rebase only works with detached HEADs'
    ],
    correctOption: 1,
    weight: 20
  }
];

export const INTERNSHIPS = [
  {
    id: 'INT-2026-01',
    title: 'Cloud Backend & Microservices Engineering Intern',
    company: 'Infosys Innovation Labs',
    logo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=150&q=80',
    location: 'Bangalore / Hybrid',
    type: 'Internship (6 Months)',
    stipend: '₹35,000 / month',
    domain: 'Backend Engineering',
    postedDate: '2 days ago',
    deadline: '15 Sept 2026',
    vacancies: 6,
    requiredSkills: ['Java', 'Spring Boot', 'SQL / PostgreSQL', 'RESTful APIs', 'Git & GitHub'],
    minCgpa: 7.5,
    description: 'Work alongside our Cloud Core Architecture group building microservice pipelines, resilience circuits, and API gateways for Tier-1 financial and health clients.',
    perks: ['Pre-Placement Offer (PPO) Eligibility', 'Cloud Certification Sponsorship', 'Flexible Hybrid Work']
  },
  {
    id: 'INT-2026-02',
    title: 'Full Stack Web & AI Systems Intern',
    company: 'TCS Research & Innovation',
    logo: 'https://images.unsplash.com/photo-1554469384-e58fac16e23a?auto=format&fit=crop&w=150&q=80',
    location: 'Hyderabad / On-site',
    type: 'Internship (4 Months)',
    stipend: '₹30,000 / month',
    domain: 'Full Stack',
    postedDate: '3 days ago',
    deadline: '20 Sept 2026',
    vacancies: 4,
    requiredSkills: ['React.js', 'Node.js', 'RESTful APIs', 'SQL / PostgreSQL', 'JavaScript (ES6+)'],
    minCgpa: 7.0,
    description: 'Develop next-gen interactive web dashboards and connect frontends with Python AI inferencing backend APIs for smart institutional systems.',
    perks: ['Industry Mentorship', 'Letter of Recommendation', 'Access to High-Performance Compute']
  },
  {
    id: 'INT-2026-03',
    title: 'AI / ML Computer Vision Intern',
    company: 'Wipro AI Centre of Excellence',
    logo: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=150&q=80',
    location: 'Pune / Remote',
    type: 'Internship (6 Months)',
    stipend: '₹40,000 / month',
    domain: 'Artificial Intelligence',
    postedDate: 'Just now',
    deadline: '30 Sept 2026',
    vacancies: 3,
    requiredSkills: ['Python', 'PyTorch / TensorFlow', 'Data Structures & Algorithms', 'Docker & Microservices'],
    minCgpa: 8.0,
    description: 'Train and deploy deep learning segmentation models for medical imaging, X-ray classification, and edge telemetry.',
    perks: ['Co-authorship on Patents/Papers', 'Top PPO Package (₹14 LPA)', 'Direct GPU Cluster Access']
  },
  {
    id: 'INT-2026-04',
    title: 'Ayush Health Informatics Intern',
    company: 'AyuBridge Medical Tech',
    logo: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=150&q=80',
    location: 'New Delhi / Hybrid',
    type: 'Internship (3 Months)',
    stipend: '₹28,000 / month',
    domain: 'Healthcare Informatics',
    postedDate: '5 days ago',
    deadline: '18 Sept 2026',
    vacancies: 5,
    requiredSkills: ['Java', 'SQL / PostgreSQL', 'RESTful APIs', 'HTML5 / CSS3'],
    minCgpa: 7.0,
    description: 'Digitizing traditional health pharmacopoeia datasets with standardized FHIR schemas and creating diagnostic assistant tools.',
    perks: ['Govt SIH Innovation Recognition', 'Flexible Hours', 'Full Placement Conversion']
  }
];

export const JOBS = [
  {
    id: 'JOB-2026-101',
    title: 'Associate Backend Software Engineer',
    company: 'Infosys Limited',
    logo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=150&q=80',
    location: 'Bangalore / Pune / Hyderabad',
    salary: '₹9.2 - ₹14.5 LPA',
    experience: 'Fresher / 0-1 Years',
    domain: 'Software Development',
    requiredSkills: ['Java', 'Spring Boot', 'SQL / PostgreSQL', 'RESTful APIs', 'Git & GitHub', 'Docker & Microservices'],
    vacancies: 18,
    postedDate: '1 week ago',
    description: 'We are hiring graduate engineers to build scalable Java Spring Boot backend services powering mission-critical cloud enterprise systems.'
  },
  {
    id: 'JOB-2026-102',
    title: 'Graduate Full Stack Developer',
    company: 'Persistent Systems',
    logo: 'https://images.unsplash.com/photo-1554469384-e58fac16e23a?auto=format&fit=crop&w=150&q=80',
    location: 'Pune / Goa / Bangalore',
    salary: '₹8.0 - ₹12.0 LPA',
    experience: 'Fresher / 0-1 Years',
    domain: 'Full Stack',
    requiredSkills: ['React.js', 'Node.js', 'JavaScript (ES6+)', 'SQL / PostgreSQL', 'RESTful APIs'],
    vacancies: 12,
    postedDate: '4 days ago',
    description: 'Design modern web applications and scalable API layers for global healthcare and industrial IoT clients.'
  }
];

export const MOCK_APPLICATIONS = [
  {
    id: 'APP-901',
    opportunityId: 'INT-2026-01',
    title: 'Cloud Backend & Microservices Engineering Intern',
    company: 'Infosys Innovation Labs',
    appliedDate: '24 Aug 2026',
    status: 'Interview Scheduled',
    statusStep: 4, // 1: Applied, 2: Under Review, 3: Shortlisted, 4: Interview, 5: Selected
    matchScore: 82,
    interviewDate: '04 Sept 2026, 03:00 PM IST',
    interviewMode: 'Google Meet (Technical Round 1)',
    feedback: 'Resume shortlisted based on high Java & SQL scores. Candidate recommended to review Spring Boot & Docker concepts.'
  },
  {
    id: 'APP-902',
    opportunityId: 'INT-2026-02',
    title: 'Full Stack Web & AI Systems Intern',
    company: 'TCS Research & Innovation',
    appliedDate: '26 Aug 2026',
    status: 'Shortlisted',
    statusStep: 3,
    matchScore: 88,
    interviewDate: 'Pending Schedule',
    interviewMode: 'Virtual',
    feedback: 'Profile passed initial screening. Technical panel reviewing GitHub repositories.'
  },
  {
    id: 'APP-903',
    opportunityId: 'INT-2026-04',
    title: 'Ayush Health Informatics Intern',
    company: 'AyuBridge Medical Tech',
    appliedDate: '20 Aug 2026',
    status: 'Under Review',
    statusStep: 2,
    matchScore: 92,
    interviewDate: 'TBD',
    interviewMode: 'In-person / Hybrid',
    feedback: 'Application received and routed to the lead informatics engineer.'
  }
];

export const AI_RECOMMENDED_ROADMAP = {
  targetRole: 'Backend Developer / Java Specialist',
  overallMatch: 78,
  estimatedTimeToBridge: '6 - 8 Weeks',
  summary: 'Your core foundation in Java (85%) and SQL (80%) is exceptionally strong. To qualify for top-tier Tier-1 backend roles with >90% match, you need to acquire hands-on proficiency in Spring Boot, RESTful API design, and Docker microservices.',
  milestones: [
    {
      step: 1,
      skill: 'Advanced RESTful API Design & Best Practices',
      status: 'In Progress',
      gapSeverity: 'Moderate',
      estimatedHours: '12 Hours',
      description: 'Master OpenAPI specs, HTTP status codes, idempotent PUT vs PATCH, rate limiting, and JWT token authentication.',
      courses: [
        { name: 'Mastering RESTful API Architecture with Java', provider: 'Coursera / Duke', duration: '6 hrs', rating: 4.8 },
        { name: 'API Security & OAuth2 Fundamentals', provider: 'Udemy / Spring Academy', duration: '4 hrs', rating: 4.9 }
      ],
      project: 'Build an API Rate Limiter & JWT Auth Gateway'
    },
    {
      step: 2,
      skill: 'Spring Boot 3.x & Spring Data JPA',
      status: 'Upcoming',
      gapSeverity: 'High Gap',
      estimatedHours: '20 Hours',
      description: 'Build enterprise microservices with Spring Boot 3, Dependency Injection, Hibernate entity mapping, and automated JUnit 5 tests.',
      courses: [
        { name: 'Spring Boot 3 & Spring Cloud Microservices Masterclass', provider: 'Spring Academy', duration: '14 hrs', rating: 4.9 },
        { name: 'Testing Spring Boot APIs with Mockito & Testcontainers', provider: 'Baeldung Pro', duration: '6 hrs', rating: 4.8 }
      ],
      project: 'E-Commerce Order Management Microservice'
    },
    {
      step: 3,
      skill: 'Dockerization & Containerized Microservices',
      status: 'Upcoming',
      gapSeverity: 'High Gap',
      estimatedHours: '14 Hours',
      description: 'Learn multi-stage Dockerfiles, Docker Compose service orchestration, healthchecks, and environment configuration.',
      courses: [
        { name: 'Docker & Kubernetes for Java Developers', provider: 'edX / Linux Foundation', duration: '10 hrs', rating: 4.7 }
      ],
      project: 'Deploy Microservices Stack with PostgreSQL on Docker Compose'
    }
  ]
};

export const COLLEGE_DEPARTMENT_ANALYTICS = [
  { department: 'Computer Science & Engg', totalStudents: 420, avgSkillScore: 78, topGap: 'Docker & Cloud Native', placementRate: '86%' },
  { department: 'Information Science & Tech', totalStudents: 310, avgSkillScore: 75, topGap: 'Spring Boot & Microservices', placementRate: '82%' },
  { department: 'AI & Data Science', totalStudents: 240, avgSkillScore: 82, topGap: 'MLOps & Model Deployment', placementRate: '88%' },
  { department: 'Electronics & Communication', totalStudents: 270, avgSkillScore: 71, topGap: 'Embedded Systems & Python', placementRate: '76%' }
];

export const INDUSTRY_MOUS = [
  {
    id: 'MOU-1',
    company: 'Infosys Limited',
    type: 'Industry CoE & Co-designed Curriculum',
    signedDate: 'Jan 2025',
    status: 'Active',
    internshipsCommitted: 45,
    studentsPlaced: 38,
    facultyTrained: 12
  },
  {
    id: 'MOU-2',
    company: 'TCS Research',
    type: 'Joint R&D Lab & Student Hackathons',
    signedDate: 'Aug 2025',
    status: 'Active',
    internshipsCommitted: 30,
    studentsPlaced: 24,
    facultyTrained: 8
  },
  {
    id: 'MOU-3',
    company: 'Wipro Innovation CoE',
    type: 'AI / ML Talent Incubation',
    signedDate: 'March 2026',
    status: 'Active',
    internshipsCommitted: 25,
    studentsPlaced: 19,
    facultyTrained: 15
  }
];

export const NOTIFICATIONS = [
  {
    id: 'NOTIF-1',
    title: 'Interview Scheduled: Infosys Innovation Labs',
    message: 'Your technical interview for Cloud Backend Engineering Intern is confirmed for 04 Sept at 3:00 PM IST.',
    time: '2 hours ago',
    type: 'interview',
    unread: true
  },
  {
    id: 'NOTIF-2',
    title: 'New High-Match Internship Posted',
    message: 'TCS Research posted "Full Stack Web & AI Systems Intern" (88% Skill Match with your profile).',
    time: '1 day ago',
    type: 'match',
    unread: true
  },
  {
    id: 'NOTIF-3',
    title: 'Skill Assessment Result Ready',
    message: 'You scored 85% in Java and 80% in SQL. View your detailed AI Gap Analysis report.',
    time: '3 days ago',
    type: 'assessment',
    unread: false
  }
];
