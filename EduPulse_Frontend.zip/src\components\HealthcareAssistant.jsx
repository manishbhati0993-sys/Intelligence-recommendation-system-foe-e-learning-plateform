import React, { useState, useEffect } from 'react';
import {
  Activity,
  Stethoscope,
  Scan,
  UserCheck,
  HeartPulse,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Brain,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';
import ThreeBodyModel from './ThreeBodyModel';
import SymptomChecker from './SymptomChecker';
import VitalsHUD from './VitalsHUD';
import DiagnosisResult from './DiagnosisResult';
import VisionScanner from './VisionScanner';
import DoctorMatchmaker from './DoctorMatchmaker';
import HealthReportModal from './HealthReportModal';
import { MEDICAL_DATA } from '../data/medicalData';

export default function HealthcareAssistant() {
  const [activeSubTab, setActiveSubTab] = useState('clinical_diagnosis');
  const [selectedOrgan, setSelectedOrgan] = useState('lungs');
  const [selectedSymptoms, setSelectedSymptoms] = useState(
    new Set(["Shortness of Breath", "Persistent Cough", "High Fever"])
  );
  const [patientData, setPatientData] = useState({
    name: 'Alex Johnson',
    age: 42,
    gender: 'Male',
    bloodGroup: 'O+'
  });
  const [vitals, setVitals] = useState({
    heartRate: 82,
    bpSystolic: 125,
    bpDiastolic: 82,
    spo2: 97,
    temp: 98.6,
    respirationRate: 18
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [selectedSpecialty, setSelectedSpecialty] = useState('');

  // Handle toggling symptoms
  const handleToggleSymptom = (symptom) => {
    setSelectedSymptoms((prev) => {
      const next = new Set(prev);
      if (next.has(symptom)) {
        next.delete(symptom);
      } else {
        next.add(symptom);
      }
      return next;
    });
  };

  // Add custom symptom
  const handleAddCustomSymptom = (symptom) => {
    setSelectedSymptoms((prev) => {
      const next = new Set(prev);
      next.add(symptom);
      return next;
    });
  };

  // Handle organ selection from 3D model
  const handleSelectOrgan = (organId) => {
    setSelectedOrgan(organId);
    const organObj = MEDICAL_DATA.bodyOrgans.find((o) => o.id === organId);
    if (organObj && organObj.symptoms.length > 0) {
      // Add first symptom of organ
      setSelectedSymptoms((prev) => {
        const next = new Set(prev);
        organObj.symptoms.slice(0, 2).forEach((s) => next.add(s));
        return next;
      });
    }
  };

  // Run AI Diagnostic Assessment Engine
  const handleRunDiagnosis = () => {
    setIsAnalyzing(true);

    setTimeout(() => {
      const symptomsArr = Array.from(selectedSymptoms);
      let bestMatch = MEDICAL_DATA.conditions[0];
      let highestMatchCount = -1;

      MEDICAL_DATA.conditions.forEach((cond) => {
        let matchCount = 0;
        cond.matchKeywords.forEach((kw) => {
          if (symptomsArr.some((s) => s.toLowerCase().includes(kw.toLowerCase()) || kw.toLowerCase().includes(s.toLowerCase()))) {
            matchCount++;
          }
        });
        if (matchCount > highestMatchCount) {
          highestMatchCount = matchCount;
          bestMatch = cond;
        }
      });

      const differential = MEDICAL_DATA.conditions
        .filter((c) => c.id !== bestMatch.id)
        .slice(0, 2)
        .map((c, i) => ({
          name: c.name,
          icd10: c.icd10,
          confidence: Math.max(45, 80 - i * 15),
          category: c.category
        }));

      const matchedDoc = MEDICAL_DATA.doctors.find((d) =>
        d.specialty.toLowerCase().includes(bestMatch.category.toLowerCase()) ||
        bestMatch.specialist.toLowerCase().includes(d.specialty.toLowerCase())
      ) || MEDICAL_DATA.doctors[0];

      setDiagnosisResult({
        analysisId: `DX-${Date.now().toString().slice(-6)}`,
        primaryDiagnosis: {
          ...bestMatch,
          confidence: Math.min(98, bestMatch.baseConfidence + (symptomsArr.length > 2 ? 4 : 0))
        },
        differentialDiagnoses: differential,
        recommendedDoctor: matchedDoc,
        inputSummary: {
          symptomsCount: symptomsArr.length,
          vitalsAlert: vitals.spo2 < 95 || vitals.bpSystolic > 140 ? 'Abnormal' : 'Stable'
        }
      });

      setSelectedSpecialty(bestMatch.specialist.split('/')[0].trim());
      setIsAnalyzing(false);
    }, 1200);
  };

  // Initialize with diagnosis on start
  useEffect(() => {
    handleRunDiagnosis();
  }, []);

  return (
    <div className="space-y-8 py-6">
      
      {/* Banner & Title Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-cyan-950/80 via-slate-900 to-emerald-950/80 p-6 sm:p-8 border border-cyan-500/30 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5" /> MediPulse 3D AI Clinical Decision Support Engine
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              AI-Powered Healthcare Assistant
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Holographic 3D organ symptom mapping, real-time vitals wave telemetry, deep-learning clinical differential diagnosis, and automated specialist referral matching.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsReportModalOpen(true)}
              disabled={!diagnosisResult}
              className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition flex items-center gap-2"
            >
              <FileText className="w-4 h-4" /> Download Clinical Report
            </button>
          </div>
        </div>

        {/* Quick Nav Sub-tabs */}
        <div className="flex flex-wrap items-center gap-2 pt-6 mt-6 border-t border-slate-800">
          <button
            onClick={() => setActiveSubTab('clinical_diagnosis')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'clinical_diagnosis'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Stethoscope className="w-4 h-4" /> 3D Anatomy & Clinical Diagnosis
          </button>

          <button
            onClick={() => setActiveSubTab('vision_scanner')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'vision_scanner'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Scan className="w-4 h-4" /> 3D Radiology & Vision Scanner
          </button>

          <button
            onClick={() => setActiveSubTab('doctors_matching')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'doctors_matching'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <UserCheck className="w-4 h-4" /> Specialist Telehealth Matchmaker
          </button>
        </div>
      </div>

      {/* Main SubTab Contents */}
      {activeSubTab === 'clinical_diagnosis' && (
        <div className="space-y-8">
          {/* Top Row: 3D Holographic Model + Vitals HUD */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Left 3D Anatomical Canvas */}
            <div className="lg:col-span-7 flex flex-col">
              <ThreeBodyModel
                selectedOrgan={selectedOrgan}
                onSelectOrgan={handleSelectOrgan}
                bodyOrgans={MEDICAL_DATA.bodyOrgans}
              />
            </div>

            {/* Right Real-Time Vitals HUD */}
            <div className="lg:col-span-5 flex flex-col">
              <VitalsHUD
                vitals={vitals}
                onUpdateVitals={(updated) => setVitals((prev) => ({ ...prev, ...updated }))}
              />
            </div>
          </div>

          {/* Interactive Symptom Checker Questionnaire */}
          <SymptomChecker
            selectedOrgan={selectedOrgan}
            bodyOrgans={MEDICAL_DATA.bodyOrgans}
            bodyRegions={MEDICAL_DATA.bodyRegions}
            selectedSymptoms={selectedSymptoms}
            onToggleSymptom={handleToggleSymptom}
            onAddCustomSymptom={handleAddCustomSymptom}
            onRunDiagnosis={handleRunDiagnosis}
            patientData={patientData}
            onChangePatientData={(updated) => setPatientData((prev) => ({ ...prev, ...updated }))}
            isAnalyzing={isAnalyzing}
          />

          {/* Diagnosis Results Card */}
          <DiagnosisResult
            diagnosisResult={diagnosisResult}
            onSelectDoctorTab={() => setActiveSubTab('doctors_matching')}
            onOpenReportModal={() => setIsReportModalOpen(true)}
          />
        </div>
      )}

      {activeSubTab === 'vision_scanner' && (
        <VisionScanner
          sampleScans={MEDICAL_DATA.scans}
          onAnalyzeScan={() => {}}
        />
      )}

      {activeSubTab === 'doctors_matching' && (
        <DoctorMatchmaker
          doctors={MEDICAL_DATA.doctors}
          selectedSpecialty={selectedSpecialty}
        />
      )}

      {/* Official Diagnostic Report Modal */}
      {isReportModalOpen && diagnosisResult && (
        <HealthReportModal
          diagnosisResult={diagnosisResult}
          vitals={vitals}
          patientData={patientData}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}
    </div>
  );
}
