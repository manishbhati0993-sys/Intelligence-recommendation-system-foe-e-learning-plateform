import React, { useState } from 'react';
import { Award, FileText, CheckCircle2, ShieldCheck, Download, Share2, Upload, ExternalLink, Lock } from 'lucide-react';

export default function DigitalPortfolio({ userProfile = {} }) {
  const [documents, setDocuments] = useState([
    { id: 'doc_1', name: 'Aarav_Sharma_Ayush_Resume.pdf', type: 'Resume', date: '2026-08-20', size: '1.2 MB', status: 'Verified' },
    { id: 'doc_2', name: 'Ayurvedic_Pharmacognosy_Cert.pdf', type: 'Certificate', date: '2026-06-15', size: '2.4 MB', status: 'Verified' },
    { id: 'doc_3', name: 'BPharm_Ayush_Official_Transcript.pdf', type: 'Academic Record', date: '2026-07-10', size: '3.8 MB', status: 'Verified' }
  ]);

  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyLink = () => {
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleSimulateUpload = () => {
    const newDoc = {
      id: `doc_${Date.now()}`,
      name: `Uploaded_Certificate_${documents.length + 1}.pdf`,
      type: 'Certificate',
      date: new Date().toISOString().split('T')[0],
      size: '1.8 MB',
      status: 'Verified'
    };
    setDocuments([newDoc, ...documents]);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Banner */}
      <div className="glass-panel p-6 sm:p-8 border border-emerald-500/30 relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Award className="w-3.5 h-3.5" /> Core Feature #7 & #10 • Verified Digital Portfolio & Secure Document Vault
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Verified Digital Passport & <span className="gradient-text">Document Vault</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Tamper-proof digital portfolio containing verified skill badges, university transcripts, industry certifications, and secure document storage for direct recruiter sharing.
          </p>
        </div>
      </div>

      {/* Student Passport Card */}
      <div className="glass-panel p-6 sm:p-8 border border-slate-800 space-y-6">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <img
              src={userProfile.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250'}
              alt={userProfile.name}
              className="w-16 h-16 rounded-2xl object-cover ring-2 ring-emerald-400"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-white">{userProfile.name || 'Aarav Sharma'}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ✓ Verified Student
                </span>
              </div>
              <p className="text-xs text-cyan-400 font-semibold">{userProfile.title || 'B.Pharm (Ayurveda) Final Year'}</p>
              <p className="text-[11px] text-slate-400">{userProfile.institution || 'National Institute of Ayurveda, Jaipur'}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCopyLink}
            className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-500 text-xs font-bold text-white transition flex items-center gap-2"
          >
            <Share2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>{copiedLink ? 'Link Copied!' : 'Share Public Portfolio'}</span>
          </button>
        </div>

        {/* Verified Badges Grid */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Verified Skill Badges:</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3 rounded-xl bg-slate-900/80 border border-emerald-500/30 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-white">Pharmacognosy</p>
                <span className="text-[10px] text-emerald-400">Level: 85% Expert</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-500/30 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-white">HPLC Standard</p>
                <span className="text-[10px] text-cyan-400">Level: 70% Proficient</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-purple-500/30 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-white">AYUSH GCP</p>
                <span className="text-[10px] text-purple-400">Certified 2026</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-amber-500/30 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-white">GMP Compliance</p>
                <span className="text-[10px] text-amber-400">Level: 80% Proficient</span>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Secure Document Vault */}
      <div className="glass-panel p-6 sm:p-8 border border-slate-800 space-y-6">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-bold text-base">
            <Lock className="w-5 h-5 text-emerald-400" />
            <span>Secure Document Vault (Encrypted & Verified)</span>
          </div>

          <button
            type="button"
            onClick={handleSimulateUpload}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-extrabold transition flex items-center gap-1.5 shadow-md"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Document</span>
          </button>
        </div>

        <div className="space-y-3">
          {documents.map((doc) => (
            <div key={doc.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-slate-800 text-cyan-400">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{doc.name}</h4>
                  <p className="text-[10px] text-slate-400">{doc.type} • {doc.size} • Uploaded {doc.date}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ✓ {doc.status}
                </span>

                <button className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

    </div>
  );
}
