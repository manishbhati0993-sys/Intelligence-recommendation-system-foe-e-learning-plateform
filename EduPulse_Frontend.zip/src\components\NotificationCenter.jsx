import React from 'react';
import { Bell, X, CheckCircle2, Clock, Sparkles, Calendar, Briefcase } from 'lucide-react';

export default function NotificationCenter({ isOpen, onClose, notifications = [], onMarkAllRead }) {
  if (!isOpen) return null;

  return (
    <div class="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm">
      <div class="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full p-6 flex flex-col justify-between shadow-2xl animate-in slide-in-from-right">
        
        <div class="space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-4">
            <div class="flex items-center gap-2">
              <Bell class="w-5 h-5 text-cyan-400" />
              <h2 class="text-lg font-bold text-white">Notifications</h2>
              <span class="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 text-[10px] font-bold">
                {notifications.filter(n => n.unread).length} Unread
              </span>
            </div>
            <button onClick={onClose} class="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition">
              <X class="w-4 h-4" />
            </button>
          </div>

          <div class="space-y-3 overflow-y-auto max-h-[75vh] pr-1">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                class={`p-4 rounded-2xl border transition space-y-1.5 ${
                  notif.unread
                    ? 'bg-slate-950/80 border-cyan-500/40 shadow-sm'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400'
                }`}
              >
                <div class="flex items-start justify-between gap-2">
                  <h4 class="text-xs font-bold text-white">{notif.title}</h4>
                  <span class="text-[10px] text-slate-500 shrink-0">{notif.time}</span>
                </div>
                <p class="text-xs text-slate-300 leading-relaxed">{notif.message}</p>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          class="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
        >
          Close Notifications
        </button>

      </div>
    </div>
  );
}
