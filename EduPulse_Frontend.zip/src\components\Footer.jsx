import React from 'react';
import { Cpu, Heart, ShieldCheck, Sparkles, ExternalLink } from 'lucide-react';

export default function Footer({ setActiveTab }) {
  return (
    <footer className="mt-24 border-t border-slate-800/80 bg-slate-950/95 py-14 text-xs text-slate-400 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1: Platform & Team Brand */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-500 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
                </div>
              </div>
              <div>
                <div className="font-black text-white text-lg tracking-tight flex items-center gap-2">
                  Skill<span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">Bridge</span>
                  <span className="px-2 py-0.5 text-[9px] font-black rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                    SIH 2026
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 font-medium">
                  Industrial Collaboration, Skill Mapping & Smart Internship Portal
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-400 max-w-md leading-relaxed">
              Bridging the gap between university academic curricula and real-world industrial demands through multi-dimensional AI skill vectors, continuous feedback loops, and verified corporate internships.
            </p>

            {/* Team Credit Badge */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              <span className="text-[11px]">Developed by <strong className="text-cyan-300 font-bold">Team Terminal Titan</strong></span>
              <span className="text-slate-600">|</span>
              <span className="text-[11px] text-amber-400 font-semibold">Smart India Hackathon</span>
            </div>
          </div>

          {/* Col 2: Stakeholder Portals */}
          <div className="space-y-3">
            <div className="font-bold text-white text-xs uppercase tracking-wider">Stakeholder Portals</div>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button onClick={() => setActiveTab('student_dashboard')} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                  Student Skill Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('industry_dashboard')} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                  Industry Recruiter Portal
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('college_dashboard')} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                  Institution & TPO Analytics
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('skill_assessment')} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                  AI Adaptive Skill Lab
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('marketplace')} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                  Internship Marketplace
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: SIH National Initiative */}
          <div className="space-y-3">
            <div className="font-bold text-white text-xs uppercase tracking-wider">National Impact</div>
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2">
                {/* SIH Emblem Placeholder */}
                <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400 text-xs">
                  🇮🇳
                </div>
                <div>
                  <div className="font-bold text-white text-xs">Smart India Hackathon</div>
                  <div className="text-[10px] text-slate-400">Ministry of Education Innovation Cell</div>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Building sovereign digital infrastructure to power the National Education Policy (NEP 2020) vision for higher education.
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-[11px] text-slate-500">
            © 2026 <strong className="text-slate-400">SkillBridge</strong> • Team Terminal Titan for Smart India Hackathon. All rights reserved.
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <button onClick={() => setActiveTab('landing')} className="hover:text-cyan-400 transition">System Architecture</button>
            <span>•</span>
            <button onClick={() => setActiveTab('industry_collaboration')} className="hover:text-cyan-400 transition">MoU Framework</button>
            <span>•</span>
            <button onClick={() => setActiveTab('admin_panel')} className="hover:text-cyan-400 transition">Security & Privacy</button>
          </div>
        </div>

      </div>
    </footer>
  );
}
