import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RotateCw, Scan, Eye, Activity, Sparkles, RefreshCw, Zap } from 'lucide-react';

export default function ThreeBodyModel({ selectedOrgan, onSelectOrgan, bodyOrgans = [] }) {
  const mountRef = useRef(null);
  const [hoveredOrgan, setHoveredOrgan] = useState(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [wireframeMode, setWireframeMode] = useState(false);
  const [laserScan, setLaserScan] = useState(true);
  const organMeshesRef = useRef({});
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const laserMeshRef = useRef(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // --- 1. SCENE & CAMERA ---
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x030712, 0.04);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0.8, 4.5);
    cameraRef.current = camera;

    // --- 2. RENDERER ---
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // --- 3. LIGHTS ---
    const ambientLight = new THREE.AmbientLight(0x38bdf8, 0.6);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.2);
    mainLight.position.set(5, 10, 7);
    scene.add(mainLight);

    const rimLight = new THREE.PointLight(0x06b6d4, 2, 10);
    rimLight.position.set(-3, 2, -2);
    scene.add(rimLight);

    const heartLight = new THREE.PointLight(0xf43f5e, 1.5, 3);
    heartLight.position.set(0, 0.4, 0.2);
    scene.add(heartLight);

    // --- 4. HUMAN BODY SILHOUETTE MESH ---
    const bodyGroup = new THREE.Group();
    scene.add(bodyGroup);

    // Torso capsule
    const torsoGeo = new THREE.CylinderGeometry(0.5, 0.35, 1.6, 24);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      transparent: true,
      opacity: 0.25,
      wireframe: wireframeMode,
      roughness: 0.3,
      metalness: 0.8,
    });
    const torso = new THREE.Mesh(torsoGeo, bodyMat);
    torso.position.y = 0.1;
    bodyGroup.add(torso);

    // Head sphere
    const headGeo = new THREE.SphereGeometry(0.32, 24, 24);
    const head = new THREE.Mesh(headGeo, bodyMat);
    head.position.y = 1.25;
    bodyGroup.add(head);

    // Neck cylinder
    const neckGeo = new THREE.CylinderGeometry(0.18, 0.2, 0.25, 16);
    const neck = new THREE.Mesh(neckGeo, bodyMat);
    neck.position.y = 0.98;
    bodyGroup.add(neck);

    // Shoulders & Arms
    const leftArmGeo = new THREE.CylinderGeometry(0.12, 0.09, 1.3, 16);
    const leftArm = new THREE.Mesh(leftArmGeo, bodyMat);
    leftArm.position.set(-0.7, 0.1, 0);
    leftArm.rotation.z = Math.PI / 14;
    bodyGroup.add(leftArm);

    const rightArm = new THREE.Mesh(leftArmGeo, bodyMat);
    rightArm.position.set(0.7, 0.1, 0);
    rightArm.rotation.z = -Math.PI / 14;
    bodyGroup.add(rightArm);

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.16, 0.11, 1.6, 16);
    const leftLeg = new THREE.Mesh(legGeo, bodyMat);
    leftLeg.position.set(-0.25, -1.35, 0);
    bodyGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, bodyMat);
    rightLeg.position.set(0.25, -1.35, 0);
    bodyGroup.add(rightLeg);

    // --- 5. DETAILED 3D ORGANS ---
    const organsGroup = new THREE.Group();
    bodyGroup.add(organsGroup);

    const createOrganMesh = (id, geometry, color, position, scale = [1, 1, 1]) => {
      const mat = new THREE.MeshStandardMaterial({
        color: color,
        emissive: color,
        emissiveIntensity: 0.4,
        roughness: 0.2,
        metalness: 0.6,
        transparent: true,
        opacity: 0.85,
      });
      const mesh = new THREE.Mesh(geometry, mat);
      mesh.position.set(...position);
      mesh.scale.set(...scale);
      mesh.userData = { id, color, baseScale: scale };
      organsGroup.add(mesh);
      organMeshesRef.current[id] = mesh;
      return mesh;
    };

    // 1. Brain
    const brainGeo = new THREE.SphereGeometry(0.22, 16, 16);
    brainGeo.scale(1.2, 0.9, 1.1);
    createOrganMesh('brain', brainGeo, 0x38bdf8, [0, 1.25, 0]);

    // 2. Heart
    const heartShape = new THREE.Shape();
    heartShape.moveTo(0, 0);
    heartShape.bezierCurveTo(-0.1, 0.1, -0.2, 0.05, -0.15, -0.1);
    heartShape.bezierCurveTo(-0.1, -0.2, 0, -0.25, 0, -0.3);
    heartShape.bezierCurveTo(0, -0.25, 0.1, -0.2, 0.15, -0.1);
    heartShape.bezierCurveTo(0.2, 0.05, 0.1, 0.1, 0, 0);
    const extrudeSettings = { depth: 0.08, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.04, bevelThickness: 0.04 };
    const heartGeo = new THREE.ExtrudeGeometry(heartShape, extrudeSettings);
    createOrganMesh('heart', heartGeo, 0xf43f5e, [-0.08, 0.52, 0.18], [0.9, 0.9, 0.9]);

    // 3. Lungs
    const lungLeftGeo = new THREE.ConeGeometry(0.18, 0.55, 16);
    createOrganMesh('lungs', lungLeftGeo, 0x06b6d4, [-0.22, 0.45, 0.05], [1, 1, 0.8]);
    const lungRightGeo = new THREE.ConeGeometry(0.18, 0.55, 16);
    const lungRight = new THREE.Mesh(lungRightGeo, new THREE.MeshStandardMaterial({ color: 0x06b6d4, emissive: 0x06b6d4, emissiveIntensity: 0.4 }));
    lungRight.position.set(0.22, 0.45, 0.05);
    lungRight.userData = { id: 'lungs', color: 0x06b6d4, baseScale: [1, 1, 0.8] };
    organsGroup.add(lungRight);

    // 4. Liver
    const liverGeo = new THREE.BoxGeometry(0.32, 0.18, 0.22);
    createOrganMesh('liver', liverGeo, 0xeab308, [0.18, 0.12, 0.1]);

    // 5. Stomach
    const stomachGeo = new THREE.TorusGeometry(0.12, 0.07, 12, 24, Math.PI * 1.2);
    createOrganMesh('stomach', stomachGeo, 0xf97316, [-0.15, 0.08, 0.12]);

    // 6. Kidneys
    const kidneyGeo = new THREE.SphereGeometry(0.1, 12, 12);
    kidneyGeo.scale(0.8, 1.4, 0.9);
    createOrganMesh('kidneys', kidneyGeo, 0x10b981, [-0.2, -0.15, -0.1]);
    const kidneyR = new THREE.Mesh(kidneyGeo, new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x10b981, emissiveIntensity: 0.4 }));
    kidneyR.position.set(0.2, -0.15, -0.1);
    kidneyR.userData = { id: 'kidneys', color: 0x10b981, baseScale: [0.8, 1.4, 0.9] };
    organsGroup.add(kidneyR);

    // 7. Spine
    const spineGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.5, 12);
    createOrganMesh('spine', spineGeo, 0xa855f7, [0, 0.1, -0.22]);

    // --- 6. HOLOGRAPHIC SCANNER LASER RING ---
    const laserGeo = new THREE.RingGeometry(0.7, 0.75, 32);
    const laserMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.7,
    });
    const laserRing = new THREE.Mesh(laserGeo, laserMat);
    laserRing.rotation.x = Math.PI / 2;
    laserRing.position.y = 0.5;
    scene.add(laserRing);
    laserMeshRef.current = laserRing;

    // --- 7. PARTICLE BACKGROUND ---
    const particlesGeo = new THREE.BufferGeometry();
    const particleCount = 150;
    const posArray = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      posArray[i] = (Math.random() - 0.5) * 8;
      posArray[i + 1] = (Math.random() - 0.5) * 8;
      posArray[i + 2] = (Math.random() - 0.5) * 8;
    }
    particlesGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particlesMat = new THREE.PointsMaterial({
      size: 0.025,
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.4,
    });
    const particlesMesh = new THREE.Points(particlesGeo, particlesMat);
    scene.add(particlesMesh);

    // --- 8. RAYCASTING INTERACTION ---
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerMove = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(organsGroup.children);

      if (intersects.length > 0) {
        const organId = intersects[0].object.userData?.id;
        if (organId) {
          setHoveredOrgan(organId);
          container.style.cursor = 'pointer';
        }
      } else {
        setHoveredOrgan(null);
        container.style.cursor = 'default';
      }
    };

    const handlePointerClick = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(organsGroup.children);

      if (intersects.length > 0) {
        const organId = intersects[0].object.userData?.id;
        if (organId && onSelectOrgan) {
          onSelectOrgan(organId);
        }
      }
    };

    container.addEventListener('pointermove', handlePointerMove);
    container.addEventListener('click', handlePointerClick);

    // --- 9. ANIMATION LOOP ---
    let clock = new THREE.Clock();
    let animId;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Auto rotation
      if (autoRotate) {
        bodyGroup.rotation.y = elapsedTime * 0.4;
      }

      // Laser sweep animation
      if (laserScan && laserMeshRef.current) {
        laserMeshRef.current.position.y = Math.sin(elapsedTime * 2) * 1.3 + 0.1;
      }

      // Heartbeat pulse effect
      if (organMeshesRef.current['heart']) {
        const heartMesh = organMeshesRef.current['heart'];
        const pulse = 1 + Math.sin(elapsedTime * 8) * 0.08;
        heartMesh.scale.set(0.9 * pulse, 0.9 * pulse, 0.9 * pulse);
      }

      // Breathing effect on lungs
      if (organMeshesRef.current['lungs']) {
        const lungMesh = organMeshesRef.current['lungs'];
        const breath = 1 + Math.sin(elapsedTime * 2) * 0.05;
        lungMesh.scale.set(breath, breath, breath);
      }

      // Highlight selected organ
      Object.entries(organMeshesRef.current).forEach(([id, mesh]) => {
        if (id === selectedOrgan) {
          mesh.material.emissiveIntensity = 1.0;
          mesh.material.opacity = 1.0;
        } else if (id === hoveredOrgan) {
          mesh.material.emissiveIntensity = 0.8;
          mesh.material.opacity = 0.9;
        } else {
          mesh.material.emissiveIntensity = 0.3;
          mesh.material.opacity = 0.75;
        }
      });

      particlesMesh.rotation.y = elapsedTime * 0.05;
      renderer.render(scene, camera);
    };

    animate();

    // --- 10. RESIZE HANDLER ---
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      container.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('click', handlePointerClick);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [selectedOrgan, autoRotate, wireframeMode, laserScan]);

  const activeOrganObj = bodyOrgans.find(o => o.id === (selectedOrgan || hoveredOrgan));

  return (
    <div class="relative w-full h-[520px] glass-panel overflow-hidden flex flex-col justify-between p-4 border border-cyan-500/20">
      
      {/* 3D Canvas Header Controls */}
      <div class="relative z-10 flex flex-wrap items-center justify-between gap-2 no-print">
        <div class="flex items-center gap-2">
          <span class="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Activity class="w-5 h-5 animate-pulse" />
          </span>
          <div>
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              Interactive 3D Body Anatomy
              <span class="px-2 py-0.5 text-[10px] uppercase tracking-wider rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                WebGL 3.0 Live
              </span>
            </h3>
            <p class="text-[11px] text-slate-400">Rotate, zoom & click any organ to target diagnostic scan</p>
          </div>
        </div>

        {/* Action Controls */}
        <div class="flex items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setAutoRotate(!autoRotate)}
            title="Toggle 3D Rotation"
            class={`p-2 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
              autoRotate ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <RotateCw class={`w-4 h-4 ${autoRotate ? 'animate-spin-slow' : ''}`} />
            <span class="hidden sm:inline">Orbit</span>
          </button>

          <button
            type="button"
            onClick={() => setLaserScan(!laserScan)}
            title="Toggle Holographic Scanner"
            class={`p-2 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
              laserScan ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Scan class="w-4 h-4" />
            <span class="hidden sm:inline">Laser Scan</span>
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas Viewport */}
      <div ref={mountRef} class="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Holographic Laser Sweep Effect (Overlay CSS fallback) */}
      {laserScan && <div class="laser-sweep pointer-events-none z-10" />}

      {/* Active Organ HUD Callout Badge */}
      <div class="relative z-10 flex flex-wrap items-center justify-between gap-3 pt-2">
        {activeOrganObj ? (
          <div class="glass-card bg-slate-900/90 border-cyan-500/50 p-3 rounded-xl flex items-center gap-3 animate-fade-in shadow-xl shadow-cyan-500/10">
            <div
              class="w-4 h-4 rounded-full shadow-lg"
              style={{ backgroundColor: activeOrganObj.color, boxShadow: `0 0 12px ${activeOrganObj.color}` }}
            />
            <div>
              <p class="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">Targeted Organ Target</p>
              <h4 class="text-sm font-extrabold text-white">{activeOrganObj.name}</h4>
            </div>
            <button
              type="button"
              onClick={() => onSelectOrgan(activeOrganObj.id)}
              class="ml-2 px-3 py-1 text-xs font-bold rounded-lg bg-cyan-500 text-slate-950 hover:bg-cyan-400 transition"
            >
              Analyze Organ
            </button>
          </div>
        ) : (
          <div class="px-3 py-1.5 rounded-lg bg-slate-900/60 border border-slate-800 text-slate-400 text-xs flex items-center gap-2">
            <Sparkles class="w-3.5 h-3.5 text-cyan-400" /> Hover or click an organ mesh to isolate diagnosis
          </div>
        )}

        <div class="text-[10px] text-slate-500 font-mono tracking-tight bg-slate-950/60 px-2.5 py-1 rounded-md border border-slate-800">
          FPS: 60 | SHADER: GLSL ES 3.0 | RAYCAST: ACTIVE
        </div>
      </div>

    </div>
  );
}
