import React, { useState, useEffect } from 'react';
import {
  Compass,
  Target,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ArrowRight,
  TrendingUp,
  Award,
  Zap,
  BarChart2
} from 'lucide-react';
import { TARGET_ROLE_BENCHMARKS } from '../data/portalData';

export default function SkillAnalysis({ currentUser, setActiveTab }) {
  const [selectedRole, setSelectedRole] = useState(TARGET_ROLE_BENCHMARKS[0].role);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchSkillGap = async (roleName) => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/skill-gap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetRoleName: roleName,
          studentSkills: currentUser?.skills || []
        })
      });
      const data = await res.json();
      if (data.success) {
        setAnalysisResult(data);
        setLoading(false);
        return;
      }
    } catch (err) {
      // Local fallback gap calculation
      const targetBenchmark = TARGET_ROLE_BENCHMARKS.find(b => b.role === roleName) || TARGET_ROLE_BENCHMARKS[0];
      const studentSkills = currentUser?.skills || [];

      const comparison = targetBenchmark.requiredSkills.map(req => {
        const found = studentSkills.find(s => s.name.toLowerCase() === req.name.toLowerCase());
        const studentLevel = found ? found.level : 0;
        const gap = req.minLevel - studentLevel;

        let status = 'Met';
        if (gap > 20) status = 'Severe Gap';
        else if (gap > 0) status = 'Moderate Gap';

        return {
          skill: req.name,
          requiredLevel: req.minLevel,
          studentLevel,
          priority: req.priority,
          gap: Math.max(gap, 0),
          status
        };
      });

      const metCount = comparison.filter(c => c.status === 'Met').length;
      const overallMatch = Math.round((metCount / comparison.length) * 100);

      setAnalysisResult({
        success: true,
        targetRole: roleName,
        domain: targetBenchmark.domain,
        avgSalary: targetBenchmark.avgSalary,
        overallMatch,
        comparison,
        aiRecommendation: `Your profile currently matches ${overallMatch}% of required competencies for ${roleName}. Primary focus should be closing the gaps in ${comparison.filter(c => c.gap > 0).map(c => c.skill).join(', ') || 'specialized tools'}.`
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSkillGap(selectedRole);
  }, [selectedRole]);

  return (
    <div class="max-w-5xl mx-auto py-4 space-y-6">
      
      {/* Header Banner */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                AI Skill-Mapping Engine
              </span>
              <span class="text-xs text-slate-400">• Student vs Industry Requirements</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-white mt-2">
              Industry Skill Gap & Employability Analysis
            </h1>
          </div>

          {/* Target Role Selector */}
          <div class="space-y-1">
            <label class="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Select Target Role:</label>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              class="px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-bold text-cyan-300 focus:outline-none focus:border-cyan-500 shadow-md"
            >
              {TARGET_ROLE_BENCHMARKS.map((r, idx) => (
                <option key={idx} value={r.role}>{r.role}</option>
              ))}
            </select>
          </div>
        </div>

        <p class="text-xs sm:text-sm text-slate-300">
          Our AI compares your verified assessment scores and coursework against the top 100+ active hiring criteria from partner companies (Infosys, TCS, Wipro, Ayush Tech).
        </p>
      </div>

      {analysisResult && (
        <div class="space-y-6">
          
          {/* Top Score Banner */}
          <div class="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/30 border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-6 items-center">
            
            <div class="text-center sm:text-left">
              <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Candidate Match Score</div>
              <div class="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400 mt-1">
                {analysisResult.matchPercentage}%
              </div>
              <div class="text-[11px] text-emerald-400 font-semibold mt-0.5">
                Eligible for Tier-1 Internships
              </div>
            </div>

            <div class="space-y-1">
              <div class="text-xs text-slate-400">Industry Salary Range</div>
              <div class="text-lg font-bold text-white">{analysisResult.avgSalary}</div>
              <div class="text-[11px] text-slate-400">Domain: {analysisResult.domain}</div>
            </div>

            <div class="flex sm:justify-end">
              <button
                onClick={() => setActiveTab('learning_roadmap')}
                class="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-extrabold text-xs transition shadow-lg shadow-cyan-500/20 flex items-center gap-2"
              >
                <Sparkles class="w-4 h-4" /> Generate AI Roadmap
              </button>
            </div>

          </div>

          {/* Strengths vs Missing Gaps Cards */}
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Strengths */}
            <div class="p-6 rounded-2xl bg-slate-900/70 border border-emerald-500/30 space-y-4">
              <div class="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 class="w-4 h-4" /> Strong Competencies (Exceeds Benchmark)
              </div>
              <div class="flex flex-wrap gap-2">
                {analysisResult.topStrengths?.map((str, idx) => (
                  <span key={idx} class="px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-bold text-xs flex items-center gap-1.5">
                    <CheckCircle2 class="w-3.5 h-3.5" /> {str}
                  </span>
                ))}
              </div>
            </div>

            {/* Missing Gaps */}
            <div class="p-6 rounded-2xl bg-slate-900/70 border border-rose-500/30 space-y-4">
              <div class="flex items-center gap-2 text-rose-400 font-bold text-sm">
                <XCircle class="w-4 h-4" /> Missing / Deficient Skills (High Impact)
              </div>
              <div class="flex flex-wrap gap-2">
                {analysisResult.topMissingGaps?.map((gap, idx) => (
                  <span key={idx} class="px-3 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 font-bold text-xs flex items-center gap-1.5">
                    <AlertTriangle class="w-3.5 h-3.5" /> {gap}
                  </span>
                ))}
              </div>
            </div>

          </div>

          {/* Detailed Skill-by-Skill Gap Matrix */}
          <div class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <BarChart2 class="w-4 h-4 text-cyan-400" /> Skill Deficiency Breakdown & Priority Weightings
            </h3>

            <div class="space-y-4 pt-2">
              {analysisResult.breakdown?.map((item, idx) => (
                <div key={idx} class="p-4 rounded-xl bg-slate-950/50 border border-slate-800/80 space-y-2">
                  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-white text-xs">{item.skill}</span>
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                        Priority: {item.priority}
                      </span>
                      <span class={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.status === 'Strong' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        item.status === 'Moderate' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                        item.status === 'Beginner' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        {item.status}
                      </span>
                    </div>

                    <div class="text-xs font-mono text-slate-400">
                      Student Level: <strong class="text-white">{item.studentLevel}%</strong> / Min Required: <strong class="text-cyan-400">{item.requiredMinLevel}%</strong>
                    </div>
                  </div>

                  {/* Dual Bar: Student vs Required */}
                  <div class="space-y-1">
                    <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        class={`h-full rounded-full ${
                          item.studentLevel >= item.requiredMinLevel ? 'bg-emerald-500' : 'bg-rose-500'
                        }`}
                        style={{ width: `${item.studentLevel}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
