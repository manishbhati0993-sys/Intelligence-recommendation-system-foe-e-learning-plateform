import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Target,
  Briefcase,
  GraduationCap,
  Award,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Compass,
  Clock,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Bot,
  Github,
  ShieldCheck,
  MessageSquare,
  BookOpen,
  Calendar,
  Layers,
  FileBadge,
  UserCheck
} from 'lucide-react';
import SkillRadarChart from './SkillRadarChart';

export default function StudentDashboard({
  currentUser,
  portalData,
  setActiveTab,
  onApplyJob
}) {
  const [activeSubView, setActiveSubView] = useState('overview'); // 'overview' | 'projects' | 'certifications' | 'feedback'
  const skills = currentUser?.skills || [];
  const applications = portalData?.applications || [];
  const internships = portalData?.internships || [];
  const roadmap = portalData?.roadmap;

  // Calculate average skill score
  const avgScore = skills.length > 0
    ? Math.round(skills.reduce((acc, s) => acc + s.level, 0) / skills.length)
    : 78;

  // Mock feedback loop data
  const feedbackItems = [
    {
      id: 'FB-1',
      source: 'Priya Nambiar (Infosys Innovation Labs)',
      role: 'Head of Technical Talent',
      type: 'Recruiter Assessment',
      date: 'Yesterday, 4:15 PM',
      rating: 4.8,
      comment: 'Exceptional grasp of Java memory model and distributed caching. Recommended to complete a hands-on Spring Boot 3 microservice project with Docker Compose before Round 2.',
      status: 'Action Required',
      recommendedAction: 'Take Spring Boot Module in AI Roadmap'
    },
    {
      id: 'FB-2',
      source: 'SkillBridge AI Mock Interviewer',
      role: 'Automated Diagnostic Engine',
      type: 'Mock Technical Interview',
      date: '02 Sept 2026',
      rating: 4.5,
      comment: 'SQL query optimization and B-Tree indexing concepts scored in 92nd percentile. REST API error handling and status code idempotency scored in 70th percentile.',
      status: 'Reviewed',
      recommendedAction: 'Review REST API Idempotency Guide'
    },
    {
      id: 'FB-3',
      source: 'Dr. Ramesh Sundaram',
      role: 'TPO Head & Academic Advisor (NITK)',
      type: 'Faculty Endorsement',
      date: '28 Aug 2026',
      rating: 5.0,
      comment: 'Verified student capstone project on Distributed Task Queue. Nominated for Tier-1 corporate fast-track placement interviews.',
      status: 'Endorsed',
      recommendedAction: 'Keep GitHub repository README updated'
    }
  ];

  return (
    <div className="space-y-8 py-4">
      
      {/* 1. WELCOME HERO & PROFILE SUMMARY BANNER */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900/95 to-cyan-950/40 border border-slate-800 relative overflow-hidden shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          <div className="lg:col-span-8 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-0.5 text-xs font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Verified Student Profile
              </span>
              <span className="text-xs text-slate-400">• NIT Karnataka (NITK)</span>
              <span className="text-xs text-slate-400">• CGPA: <strong className="text-white">{currentUser?.cgpa || '8.74'}</strong></span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Welcome back, <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">{currentUser?.name}</span>! 👋
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Target Career Role: <strong className="text-cyan-300">{currentUser?.targetRole || 'Backend Developer / Java Specialist'}</strong>. Your multi-dimensional skill vector currently exhibits a <strong>78% match</strong> with top Tier-1 industry openings.
            </p>

            {/* Quick Action Navigation Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setActiveTab('skill_assessment')}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center gap-1.5 shadow-lg shadow-cyan-500/20"
              >
                <FileCheck className="w-3.5 h-3.5" /> Take Skill Assessment
              </button>

              <button
                onClick={() => setActiveTab('skill_analysis')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-xs transition flex items-center gap-1.5"
              >
                <Compass className="w-3.5 h-3.5 text-cyan-400" /> Skill Gap Analysis
              </button>

              <button
                onClick={() => setActiveTab('learning_roadmap')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-xs transition flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400" /> AI Career Pathway
              </button>

              <button
                onClick={() => setActiveTab('ai_chatbot')}
                className="px-4 py-2 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/50 text-emerald-300 font-bold text-xs transition flex items-center gap-1.5"
              >
                <Bot className="w-3.5 h-3.5" /> Ask Career AI
              </button>
            </div>
          </div>

          {/* Quick Readiness Score Gauge */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center p-5 rounded-2xl bg-slate-950/80 border border-slate-800 text-center shadow-inner">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Industry Readiness Index
            </div>
            <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400">
              {avgScore}%
            </div>
            <div className="text-[11px] text-emerald-400 font-semibold mt-1 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> High Tier-1 Eligibility
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
              <div className="bg-gradient-to-r from-cyan-500 to-emerald-500 h-full rounded-full" style={{ width: `${avgScore}%` }}></div>
            </div>
            <div className="text-[10px] text-slate-400 mt-2">
              Based on {skills.length} verified technical metrics
            </div>
          </div>

        </div>
      </div>

      {/* 2. FOUR KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div
          onClick={() => setActiveTab('skill_analysis')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">Target Benchmark Match</span>
            <Target className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition" />
          </div>
          <div className="text-2xl font-bold text-white mt-2">78% Match</div>
          <p className="text-[11px] text-cyan-300 mt-1">Backend Engineer / Java</p>
        </div>

        <div
          onClick={() => setActiveTab('applications')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-emerald-500/40 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">Active Applications</span>
            <Briefcase className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition" />
          </div>
          <div className="text-2xl font-bold text-white mt-2">{applications.length} Active</div>
          <p className="text-[11px] text-emerald-400 mt-1">1 Interview Confirmed (Infosys)</p>
        </div>

        <div
          onClick={() => setActiveTab('learning_roadmap')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-purple-500/40 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">AI Learning Pathway</span>
            <Sparkles className="w-4 h-4 text-purple-400 group-hover:scale-110 transition" />
          </div>
          <div className="text-2xl font-bold text-white mt-2">Milestone 1 of 3</div>
          <p className="text-[11px] text-purple-300 mt-1">REST APIs & Spring Data JPA</p>
        </div>

        <div
          onClick={() => setActiveTab('student_profile')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">Verified Portfolio Items</span>
            <Award className="w-4 h-4 text-amber-400 group-hover:scale-110 transition" />
          </div>
          <div className="text-2xl font-bold text-white mt-2">{currentUser?.projects?.length || 2} Projects</div>
          <p className="text-[11px] text-amber-300 mt-1">2 Blockchain Certificates</p>
        </div>

      </div>

      {/* 3. CORE INTERACTIVE SECTION: SKILL RADAR & SMART MATCHED INTERNSHIPS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column (5 Cols): Dynamic Interactive Skill Radar Graph */}
        <div className="lg:col-span-5 space-y-4">
          <SkillRadarChart
            skills={skills}
            benchmarkRole={currentUser?.targetRole || 'Backend Developer / Java Specialist'}
          />

          {/* Skill Gap Analysis Summary Widget */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-cyan-400" />
                Key Skill Gaps vs Industry Benchmark
              </h4>
              <button
                onClick={() => setActiveTab('skill_analysis')}
                className="text-[11px] text-cyan-400 hover:underline font-semibold"
              >
                Deep Dive →
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800/80">
                <div>
                  <div className="font-semibold text-slate-200">Spring Boot 3.x</div>
                  <div className="text-[10px] text-slate-400">Current: 45% | Required: 75%</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  High Gap (-30%)
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800/80">
                <div>
                  <div className="font-semibold text-slate-200">Docker & Microservices</div>
                  <div className="text-[10px] text-slate-400">Current: 35% | Required: 65%</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  High Gap (-30%)
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800/80">
                <div>
                  <div className="font-semibold text-slate-200">RESTful APIs</div>
                  <div className="text-[10px] text-slate-400">Current: 60% | Required: 80%</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  Moderate (-20%)
                </span>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('learning_roadmap')}
              className="w-full py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 font-bold text-xs transition flex items-center justify-center gap-1.5 mt-2"
            >
              <Sparkles className="w-3.5 h-3.5" /> Bridge Gaps via AI Learning Pathway
            </button>
          </div>
        </div>

        {/* Right Column (7 Cols): Smart Matched Internships */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-cyan-400" /> Recommended Smart Internships
              </h3>
              <p className="text-xs text-slate-400">
                Ranked by multi-vector AI skill match percentage
              </p>
            </div>
            <button
              onClick={() => setActiveTab('marketplace')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 transition flex items-center gap-1"
            >
              View All ({internships.length}) <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4">
            {internships.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition space-y-4 shadow-lg group"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.logo}
                      alt={item.company}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <h4 className="text-sm font-bold text-white group-hover:text-cyan-400 transition">
                        {item.title}
                      </h4>
                      <p className="text-xs text-slate-400">
                        {item.company} • <span className="text-slate-300 font-medium">{item.location}</span>
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 text-xs font-black rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      88% Match
                    </span>
                    <div className="text-[10px] text-slate-400 mt-1">High Compatibility</div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2">
                  {item.description}
                </p>

                {/* Skills Match Breakdown */}
                <div className="space-y-1.5 pt-1">
                  <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                    Required Skills Breakdown:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {item.requiredSkills.map((sk, idx) => {
                      const hasSkill = skills.some(s => s.name.toLowerCase().includes(sk.toLowerCase()) || sk.toLowerCase().includes(s.name.toLowerCase()));
                      return (
                        <span
                          key={idx}
                          className={`px-2.5 py-0.5 rounded-md text-[10px] font-medium flex items-center gap-1 ${
                            hasSkill
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
                          }`}
                        >
                          {hasSkill ? <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" /> : '✕'}
                          {sk}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Footer details */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center gap-3 text-slate-400">
                    <span className="font-bold text-cyan-300">{item.stipend}</span>
                    <span>•</span>
                    <span>{item.type}</span>
                  </div>

                  <button
                    onClick={() => onApplyJob(item.id)}
                    className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
                  >
                    1-Click Apply <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 4. SUB-SECTIONS TOGGLE: VERIFIED INDUSTRY PROJECTS / CERTIFICATIONS / LIVE FEEDBACK */}
      <div className="space-y-6 pt-4">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveSubView('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeSubView === 'overview'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Verified Industry Projects ({currentUser?.projects?.length || 2})
          </button>

          <button
            onClick={() => setActiveSubView('certifications')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeSubView === 'certifications'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileBadge className="w-3.5 h-3.5" /> Verifiable Certifications ({currentUser?.certifications?.length || 2})
          </button>

          <button
            onClick={() => setActiveSubView('feedback')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeSubView === 'feedback'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" /> Live Feedback Loop ({feedbackItems.length})
          </button>
        </div>

        {/* View A: Verified Industry Projects */}
        {activeSubView === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(currentUser?.projects || []).map((proj) => (
              <div
                key={proj.id}
                className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition space-y-4 shadow-xl"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Industry Verified
                      </span>
                      <span className="text-[10px] text-slate-400">GitHub Verified</span>
                    </div>
                    <h4 className="text-base font-bold text-white mt-1.5">{proj.title}</h4>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {proj.description}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {proj.techStack?.map((tech, idx) => (
                    <span key={idx} className="px-2.5 py-0.5 rounded-md bg-slate-800 text-[10px] font-mono text-cyan-300">
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
                  <a
                    href={proj.github}
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-400 hover:text-white transition flex items-center gap-1.5"
                  >
                    <Github className="w-3.5 h-3.5" /> Code Repo
                  </a>

                  <a
                    href={proj.demo}
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 transition flex items-center gap-1"
                  >
                    Live Demo <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* View B: Verifiable Certifications */}
        {activeSubView === 'certifications' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(currentUser?.certifications || []).map((cert) => (
              <div
                key={cert.id}
                className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 transition space-y-4 shadow-xl"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Award className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      Cryptographically Signed
                    </span>
                    <h4 className="text-sm font-bold text-white mt-1">{cert.title}</h4>
                    <p className="text-xs text-slate-400">{cert.issuer} • <span className="text-slate-300 font-medium">{cert.date}</span></p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
                  <span>ID: <strong className="text-cyan-300">{cert.credentialId}</strong></span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Verified On-Chain
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <span className="text-[11px] text-slate-400">Accredited by National Academic Depository</span>
                  <button className="text-cyan-400 hover:underline flex items-center gap-1 font-semibold">
                    View Certificate <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* View C: Live Feedback Loop */}
        {activeSubView === 'feedback' && (
          <div className="space-y-4">
            {feedbackItems.map((fb) => (
              <div
                key={fb.id}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 shadow-lg"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                        {fb.type}
                      </span>
                      <span className="text-xs font-bold text-white">{fb.source}</span>
                      <span className="text-xs text-slate-500">• {fb.role}</span>
                    </div>
                  </div>
                  <span className="text-[11px] text-slate-400">{fb.date}</span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  "{fb.comment}"
                </p>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">Next Action:</span>
                    <span className="font-semibold text-cyan-300">{fb.recommendedAction}</span>
                  </div>

                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 self-start sm:self-auto">
                    {fb.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>

    </div>
  );
}
