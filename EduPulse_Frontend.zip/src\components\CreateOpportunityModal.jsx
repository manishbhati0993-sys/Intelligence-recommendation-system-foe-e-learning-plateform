import React, { useState } from 'react';
import { Plus, X, Briefcase, Building2, DollarSign, MapPin, Sparkles } from 'lucide-react';

export default function CreateOpportunityModal({ isOpen, onClose, onPostJob }) {
  const [title, setTitle] = useState('');
  const [type, setType] = useState('Internship');
  const [stipend, setStipend] = useState('₹35,000 / month');
  const [location, setLocation] = useState('Bangalore / Hybrid');
  const [domain, setDomain] = useState('Backend Engineering');
  const [skillsStr, setSkillsStr] = useState('Java, Spring Boot, SQL / PostgreSQL, RESTful APIs');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    const requiredSkills = skillsStr.split(',').map(s => s.trim()).filter(Boolean);

    await onPostJob({
      title,
      type,
      stipend,
      location,
      domain,
      requiredSkills,
      description
    });

    setIsSubmitting(false);
    onClose();
  };

  return (
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
      <div class="p-6 sm:p-8 max-w-xl w-full rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        
        <div class="flex items-center justify-between">
          <div>
            <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 uppercase">
              Recruiter Portal
            </span>
            <h2 class="text-xl font-extrabold text-white mt-1">Post New Opportunity</h2>
          </div>
          <button onClick={onClose} class="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800 transition">
            <X class="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} class="space-y-4">
          <div>
            <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Opportunity Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Cloud Backend Engineering Intern"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Opportunity Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none"
              >
                <option value="Internship">Internship (6 Months)</option>
                <option value="Job">Full Time Job</option>
              </select>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Domain</label>
              <select
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none"
              >
                <option value="Backend Engineering">Backend Engineering</option>
                <option value="Full Stack">Full Stack</option>
                <option value="Artificial Intelligence">Artificial Intelligence</option>
                <option value="Healthcare Informatics">Healthcare Informatics</option>
              </select>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Compensation / Stipend</label>
              <input
                type="text"
                value={stipend}
                onChange={(e) => setStipend(e.target.value)}
                class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Required Skills (Comma separated)</label>
            <input
              type="text"
              value={skillsStr}
              onChange={(e) => setSkillsStr(e.target.value)}
              class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Job Description & Eligibility</label>
            <textarea
              rows="3"
              placeholder="Describe core project responsibilities and interview expectations..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            ></textarea>
          </div>

          <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              class="px-4 py-2.5 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 hover:text-white transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-extrabold text-xs transition shadow-lg shadow-cyan-500/20"
            >
              {isSubmitting ? 'Publishing...' : 'Publish to Marketplace'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
