import React, { useState } from 'react';
import {
  GraduationCap,
  Users,
  Award,
  TrendingUp,
  Building2,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  FileSpreadsheet,
  Download,
  BookOpen,
  Calendar,
  ShieldCheck,
  TrendingDown,
  Activity
} from 'lucide-react';

export default function CollegeDashboard({ currentUser, portalData, setActiveTab }) {
  const analytics = portalData?.collegeAnalytics || [
    { department: 'Computer Science & Engg', totalStudents: 420, avgSkillScore: 78, topGap: 'Docker & Cloud Native', placementRate: '86%' },
    { department: 'Information Science & Tech', totalStudents: 310, avgSkillScore: 75, topGap: 'Spring Boot & Microservices', placementRate: '82%' },
    { department: 'AI & Data Science', totalStudents: 240, avgSkillScore: 82, topGap: 'MLOps & Model Deployment', placementRate: '88%' },
    { department: 'Electronics & Communication', totalStudents: 270, avgSkillScore: 71, topGap: 'Embedded Systems & Python', placementRate: '76%' }
  ];
  const mous = portalData?.mous || [];
  const [downloadToast, setDownloadToast] = useState(false);

  const handleExport = () => {
    setDownloadToast(true);
    setTimeout(() => setDownloadToast(false), 3000);
  };

  // Student skill growth across semesters
  const semesterGrowthData = [
    { semester: 'Sem 3 (Fundamentals)', score: 45, placementReadiness: '18%' },
    { semester: 'Sem 4 (Data Structures)', score: 58, placementReadiness: '32%' },
    { semester: 'Sem 5 (Core Web & DB)', score: 68, placementReadiness: '54%' },
    { semester: 'Sem 6 (AI Mapping Applied)', score: 79, placementReadiness: '76%' },
    { semester: 'Sem 7 (Internship Stage)', score: 87, placementReadiness: '91%' }
  ];

  return (
    <div className="space-y-8 py-4 max-w-7xl mx-auto">
      
      {/* Toast Alert */}
      {downloadToast && (
        <div className="fixed top-20 right-6 z-50 p-4 rounded-2xl bg-slate-900 border border-emerald-500 shadow-2xl text-xs font-bold text-white flex items-center gap-2 animate-in slide-in-from-top">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>NIRF & AICTE Accreditation Placement Report downloaded!</span>
        </div>
      )}

      {/* 1. HEADER BANNER */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-400 p-0.5 shadow-xl flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <GraduationCap className="w-8 h-8 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 text-xs font-black rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Institutional TPO Portal
                </span>
                <span className="text-xs text-slate-400">• NIRF & AICTE Synchronized</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">{currentUser?.college}</h1>
              <p className="text-xs text-slate-300 font-medium">{currentUser?.name} — <span className="text-emerald-400">{currentUser?.title}</span></p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExport}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition flex items-center gap-1.5 border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" /> Export Compliance PDF
            </button>

            <button
              onClick={() => setActiveTab('college_analytics')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-black text-xs transition shadow-lg shadow-emerald-500/20 flex items-center gap-2"
            >
              <BarChart3 className="w-4 h-4" /> Curriculum Heatmap
            </button>
          </div>
        </div>
      </div>

      {/* 2. PLACEMENT OVERVIEW & RANKING METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Enrolled Batch</div>
          <div className="text-2xl font-black text-white mt-2">1,240 Students</div>
          <p className="text-[11px] text-cyan-400 mt-1">4 Engineering Departments</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Placement Conversion</div>
          <div className="text-2xl font-black text-emerald-400 mt-2">84.2% Placed</div>
          <p className="text-[11px] text-emerald-300 mt-1">980 Offers • 88% Conversion</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Package (CTC)</div>
          <div className="text-2xl font-black text-amber-400 mt-2">₹12.8 LPA</div>
          <p className="text-[11px] text-amber-300 mt-1">Highest Package: ₹28.5 LPA</p>
        </div>

        {/* Ranking improvement metric */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-emerald-500/40 bg-emerald-950/10">
          <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" /> NIRF Ranking Impact
          </div>
          <div className="text-2xl font-black text-white mt-2">Rank #12 <span className="text-xs text-emerald-400 font-bold">(+4 Ranks)</span></div>
          <p className="text-[11px] text-slate-400 mt-1">NAAC Metric 5.2: 3.92 / 4.0</p>
        </div>

      </div>

      {/* 3. CURRICULUM VS INDUSTRY SKILL GAP INSIGHTS */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-bold border border-cyan-500/20 mb-1">
              <BookOpen className="w-3.5 h-3.5" />
              Syllabus Diagnostic Telemetry
            </div>
            <h3 className="text-xl font-black text-white">
              Curriculum vs. Live Industry Tech Gap Insights
            </h3>
            <p className="text-xs text-slate-400">
              Departmental assessment scores mapped against corporate job criteria to flag syllabus drift
            </p>
          </div>

          <button
            onClick={handleExport}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 flex items-center gap-1.5 transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Export Excel
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Department</th>
                <th className="p-3.5">Batch Size</th>
                <th className="p-3.5">Avg Technical Score</th>
                <th className="p-3.5">Critical Identified Gap</th>
                <th className="p-3.5">Placement %</th>
                <th className="p-3.5 text-right">Recommended Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {analytics.map((dept, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition">
                  <td className="p-3.5 font-bold text-white">{dept.department}</td>
                  <td className="p-3.5 text-slate-300 font-mono">{dept.totalStudents}</td>
                  <td className="p-3.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-cyan-400 font-bold">{dept.avgSkillScore}%</span>
                      <div className="w-16 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-cyan-500 h-full rounded-full" style={{ width: `${dept.avgSkillScore}%` }}></div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3.5">
                    <span className="px-2.5 py-1 rounded-md bg-rose-500/10 text-rose-400 border border-rose-500/20 font-medium">
                      {dept.topGap}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono text-emerald-400 font-bold">{dept.placementRate}</td>
                  <td className="p-3.5 text-right">
                    <button
                      onClick={() => setActiveTab('college_analytics')}
                      className="text-cyan-400 hover:text-cyan-300 font-bold transition flex items-center gap-1 ml-auto"
                    >
                      Update Syllabus →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. DUAL SECTION: REAL-TIME INDUSTRY COLLABORATION & SEMESTER SKILL GROWTH */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left 7 Cols: Real-time Industry Collaboration Dashboard (Active MoUs) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-400" /> Active Industry Collaboration MoUs
            </h3>
            <button
              onClick={() => setActiveTab('industry_collaboration')}
              className="text-xs font-bold text-cyan-400 hover:underline"
            >
              Manage All ({mous.length}) →
            </button>
          </div>

          <div className="space-y-3">
            {mous.map((mou) => (
              <div
                key={mou.id}
                className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3 shadow-lg"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-white">{mou.company}</h4>
                    <p className="text-xs text-slate-400">{mou.type}</p>
                  </div>
                  <span className="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {mou.status} • Signed {mou.signedDate}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-1 text-center text-xs">
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="font-mono font-bold text-white">{mou.internshipsCommitted}</div>
                    <div className="text-[10px] text-slate-400">Committed Seats</div>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="font-mono font-bold text-emerald-400">{mou.studentsPlaced}</div>
                    <div className="text-[10px] text-slate-400">Placed to Date</div>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="font-mono font-bold text-cyan-400">{mou.facultyTrained}</div>
                    <div className="text-[10px] text-slate-400">Faculty Certified</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 5 Cols: Student Skill Growth Tracking Over Semesters */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" /> Longitudinal Skill Growth Tracking
            </h3>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 shadow-lg">
            <p className="text-xs text-slate-300 leading-relaxed">
              Track cohort competency development over 8 semesters to measure the quantitative impact of SkillBridge integration.
            </p>

            <div className="space-y-3 pt-1">
              {semesterGrowthData.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200">{item.semester}</span>
                    <span className="font-mono font-bold text-cyan-400">{item.score}% Skill Index</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden flex">
                    <div
                      className="bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${item.score}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>Placement Eligibility: <strong className="text-emerald-400">{item.placementReadiness}</strong></span>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> +42% Accelerating Curve
              </span>
              <span>Audited by AI Vector Engine</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
