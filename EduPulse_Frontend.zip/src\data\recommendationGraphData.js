export const graphData = {
  nodes: [
    { id: '1', name: 'Intro to Python', group: 1, type: 'course', description: 'Learn the basics of Python programming.' },
    { id: '2', name: 'Data Science with Python', group: 1, type: 'course', description: 'Apply Python to data analysis and machine learning.' },
    { id: '3', name: 'Machine Learning Basics', group: 2, type: 'course', description: 'Core concepts of machine learning algorithms.' },
    { id: '4', name: 'Deep Learning', group: 2, type: 'course', description: 'Neural networks and advanced models.' },
    { id: '5', name: 'Python', group: 3, type: 'skill', description: 'Programming language.' },
    { id: '6', name: 'Data Analysis', group: 3, type: 'skill', description: 'Extracting insights from data.' },
    { id: '7', name: 'Neural Networks', group: 3, type: 'skill', description: 'Brain-inspired computing architecture.' },
    { id: '8', name: 'Web Dev Basics', group: 4, type: 'course', description: 'HTML, CSS, JS.' },
    { id: '9', name: 'React Development', group: 4, type: 'course', description: 'Build modern UIs with React.' }
  ],
  links: [
    { source: '1', target: '2', value: 2 },
    { source: '2', target: '3', value: 2 },
    { source: '3', target: '4', value: 2 },
    { source: '5', target: '1', value: 1 },
    { source: '5', target: '2', value: 1 },
    { source: '6', target: '2', value: 1 },
    { source: '7', target: '4', value: 1 },
    { source: '8', target: '9', value: 2 }
  ]
};
