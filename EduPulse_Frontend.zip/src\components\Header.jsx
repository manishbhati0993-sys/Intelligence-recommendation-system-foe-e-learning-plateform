import React, { useState } from 'react';
import {
  Sparkles,
  LayoutDashboard,
  GraduationCap,
  Briefcase,
  Building2,
  Cpu,
  Bell,
  Sun,
  Moon,
  Search,
  CheckCircle2,
  ChevronDown,
  User,
  ShieldAlert,
  Compass,
  FileCheck,
  BarChart3,
  Bot,
  Settings,
  ShieldCheck,
  ArrowRight,
  Menu,
  X
} from 'lucide-react';
import { USER_ROLES } from '../data/portalData';

export default function Header({
  activeTab,
  setActiveTab,
  activeRole,
  onRoleChange,
  currentUser,
  unreadNotificationsCount,
  onOpenNotifications,
  onOpenAuth,
  onOpenSettings,
  theme,
  toggleTheme
}) {
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const roles = [
    { role: USER_ROLES.STUDENT, label: 'Student Persona', desc: 'Aarav Sharma (NITK)', icon: User, badgeColor: 'text-cyan-400 bg-cyan-500/10' },
    { role: USER_ROLES.INDUSTRY, label: 'Industry Recruiter', desc: 'Infosys Innovation Labs', icon: Building2, badgeColor: 'text-blue-400 bg-blue-500/10' },
    { role: USER_ROLES.COLLEGE, label: 'College / TPO Head', desc: 'Dr. Ramesh (NITK TPO)', icon: GraduationCap, badgeColor: 'text-emerald-400 bg-emerald-500/10' },
    { role: USER_ROLES.ADMIN, label: 'SIH Central Cell', desc: 'Super Administrator', icon: ShieldCheck, badgeColor: 'text-amber-400 bg-amber-500/10' }
  ];

  const currentRoleObj = roles.find(r => r.role === activeRole) || roles[0];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/85 border-b border-slate-800/80 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        {/* Left: Brand Logo & SIH Subtitle */}
        <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => setActiveTab('landing')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-lg sm:text-xl tracking-tight text-white">
                Skill<span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">Bridge</span>
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-black rounded-full bg-blue-500/10 text-cyan-400 border border-cyan-500/25">
                SIH 2026
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium hidden sm:block">
              by <span className="text-slate-300 font-semibold">Team Terminal Titan</span>
            </p>
          </div>
        </div>

        {/* Center: Dynamic Navigation Links based on active role */}
        <nav className="hidden lg:flex items-center gap-1">
          <button
            onClick={() => setActiveTab('landing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'landing'
                ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            Overview
          </button>

          {activeRole === USER_ROLES.STUDENT && (
            <>
              <button
                onClick={() => setActiveTab('student_dashboard')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'student_dashboard'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" /> Dashboard
              </button>

              <button
                onClick={() => setActiveTab('skill_assessment')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'skill_assessment'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <FileCheck className="w-3.5 h-3.5" /> Skill Lab
              </button>

              <button
                onClick={() => setActiveTab('skill_analysis')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'skill_analysis'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Compass className="w-3.5 h-3.5" /> Skill Gap
              </button>

              <button
                onClick={() => setActiveTab('learning_roadmap')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'learning_roadmap'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" /> AI Pathway
              </button>

              <button
                onClick={() => setActiveTab('marketplace')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'marketplace'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Briefcase className="w-3.5 h-3.5" /> Internships
              </button>

              <button
                onClick={() => setActiveTab('applications')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'applications'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                Applications
              </button>
            </>
          )}

          {activeRole === USER_ROLES.INDUSTRY && (
            <>
              <button
                onClick={() => setActiveTab('industry_dashboard')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'industry_dashboard'
                    ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" /> Pipeline HUD
              </button>

              <button
                onClick={() => setActiveTab('candidate_matching')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'candidate_matching'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" /> Matched Talent
              </button>

              <button
                onClick={() => setActiveTab('marketplace')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'marketplace'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Briefcase className="w-3.5 h-3.5" /> Openings
              </button>
            </>
          )}

          {activeRole === USER_ROLES.COLLEGE && (
            <>
              <button
                onClick={() => setActiveTab('college_dashboard')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'college_dashboard'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" /> TPO Dashboard
              </button>

              <button
                onClick={() => setActiveTab('college_analytics')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'college_analytics'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" /> Curriculum Gap
              </button>

              <button
                onClick={() => setActiveTab('industry_collaboration')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'industry_collaboration'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" /> Industry MoUs
              </button>
            </>
          )}

          {activeRole === USER_ROLES.ADMIN && (
            <button
              onClick={() => setActiveTab('admin_panel')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                activeTab === 'admin_panel'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" /> SIH Admin
            </button>
          )}

          {/* Ask AI Assistant shortcut */}
          <button
            onClick={() => setActiveTab('ai_chatbot')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'ai_chatbot'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-emerald-400 hover:bg-emerald-950/40 border border-emerald-500/30'
            }`}
          >
            <Bot className="w-3.5 h-3.5" /> Ask AI
          </button>
        </nav>

        {/* Right Action Toolbar: Role Switcher + Notifications + Settings + Auth */}
        <div className="flex items-center gap-2">
          
          {/* Interactive Persona Dropdown Switcher */}
          <div className="relative">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold transition"
            >
              <span className={`w-2 h-2 rounded-full ${
                activeRole === USER_ROLES.STUDENT ? 'bg-cyan-400' :
                activeRole === USER_ROLES.INDUSTRY ? 'bg-blue-400' :
                activeRole === USER_ROLES.COLLEGE ? 'bg-emerald-400' : 'bg-amber-400'
              }`}></span>
              <span className="text-white hidden md:inline capitalize">{activeRole} View</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {isRoleDropdownOpen && (
              <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Switch SIH Stakeholder Persona
                </div>
                {roles.map((r) => {
                  const Icon = r.icon;
                  return (
                    <button
                      key={r.role}
                      onClick={() => {
                        onRoleChange(r.role);
                        setIsRoleDropdownOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 p-2.5 rounded-xl text-left transition ${
                        activeRole === r.role ? 'bg-slate-800 text-white font-bold' : 'hover:bg-slate-800/60 text-slate-300'
                      }`}
                    >
                      <div className={`p-1.5 rounded-lg ${r.badgeColor}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs font-bold">{r.label}</div>
                        <div className="text-[10px] text-slate-400">{r.desc}</div>
                      </div>
                      {activeRole === r.role && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Notifications Trigger */}
          <button
            onClick={onOpenNotifications}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 relative transition border border-transparent hover:border-slate-800"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-slate-950"></span>
            )}
          </button>

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 transition border border-transparent hover:border-slate-800"
            title="Platform Settings & Preferences"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 transition border border-transparent hover:border-slate-800"
            title="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* User Profile / Auth Button */}
          <button
            onClick={onOpenAuth}
            className="hidden sm:flex items-center gap-2 pl-2 pr-3 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 transition"
          >
            <img
              src={currentUser?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80"}
              alt="User"
              className="w-7 h-7 rounded-lg object-cover border border-cyan-500/30"
            />
            <div className="text-left hidden xl:block">
              <div className="text-xs font-bold text-white line-clamp-1">{currentUser?.name || "Sign In"}</div>
              <div className="text-[10px] text-slate-400 capitalize">{activeRole}</div>
            </div>
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 transition"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

        </div>

      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-950 p-4 space-y-2 animate-in slide-in-from-top">
          <button
            onClick={() => { setActiveTab('landing'); setIsMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900"
          >
            Overview
          </button>
          {activeRole === USER_ROLES.STUDENT && (
            <>
              <button
                onClick={() => { setActiveTab('student_dashboard'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-cyan-400 hover:bg-slate-900 flex items-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4" /> Student Dashboard
              </button>
              <button
                onClick={() => { setActiveTab('skill_assessment'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900 flex items-center gap-2"
              >
                <FileCheck className="w-4 h-4" /> Skill Assessment Lab
              </button>
              <button
                onClick={() => { setActiveTab('skill_analysis'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900 flex items-center gap-2"
              >
                <Compass className="w-4 h-4" /> AI Skill Gap Analysis
              </button>
              <button
                onClick={() => { setActiveTab('learning_roadmap'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900 flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" /> Personalized Career Pathway
              </button>
              <button
                onClick={() => { setActiveTab('marketplace'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900 flex items-center gap-2"
              >
                <Briefcase className="w-4 h-4" /> Smart Matched Internships
              </button>
            </>
          )}

          {activeRole === USER_ROLES.INDUSTRY && (
            <>
              <button
                onClick={() => { setActiveTab('industry_dashboard'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-blue-400 hover:bg-slate-900 flex items-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4" /> Industry Recruiter Dashboard
              </button>
              <button
                onClick={() => { setActiveTab('candidate_matching'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900 flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" /> Pre-Vetted Talent Pool
              </button>
            </>
          )}

          {activeRole === USER_ROLES.COLLEGE && (
            <>
              <button
                onClick={() => { setActiveTab('college_dashboard'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-emerald-400 hover:bg-slate-900 flex items-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4" /> TPO Institution Portal
              </button>
              <button
                onClick={() => { setActiveTab('college_analytics'); setIsMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-900 flex items-center gap-2"
              >
                <BarChart3 className="w-4 h-4" /> Curriculum Skill Heatmaps
              </button>
            </>
          )}

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <button
              onClick={() => { onOpenSettings(); setIsMobileMenuOpen(false); }}
              className="px-3 py-1.5 rounded-lg bg-slate-900 text-xs font-semibold text-slate-300 flex items-center gap-1.5"
            >
              <Settings className="w-3.5 h-3.5" /> Settings
            </button>
            <button
              onClick={() => { onOpenAuth(); setIsMobileMenuOpen(false); }}
              className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs"
            >
              Sign In / Switch
            </button>
          </div>
        </div>
      )}

    </header>
  );
}
