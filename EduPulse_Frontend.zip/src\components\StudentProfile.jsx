import React, { useState } from 'react';
import {
  User,
  GraduationCap,
  Award,
  Briefcase,
  FileText,
  Upload,
  Plus,
  Trash2,
  CheckCircle2,
  ExternalLink,
  Github,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

export default function StudentProfile({ currentUser, onUpdateProfile }) {
  const [profile, setProfile] = useState(currentUser || {});
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillCategory, setNewSkillCategory] = useState('Backend');
  const [newSkillLevel, setNewSkillLevel] = useState(75);
  const [resumeUploaded, setResumeUploaded] = useState(true);

  const handleAddSkill = () => {
    if (!newSkillName.trim()) return;
    const newSkill = {
      name: newSkillName.trim(),
      category: newSkillCategory,
      level: Number(newSkillLevel),
      verified: false
    };
    const updatedSkills = [...(profile.skills || []), newSkill];
    const updated = { ...profile, skills: updatedSkills };
    setProfile(updated);
    if (onUpdateProfile) onUpdateProfile(updated);
    setNewSkillName('');
  };

  const handleRemoveSkill = (skillIndex) => {
    const updatedSkills = profile.skills.filter((_, idx) => idx !== skillIndex);
    const updated = { ...profile, skills: updatedSkills };
    setProfile(updated);
    if (onUpdateProfile) onUpdateProfile(updated);
  };

  return (
    <div class="space-y-8 py-4 max-w-6xl mx-auto">
      
      {/* Profile Header Card */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div class="flex items-center gap-5">
            <div class="relative">
              <img
                src={profile.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                alt={profile.name}
                class="w-20 h-20 rounded-2xl object-cover border-2 border-cyan-400 shadow-xl"
              />
              <span class="absolute -bottom-1 -right-1 p-1 bg-emerald-500 rounded-full border-2 border-slate-900" title="Verified Profile">
                <CheckCircle2 class="w-3.5 h-3.5 text-slate-950 font-bold" />
              </span>
            </div>
            <div>
              <h2 class="text-2xl font-extrabold text-white">{profile.name}</h2>
              <p class="text-xs text-cyan-400 font-semibold">{profile.degree} • {profile.department}</p>
              <p class="text-xs text-slate-400">{profile.college} ({profile.location})</p>
            </div>
          </div>

          <div class="flex items-center gap-3">
            <div class="px-4 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div class="text-[10px] text-slate-400 uppercase font-bold">Cumulative CGPA</div>
              <div class="text-lg font-black text-emerald-400">{profile.cgpa} / 10.0</div>
            </div>
            <div class="px-4 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div class="text-[10px] text-slate-400 uppercase font-bold">Batch Year</div>
              <div class="text-lg font-black text-cyan-400">{profile.graduationYear}</div>
            </div>
          </div>
        </div>

        <p class="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
          "{profile.bio}"
        </p>
      </div>

      {/* Grid: Skills Management & Resume Upload */}
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left 7 Columns: Skills & Competencies */}
        <div class="lg:col-span-7 space-y-6">
          
          <div class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-5">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-bold text-white flex items-center gap-2">
                  <Award class="w-5 h-5 text-cyan-400" /> Technical & Soft Skills
                </h3>
                <p class="text-xs text-slate-400">Add proficiencies to improve your AI Opportunity Match score</p>
              </div>
              <span class="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 font-bold">
                {profile.skills?.length || 0} Skills
              </span>
            </div>

            {/* Add Skill Form */}
            <div class="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
              <div class="text-xs font-bold uppercase tracking-wider text-slate-300">Add New Competency</div>
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="Skill name (e.g. Docker, Spring Boot)..."
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                  class="px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
                <select
                  value={newSkillCategory}
                  onChange={(e) => setNewSkillCategory(e.target.value)}
                  class="px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none"
                >
                  <option value="Backend">Backend</option>
                  <option value="Frontend">Frontend</option>
                  <option value="Database">Database</option>
                  <option value="DevOps">DevOps</option>
                  <option value="AI/ML">AI/ML</option>
                  <option value="Soft Skill">Soft Skill</option>
                </select>
                <button
                  type="button"
                  onClick={handleAddSkill}
                  class="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-1"
                >
                  <Plus class="w-3.5 h-3.5" /> Add Skill
                </button>
              </div>
            </div>

            {/* Skills List */}
            <div class="space-y-3">
              {profile.skills?.map((sk, idx) => (
                <div
                  key={idx}
                  class="p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between gap-4"
                >
                  <div class="flex-1">
                    <div class="flex items-center justify-between text-xs mb-1">
                      <span class="font-bold text-white flex items-center gap-1.5">
                        {sk.name}
                        {sk.verified ? (
                          <span class="text-[10px] text-emerald-400 font-medium flex items-center gap-0.5">
                            <CheckCircle2 class="w-3 h-3" /> Verified
                          </span>
                        ) : (
                          <span class="text-[10px] text-slate-400">Self-reported</span>
                        )}
                      </span>
                      <span class="font-mono font-bold text-cyan-400">{sk.level}%</span>
                    </div>
                    <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        class={`h-full rounded-full ${
                          sk.level >= 80 ? 'bg-emerald-500' : sk.level >= 60 ? 'bg-cyan-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${sk.level}%` }}
                      ></div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleRemoveSkill(idx)}
                    class="p-1.5 text-slate-500 hover:text-rose-400 transition"
                    title="Remove skill"
                  >
                    <Trash2 class="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

          </div>

        </div>

        {/* Right 5 Columns: Resume Upload & Certifications */}
        <div class="lg:col-span-5 space-y-6">
          
          {/* Resume Upload Box */}
          <div class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <div class="flex items-center justify-between">
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <FileText class="w-4 h-4 text-cyan-400" /> Digital Resume (ATS Vetted)
              </h3>
              <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                ATS Score: 92/100
              </span>
            </div>

            <div class="p-4 rounded-xl border-2 border-dashed border-slate-800 hover:border-cyan-500/40 text-center space-y-3 transition">
              <div class="w-10 h-10 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto">
                <Upload class="w-5 h-5" />
              </div>
              <div>
                <p class="text-xs font-bold text-white">Aarav_Sharma_Resume_Verified.pdf</p>
                <p class="text-[10px] text-slate-400">PDF format • 1.2 MB • Verified by TPO NITK</p>
              </div>
              <button
                onClick={() => alert("Resume re-uploaded and parsed with AI entity extraction!")}
                class="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
              >
                Upload Updated CV
              </button>
            </div>
          </div>

          {/* Certifications List */}
          <div class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck class="w-4 h-4 text-amber-400" /> Verified Certifications
            </h3>

            <div class="space-y-3">
              {profile.certifications?.map((cert) => (
                <div key={cert.id} class="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                  <div class="text-xs font-bold text-white">{cert.title}</div>
                  <div class="text-[11px] text-cyan-400 font-medium">{cert.issuer} • {cert.date}</div>
                  <div class="text-[10px] text-slate-400 font-mono">ID: {cert.credentialId}</div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Projects Showcase Section */}
      <div class="p-6 sm:p-8 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-6">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-lg font-bold text-white flex items-center gap-2">
              <Briefcase class="w-5 h-5 text-cyan-400" /> Showcase Projects & Repositories
            </h3>
            <p class="text-xs text-slate-400">Production-ready applications demonstrating verified skills</p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          {profile.projects?.map((prj) => (
            <div key={prj.id} class="p-5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
              <div class="flex items-center justify-between">
                <h4 class="text-sm font-bold text-white">{prj.title}</h4>
                <div class="flex items-center gap-2">
                  {prj.github && (
                    <a href={prj.github} target="_blank" rel="noreferrer" class="text-slate-400 hover:text-white transition">
                      <Github class="w-4 h-4" />
                    </a>
                  )}
                  {prj.demo && (
                    <a href={prj.demo} target="_blank" rel="noreferrer" class="text-cyan-400 hover:text-cyan-300 transition">
                      <ExternalLink class="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>

              <p class="text-xs text-slate-300 leading-relaxed">{prj.description}</p>

              <div class="flex flex-wrap gap-1.5 pt-2">
                {prj.techStack.map((tech, idx) => (
                  <span key={idx} class="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-cyan-300 font-semibold">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
