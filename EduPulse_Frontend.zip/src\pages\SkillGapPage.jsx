import React, { useState } from 'react';
import {
  GitMerge,
  Target,
  Sparkles,
  TrendingUp,
  Award,
  CheckCircle2,
  Clock,
  ArrowRight,
  AlertCircle,
  BrainCircuit,
  Lock,
  Play,
  Layers,
  ChevronRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';
import SkillRadarChart from '../components/SkillRadarChart';
import ProgressBar from '../components/ProgressBar';
import { careerRolesData, coursesData } from '../data/mockData';
import { calculateSkillGapAnalysis } from '../services/recommendationEngine';

export default function SkillGapPage({
  user,
  onSelectCourse,
  onShowToast,
  onUpdateTargetRole,
}) {
  const [selectedRoleName, setSelectedRoleName] = useState(
    user.targetRole || 'AI / Machine Learning Engineer'
  );

  const analysis = calculateSkillGapAnalysis(user.skillCompetencies, selectedRoleName);
  const activeRole = analysis.role;

  // Prepare Gap Bar Chart data
  const gapChartData = analysis.gapBreakdown.map((item) => ({
    name: item.skill.split(' ')[0] + ' ' + (item.skill.split(' ')[1] || ''),
    'Current Score': item.currentScore,
    'Target Requirement': item.targetScore,
    Gap: item.gap,
  }));

  const handleRoleChange = (roleName) => {
    setSelectedRoleName(roleName);
    onUpdateTargetRole?.(roleName);
    onShowToast?.({
      type: 'ai',
      title: 'Target Role Realigned',
      message: `Competency benchmarks and learning path recalculated for ${roleName}.`,
    });
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Top Banner: Role Selection & Overall Readiness Index */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-300 text-xs font-bold">
              <GitMerge className="w-3.5 h-3.5" />
              <span>Adaptive AI Competency Mapping</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
              Skill Gap & Career Roadmap
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Compare your assessed skill vectors against industry-standard role benchmarks. EduPulse AI constructs an optimized step-by-step sequence to bridge critical deficits in minimal time.
            </p>
          </div>

          {/* Readiness Score Card */}
          <div className="p-5 rounded-2xl bg-slate-950/90 border border-indigo-500/30 flex items-center gap-5 flex-shrink-0">
            <div className="relative w-16 h-16 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-800"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-emerald-400"
                  strokeDasharray={`${analysis.overallReadinessIndex}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-sm font-extrabold text-slate-100 font-mono">
                {analysis.overallReadinessIndex}%
              </span>
            </div>

            <div>
              <p className="text-xs font-bold text-slate-100">Role Readiness Index</p>
              <p className="text-[11px] text-emerald-400 font-medium mt-0.5">
                {analysis.overallReadinessIndex >= 85
                  ? 'Ready for Senior Interviews'
                  : analysis.overallReadinessIndex >= 70
                  ? 'Strong Intermediate Foundation'
                  : 'Foundations in Progress'}
              </p>
              <p className="text-[10px] text-slate-500 mt-1">
                Average Salary: <span className="text-slate-300 font-mono">{activeRole.avgSalary}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Role Selector Tabs */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-wrap items-center gap-3">
          <span className="text-xs font-semibold text-slate-400 mr-2 flex items-center gap-1.5">
            <Target className="w-4 h-4 text-indigo-400" />
            Switch Career Path:
          </span>
          {careerRolesData.map((role) => (
            <button
              key={role.id}
              onClick={() => handleRoleChange(role.name)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                selectedRoleName === role.name
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              <span>{role.name}</span>
              <span className="text-[10px] font-mono opacity-80 font-normal">
                ({role.demandGrowth})
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Visual Skill Maps Grid (Radar Chart & Bar Comparison) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Recharts Radar Vector Map */}
        <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
                <BrainCircuit className="w-4 h-4 text-indigo-400" />
                <span>Multidimensional Competency Radar</span>
              </h3>
              <p className="text-xs text-slate-400">Current Assessed Vector vs Target Requirement</p>
            </div>
            <span className="text-xs font-mono text-indigo-400 font-bold bg-indigo-500/10 px-2.5 py-1 rounded-lg border border-indigo-500/20">
              6 Dimensions
            </span>
          </div>

          <div className="pt-2">
            <SkillRadarChart
              data={analysis.gapBreakdown}
              roleTitle={activeRole.name}
              height={320}
              showCohort={true}
            />
          </div>
        </div>

        {/* Right: Recharts Bar Chart Breakdown */}
        <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-teal-400" />
                <span>Competency Deficit Analysis</span>
              </h3>
              <p className="text-xs text-slate-400">Scores out of 100 with required delta</p>
            </div>
          </div>

          <div className="w-full h-80 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={gapChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis
                  dataKey="name"
                  stroke="#64748b"
                  fontSize={10}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#64748b" fontSize={10} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '11px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="Current Score" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Target Requirement" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Competency Gap Matrix Breakdown Table */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-100 text-base">
              Competency Deficit & Priority Matrix
            </h3>
            <p className="text-xs text-slate-400">
              Sorted by highest skill deficit for <span className="text-indigo-400 font-semibold">{selectedRoleName}</span>
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 rounded-l-xl">Skill Dimension</th>
                <th className="py-3 px-3">Current Score</th>
                <th className="py-3 px-3">Target Required</th>
                <th className="py-3 px-3">Deficit Gap</th>
                <th className="py-3 px-3">Importance</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right rounded-r-xl">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {analysis.prioritizedGaps.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-200">{item.skill}</td>
                  <td className="py-3.5 px-3 font-mono text-indigo-400">{item.currentScore}/100</td>
                  <td className="py-3.5 px-3 font-mono text-emerald-400">{item.targetScore}/100</td>
                  <td className="py-3.5 px-3">
                    {item.gap > 0 ? (
                      <span className="font-mono text-rose-400 font-bold">-{item.gap} pts</span>
                    ) : (
                      <span className="font-mono text-emerald-400 font-bold">✓ Complete</span>
                    )}
                  </td>
                  <td className="py-3.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.importance === 'Critical'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : item.importance === 'High'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.importance}
                    </span>
                  </td>
                  <td className="py-3.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.status === 'Mastered'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : item.status === 'Near Target'
                          ? 'bg-cyan-500/20 text-cyan-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {item.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => {
                        // Find matching course for this skill
                        const course = coursesData.find((c) =>
                          c.skillsTaught.includes(item.skill)
                        );
                        if (course) onSelectCourse?.(course);
                      }}
                      className="px-3 py-1 rounded-xl bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-bold transition-all"
                    >
                      Bridge Gap →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Suggested Step-by-Step Learning Path Roadmap */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-1 rounded-lg bg-indigo-500/20 text-indigo-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <h2 className="text-xl font-bold text-slate-100">
                AI-Generated Learning Roadmap
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Follow this optimized sequence of milestones to achieve 100% readiness for {selectedRoleName}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span>Estimated Total Time: <strong>~22 weeks</strong></span>
          </div>
        </div>

        {/* Milestone Sequence Timeline */}
        <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
          {(activeRole.learningPath || []).map((stepItem, idx) => {
            const courseObj = coursesData.find((c) => c.id === stepItem.courseId);
            const isCompleted = stepItem.status === 'completed';
            const isInProgress = stepItem.status === 'in-progress';
            const isRecommendedNext = stepItem.status === 'recommended-next';
            const isLocked = stepItem.status === 'locked';

            return (
              <div key={idx} className="relative group">
                {/* Timeline Node Icon */}
                <div
                  className={`absolute -left-6 sm:-left-8 top-1.5 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-transform ${
                    isCompleted
                      ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30 ring-4 ring-slate-900'
                      : isInProgress
                      ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/30 ring-4 ring-slate-900 animate-pulse'
                      : isRecommendedNext
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30 ring-4 ring-slate-900'
                      : 'bg-slate-800 text-slate-400 ring-4 ring-slate-900'
                  }`}
                >
                  {isCompleted ? '✓' : stepItem.step}
                </div>

                {/* Milestone Card */}
                <div
                  className={`p-5 rounded-2xl border transition-all ${
                    isRecommendedNext
                      ? 'bg-gradient-to-r from-indigo-950/70 via-slate-900 to-slate-900 border-indigo-500/50 shadow-xl shadow-indigo-500/10'
                      : isCompleted
                      ? 'bg-slate-900/60 border-slate-800/80 opacity-90'
                      : 'bg-slate-900/90 border-slate-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono font-bold text-indigo-400 uppercase">
                        Milestone {stepItem.step}
                      </span>
                      <span className="text-slate-500">•</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isCompleted
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : isInProgress
                            ? 'bg-indigo-500/20 text-indigo-300'
                            : isRecommendedNext
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {isCompleted
                          ? 'Completed'
                          : isInProgress
                          ? `In Progress (${stepItem.progress}%)`
                          : isRecommendedNext
                          ? '⭐ Recommended Next Action'
                          : 'Locked (Requires Step ' + (stepItem.step - 1) + ')'}
                      </span>
                    </div>

                    <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      {stepItem.estimatedWeeks} weeks
                    </span>
                  </div>

                  <h4 className="font-bold text-slate-100 text-base mb-1">
                    {stepItem.milestone}
                  </h4>

                  <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                    {stepItem.description}
                  </p>

                  {/* Course Attached Card */}
                  {courseObj && (
                    <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={courseObj.thumbnail}
                          alt={courseObj.title}
                          className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-200 truncate">{courseObj.title}</p>
                          <p className="text-[11px] text-slate-400">
                            {courseObj.duration} • {courseObj.level} • {courseObj.rating} ★
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => onSelectCourse?.(courseObj)}
                        className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 flex-shrink-0 ${
                          isCompleted
                            ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                            : isRecommendedNext
                            ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                        }`}
                      >
                        <span>{isCompleted ? 'Review Modules' : 'View Milestone Course'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
