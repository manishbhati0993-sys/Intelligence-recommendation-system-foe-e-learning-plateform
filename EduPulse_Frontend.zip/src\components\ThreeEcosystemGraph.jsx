import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Sparkles, Activity, Layers, ArrowUpRight, Zap, Target, Search } from 'lucide-react';

export default function ThreeEcosystemGraph({ onSelectSkill, skillBenchmarks = [] }) {
  const mountRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [graphFilter, setGraphFilter] = useState('All');

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene & Camera Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0f1d, 0.025);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 5, 24);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x0a0f1d, 1);
    container.appendChild(renderer.domElement);

    // 2. Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x06b6d4, 3, 100);
    pointLight.position.set(10, 15, 10);
    scene.add(pointLight);

    const emeraldLight = new THREE.PointLight(0x10b981, 2, 80);
    emeraldLight.position.set(-10, -10, -10);
    scene.add(emeraldLight);

    // 3. Glowing Central Hub (Ayush Industry Portal Core)
    const coreGeo = new THREE.IcosahedronGeometry(2.2, 2);
    const coreMat = new THREE.MeshPhongMaterial({
      color: 0x06b6d4,
      emissive: 0x0369a1,
      wireframe: true,
      transparent: true,
      opacity: 0.85
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    scene.add(coreMesh);

    // Inner glowing sphere
    const innerGeo = new THREE.SphereGeometry(1.4, 32, 32);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.6
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    coreMesh.add(innerMesh);

    // 4. Create 3D Nodes for Skills & Industry Partners
    const nodes = [
      { id: 'n1', label: 'Ayurvedic Pharmacognosy', type: 'Skill', category: 'Ayush Science', gap: 16, demand: 92, pos: [6, 3, 4], color: 0x10b981 },
      { id: 'n2', label: 'AI in Phytochemistry', type: 'Skill', category: 'HealthTech & AI', gap: 46, demand: 88, pos: [-7, 4, 3], color: 0x06b6d4 },
      { id: 'n3', label: 'Clinical Trials (AYUSH GCP)', type: 'Skill', category: 'Regulatory', gap: 27, demand: 85, pos: [4, -5, 5], color: 0xf59e0b },
      { id: 'n4', label: 'HPLC & Spectroscopy', type: 'Skill', category: 'Lab & Research', gap: 22, demand: 90, pos: [-5, -4, -3], color: 0x8b5cf6 },
      { id: 'n5', label: 'GMP Manufacturing Standards', type: 'Skill', category: 'Manufacturing', gap: 17, demand: 89, pos: [7, -2, -6], color: 0xec4899 },
      { id: 'n6', label: 'Bioinformatics & Docking', type: 'Skill', category: 'HealthTech & AI', gap: 34, demand: 82, pos: [-7, 1, -7], color: 0x3b82f6 },
      { id: 'n7', label: 'Dabur Ayush Research Labs', type: 'Industry', category: 'Phytomedicine R&D', demand: 95, pos: [11, 2, -2], color: 0x10b981 },
      { id: 'n8', label: 'Patanjali BioResearch', type: 'Industry', category: 'HealthTech & AI', demand: 90, pos: [-11, 5, 2], color: 0x06b6d4 },
      { id: 'n9', label: 'Himalaya Wellness Co.', type: 'Industry', category: 'Clinical Operations', demand: 88, pos: [8, -7, 1], color: 0xf59e0b },
      { id: 'n10', label: 'CSIR-CIMAP Research', type: 'Academic', category: 'FDP & Grants', demand: 92, pos: [-9, -6, 4], color: 0x8b5cf6 }
    ];

    const nodeMeshes = [];
    const lineGroup = new THREE.Group();
    scene.add(lineGroup);

    nodes.forEach((node) => {
      const radius = node.type === 'Industry' ? 1.1 : 0.8;
      const geo = new THREE.SphereGeometry(radius, 24, 24);
      const mat = new THREE.MeshStandardMaterial({
        color: node.color,
        emissive: node.color,
        emissiveIntensity: 0.4,
        roughness: 0.2,
        metalness: 0.5
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(...node.pos);
      mesh.userData = node;
      scene.add(mesh);
      nodeMeshes.push(mesh);

      // Connect Node to Core Hub with energy line
      const points = [];
      points.push(new THREE.Vector3(0, 0, 0));
      points.push(new THREE.Vector3(...node.pos));

      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineBasicMaterial({
        color: node.color,
        transparent: true,
        opacity: 0.35
      });
      const line = new THREE.Line(lineGeo, lineMat);
      lineGroup.add(line);
    });

    // 5. Ambient 3D Particle Cloud
    const particleCount = 200;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 50;
      particlePositions[i + 1] = (Math.random() - 0.5) * 50;
      particlePositions[i + 2] = (Math.random() - 0.5) * 50;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.15,
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.5
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    scene.add(particleSystem);

    // 6. Interactive Raycasting & Mouse Dragging
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const handlePointerDown = (e) => {
      isDragging = true;
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const handlePointerMove = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

      if (isDragging) {
        const deltaX = e.clientX - previousMousePosition.x;
        const deltaY = e.clientY - previousMousePosition.y;

        scene.rotation.y += deltaX * 0.005;
        scene.rotation.x += deltaY * 0.005;

        previousMousePosition = { x: e.clientX, y: e.clientY };
      }

      // Check Hovering
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(nodeMeshes);

      if (intersects.length > 0) {
        container.style.cursor = 'pointer';
        setHoveredNode(intersects[0].object.userData);
      } else {
        container.style.cursor = 'grab';
        setHoveredNode(null);
      }
    };

    const handlePointerUp = () => {
      isDragging = false;
    };

    const handleClick = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(nodeMeshes);

      if (intersects.length > 0) {
        const node = intersects[0].object.userData;
        setSelectedNode(node);
        if (onSelectSkill && node.type === 'Skill') {
          onSelectSkill(node.label);
        }
      }
    };

    container.addEventListener('pointerdown', handlePointerDown);
    container.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    container.addEventListener('click', handleClick);

    // 7. Animation Loop
    let animationFrameId;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Rotate core hub
      coreMesh.rotation.y = elapsedTime * 0.3;
      coreMesh.rotation.x = elapsedTime * 0.15;
      particleSystem.rotation.y = elapsedTime * 0.05;

      // Pulse node meshes
      nodeMeshes.forEach((mesh, idx) => {
        mesh.position.y += Math.sin(elapsedTime * 2 + idx) * 0.003;
      });

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('pointerdown', handlePointerDown);
      container.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      container.removeEventListener('click', handleClick);
      window.removeEventListener('resize', handleResize);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative w-full h-[520px] rounded-2xl overflow-hidden glass-panel border border-cyan-500/30 bg-slate-950/80 shadow-2xl">
      
      {/* 3D WebGL Canvas Mount */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Overlay Bar */}
      <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        
        <div className="flex items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-cyan-500/30 pointer-events-auto">
          <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            3D Skill & Industry Constellation Graph
          </span>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1 rounded-xl border border-slate-700 pointer-events-auto">
          {['All', 'Ayush Science', 'HealthTech & AI', 'Regulatory'].map((cat) => (
            <button
              key={cat}
              onClick={() => setGraphFilter(cat)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition ${
                graphFilter === cat
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* Interactive Controls Overlay Hint */}
      <div className="absolute bottom-4 left-4 pointer-events-none flex items-center gap-2 text-[11px] text-slate-400 bg-slate-950/75 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800">
        <Zap className="w-3.5 h-3.5 text-emerald-400" />
        <span>Drag mouse to rotate 3D graph • Click node to inspect gap metrics</span>
      </div>

      {/* Hover Node Tooltip */}
      {hoveredNode && !selectedNode && (
        <div className="absolute bottom-16 left-4 bg-slate-900/95 backdrop-blur-md border border-cyan-500/50 p-3 rounded-xl shadow-xl pointer-events-none animate-fade-in space-y-1">
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${hoveredNode.type === 'Industry' ? 'bg-cyan-400' : 'bg-emerald-400'}`} />
            <h4 className="text-xs font-bold text-white">{hoveredNode.label}</h4>
          </div>
          <p className="text-[10px] text-slate-400">{hoveredNode.category} • {hoveredNode.type}</p>
        </div>
      )}

      {/* Selected Node Details Popup Card */}
      {selectedNode && (
        <div className="absolute bottom-4 right-4 max-w-sm w-full bg-slate-900/95 backdrop-blur-xl border border-cyan-500/40 p-4 rounded-2xl shadow-2xl space-y-3 animate-fade-in">
          
          <div className="flex items-start justify-between">
            <div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                selectedNode.type === 'Industry' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-emerald-500/20 text-emerald-400'
              }`}>
                {selectedNode.type} Node
              </span>
              <h3 className="text-base font-bold text-white mt-1">{selectedNode.label}</h3>
              <p className="text-xs text-slate-400">{selectedNode.category}</p>
            </div>

            <button
              onClick={() => setSelectedNode(null)}
              className="text-slate-400 hover:text-white text-xs font-bold px-1.5 py-0.5 rounded bg-slate-800"
            >
              ✕
            </button>
          </div>

          {selectedNode.type === 'Skill' && (
            <div className="space-y-2 pt-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Industry Demand:</span>
                <span className="font-bold text-cyan-400">{selectedNode.demand}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Skill Gap Level:</span>
                <span className="font-bold text-amber-400">-{selectedNode.gap}% Gap</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-emerald-400 to-cyan-500 h-full transition-all"
                  style={{ width: `${selectedNode.demand}%` }}
                />
              </div>
            </div>
          )}

          {selectedNode.type === 'Industry' && (
            <div className="text-xs text-slate-300 space-y-1">
              <p>📍 Key Ayush R&D Partner Hub</p>
              <p>💼 6+ Active Internships & Research Projects</p>
            </div>
          )}

          <div className="pt-2 flex items-center gap-2">
            <button
              onClick={() => {
                if (onSelectSkill) onSelectSkill(selectedNode.label);
                setSelectedNode(null);
              }}
              className="w-full py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-400 text-slate-950 font-extrabold text-xs hover:opacity-95 transition flex items-center justify-center gap-1.5 shadow-md"
            >
              <span>Explore Matching Internships</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      )}

    </div>
  );
}
