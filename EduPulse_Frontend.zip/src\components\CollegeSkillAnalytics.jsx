import React from 'react';
import {
  BarChart3,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Sparkles,
  Layers,
  Award
} from 'lucide-react';
import { SKILL_BENCHMARKS } from '../data/portalData';

export default function CollegeSkillAnalytics({ setActiveTab }) {
  return (
    <div class="max-w-6xl mx-auto py-4 space-y-6">
      
      {/* Header */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div class="flex items-center gap-2">
          <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
            Institutional Skill Analytics
          </span>
          <span class="text-xs text-slate-400">• Curriculum vs Industry Demand</span>
        </div>
        <h1 class="text-2xl sm:text-3xl font-extrabold text-white">
          Batch Skill Gap Heatmap & Deficit Radar
        </h1>
        <p class="text-xs sm:text-sm text-slate-300">
          Identify syllabus discrepancies before final placement season. Our AI aggregates 1,200+ student assessment results and benchmarks them against real-time industry recruiter searches.
        </p>
      </div>

      {/* Benchmarks Heatmap Grid */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 space-y-6">
        <h3 class="text-base font-bold text-white flex items-center gap-2">
          <Layers class="w-5 h-5 text-cyan-400" /> Technology Benchmarks: Student Average vs Industry Demand
        </h3>

        <div class="space-y-4">
          {SKILL_BENCHMARKS.map((item, idx) => {
            const gap = item.avgIndustryDemand - item.studentAvg;
            const isHighGap = gap >= 25;
            return (
              <div key={idx} class="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-white text-sm">{item.name}</span>
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                        {item.category}
                      </span>
                      <span class="text-[10px] font-bold text-cyan-400">
                        {item.growthRate}
                      </span>
                    </div>
                  </div>

                  <div class="flex items-center gap-3 text-xs font-mono">
                    <span class="text-slate-400">Batch Avg: <strong class="text-white">{item.studentAvg}%</strong></span>
                    <span class="text-slate-400">Demand: <strong class="text-emerald-400">{item.avgIndustryDemand}%</strong></span>
                    <span class={`px-2 py-0.5 rounded text-[10px] font-bold ${isHighGap ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-emerald-500/10 text-emerald-400'}`}>
                      {gap > 0 ? `${gap}% Gap` : 'Aligned'}
                    </span>
                  </div>
                </div>

                {/* Progress bar comparing student avg to industry demand */}
                <div class="space-y-1">
                  <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden relative">
                    {/* Industry Demand marker */}
                    <div
                      class="bg-slate-700 h-full absolute inset-y-0 left-0"
                      style={{ width: `${item.avgIndustryDemand}%` }}
                    ></div>
                    {/* Student current avg */}
                    <div
                      class={`h-full absolute inset-y-0 left-0 rounded-full ${
                        isHighGap ? 'bg-amber-500' : 'bg-gradient-to-r from-cyan-500 to-emerald-500'
                      }`}
                      style={{ width: `${item.studentAvg}%` }}
                    ></div>
                  </div>
                </div>

                {isHighGap && (
                  <div class="text-[11px] text-amber-300 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20 flex items-center justify-between">
                    <span class="flex items-center gap-1.5">
                      <AlertTriangle class="w-3.5 h-3.5 text-amber-400" />
                      Critical curriculum gap detected. Recommended: Organize a 2-week Faculty Development Program (FDP) on {item.name}.
                    </span>
                    <button
                      onClick={() => setActiveTab('industry_collaboration')}
                      class="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] transition shrink-0 ml-2"
                    >
                      Propose Workshop
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
