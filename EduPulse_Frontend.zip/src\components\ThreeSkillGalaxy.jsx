import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  RotateCcw,
  Maximize2,
  Minimize2,
  Brain,
  Sparkles,
  Layers,
  TrendingUp,
  Award,
  Sliders,
  CheckCircle2,
  X
} from 'lucide-react';
import { skillGalaxyData } from '../data/mockData';

export default function ThreeSkillGalaxy({
  user,
  onSelectSkill,
}) {
  const containerRef = useRef(null);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [is2DFallback, setIs2DFallback] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeCategory, setActiveCategory] = useState('All');

  // Check WebGL availability
  useEffect(() => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) {
        setIs2DFallback(true);
      }
    } catch {
      setIs2DFallback(true);
    }
  }, []);

  // Three.js Scene Setup
  useEffect(() => {
    if (is2DFallback || !containerRef.current) return;

    const width = containerRef.current.clientWidth || 800;
    const height = compact ? 360 : 480;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020617, 0.015);

    const camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 1000);
    camera.position.set(0, 15, 38);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;

    // Clear previous canvas
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 75;
    controls.minDistance = 12;

    // Ambient & Point Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const coreLight = new THREE.PointLight(0x6366f1, 2.5, 60);
    coreLight.position.set(0, 0, 0);
    scene.add(coreLight);

    // Particle Stars
    const particleGeo = new THREE.BufferGeometry();
    const particleCount = 450;
    const posArray = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i++) {
      posArray[i] = (Math.random() - 0.5) * 80;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.25,
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.6,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Central Core Galaxy Node: Student Persona
    const coreGeo = new THREE.SphereGeometry(2.0, 32, 32);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x4f46e5,
      emissive: 0x6366f1,
      emissiveIntensity: 0.8,
      roughness: 0.2,
      metalness: 0.8,
    });
    const coreNode = new THREE.Mesh(coreGeo, coreMat);
    coreNode.userData = { isCore: true, name: user?.name || 'Alex' };
    scene.add(coreNode);

    // Construct Hierarchical Clusters
    const interactiveMeshes = [];
    const categories = skillGalaxyData.categories;
    const categoryRadius = 14;

    categories.forEach((cat, catIdx) => {
      const catAngle = (catIdx / categories.length) * Math.PI * 2;
      const catX = Math.cos(catAngle) * categoryRadius;
      const catZ = Math.sin(catAngle) * categoryRadius;
      const catY = (catIdx % 2 === 0 ? 1 : -1) * 2;

      // Category Hub Mesh
      const catColorNum = parseInt(cat.color.replace('#', '0x'));
      const catGeo = new THREE.SphereGeometry(1.6, 24, 24);
      const catMat = new THREE.MeshStandardMaterial({
        color: catColorNum,
        emissive: catColorNum,
        emissiveIntensity: 0.6,
        roughness: 0.3,
      });
      const catMesh = new THREE.Mesh(catGeo, catMat);
      catMesh.position.set(catX, catY, catZ);
      catMesh.userData = { isCategory: true, category: cat };
      scene.add(catMesh);
      interactiveMeshes.push(catMesh);

      // Connect Category to Student Core
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(catX, catY, catZ),
      ]);
      const lineMat = new THREE.LineBasicMaterial({
        color: catColorNum,
        transparent: true,
        opacity: 0.4,
      });
      scene.add(new THREE.Line(lineGeo, lineMat));

      // Sub-Skills around this Category Hub
      const subRadius = 6;
      cat.skills.forEach((skill, skIdx) => {
        const subAngle = (skIdx / cat.skills.length) * Math.PI * 2;
        const skX = catX + Math.cos(subAngle) * subRadius;
        const skZ = catZ + Math.sin(subAngle) * subRadius;
        const skY = catY + Math.sin(skIdx) * 2;

        // Node size and glow intensity directly reflect skill score! (Prompt Section 9)
        const sizeRadius = 0.7 + (skill.score / 100) * 0.9;
        const glowIntensity = 0.3 + (skill.score / 100) * 0.9;

        const skillColorNum = parseInt((skill.color || cat.color).replace('#', '0x'));
        const skGeo = new THREE.SphereGeometry(sizeRadius, 24, 24);
        const skMat = new THREE.MeshStandardMaterial({
          color: skillColorNum,
          emissive: skillColorNum,
          emissiveIntensity: glowIntensity,
          roughness: 0.2,
          metalness: 0.4,
        });
        const skMesh = new THREE.Mesh(skGeo, skMat);
        skMesh.position.set(skX, skY, skZ);
        skMesh.userData = { isSkill: true, skill, category: cat };
        scene.add(skMesh);
        interactiveMeshes.push(skMesh);

        // Connect Skill to Category Hub
        const subLineGeo = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(catX, catY, catZ),
          new THREE.Vector3(skX, skY, skZ),
        ]);
        const subLineMat = new THREE.LineBasicMaterial({
          color: skillColorNum,
          transparent: true,
          opacity: 0.35,
        });
        scene.add(new THREE.Line(subLineGeo, subLineMat));
      });
    });

    // Raycasting for Interactivity
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onPointerDown = (event) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(interactiveMeshes);
      if (intersects.length > 0) {
        const hit = intersects[0].object;
        if (hit.userData.isSkill) {
          setSelectedSkill(hit.userData.skill);
          onSelectSkill?.(hit.userData.skill);
        } else if (hit.userData.isCategory) {
          setSelectedSkill({
            name: hit.userData.category.name,
            isCategory: true,
            skills: hit.userData.category.skills,
          });
        }
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    // Animation Loop
    let animId;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Gentle galaxy rotation
      particles.rotation.y = elapsedTime * 0.02;
      coreNode.rotation.y = elapsedTime * 0.15;

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const newW = containerRef.current.clientWidth;
      const newH = compact ? 360 : 480;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.dispose();
    };
  }, [is2DFallback]);

  const compact = false;

  return (
    <div className="space-y-4">
      {/* Galaxy Title and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
              <Brain className="w-4 h-4" />
            </span>
            <h2 className="text-xl font-extrabold text-white">Student Skill Galaxy</h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-500/10 text-purple-300 border border-purple-500/20">
              3D Knowledge Topology
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Node size and luminescence reflect your assessed mastery. Click any sphere to explore details.
          </p>
        </div>

        {/* 2D / 3D Switch & Reset */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIs2DFallback((prev) => !prev)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              is2DFallback
                ? 'bg-indigo-600 text-white border-indigo-500'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:text-white'
            }`}
          >
            {is2DFallback ? 'Switch to 3D Galaxy' : '2D Graph Fallback'}
          </button>
        </div>
      </div>

      {/* 3D / 2D Canvas Container */}
      <div className="relative rounded-3xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl">
        {!is2DFallback ? (
          <div
            ref={containerRef}
            className="w-full h-[480px] cursor-grab active:cursor-grabbing relative"
          >
            {/* Overlay 3D Controls Legend */}
            <div className="absolute top-4 left-4 z-10 p-3 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-[11px] text-slate-300 space-y-1.5 pointer-events-none">
              <div className="flex items-center gap-2 font-bold text-white uppercase text-[10px] tracking-wider">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                <span>Galaxy Clusters</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                <span>Programming (Python, JS, Data Structures)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                <span>Data Science (Stats, ML, Viz)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                <span>AI & Neural Systems (Transformers, CV)</span>
              </div>
            </div>

            <div className="absolute bottom-4 right-4 z-10 px-3 py-1.5 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-[10px] text-slate-400 pointer-events-none">
              Left Click + Drag: Orbit • Scroll: Zoom • Right Click: Pan
            </div>
          </div>
        ) : (
          /* 2D Fallback View (Prompt Section 16) */
          <div className="p-6 sm:p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {skillGalaxyData.categories.map((cat) => (
                <div
                  key={cat.id}
                  className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: cat.color }}
                      />
                      <h3 className="font-bold text-slate-100 text-sm">{cat.name}</h3>
                    </div>
                    <span className="text-xs text-slate-400">{cat.skills.length} Skills</span>
                  </div>

                  <div className="space-y-3">
                    {cat.skills.map((sk) => (
                      <div
                        key={sk.id}
                        onClick={() => setSelectedSkill(sk)}
                        className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-indigo-500/40 cursor-pointer transition-all space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-200">{sk.name}</span>
                          <span className="font-mono font-bold text-emerald-400">{sk.score}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${sk.score}%`,
                              backgroundColor: sk.color || cat.color,
                            }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400">{sk.description}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Selected Skill Telemetry Drawer */}
      {selectedSkill && (
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-indigo-400">
              Selected Skill Node
            </span>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">{selectedSkill.name}</h3>
              {selectedSkill.score && (
                <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  {selectedSkill.score}% Mastery
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              {selectedSkill.description || 'Target proficiency benchmark: 90%'}
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => setSelectedSkill(null)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
