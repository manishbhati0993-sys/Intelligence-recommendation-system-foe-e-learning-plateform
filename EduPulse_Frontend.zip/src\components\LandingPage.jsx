import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Target,
  Briefcase,
  GraduationCap,
  Building2,
  CheckCircle2,
  Cpu,
  TrendingUp,
  Award,
  ShieldCheck,
  ChevronRight,
  HelpCircle,
  Mail,
  Zap,
  Users,
  Compass,
  FileText,
  BarChart3,
  AlertTriangle,
  FileX2,
  Unlink,
  CheckCircle,
  Network
} from 'lucide-react';
import { USER_ROLES } from '../data/portalData';
import SystemFlowVisualizer from './SystemFlowVisualizer';
import ThreeEcosystemGraph from './ThreeEcosystemGraph';

export default function LandingPage({ setActiveTab, onRoleChange, onOpenAuth }) {
  const [activeFaq, setActiveFaq] = useState(null);
  const [show3DNetwork, setShow3DNetwork] = useState(false);

  const faqs = [
    {
      q: 'How does the AI Skill Mapping engine calculate candidate-opportunity match scores?',
      a: 'The engine parses student verified technical assessment scores and repository project commits against recruiters’ required skill priority weights (High/Medium/Low). It flags exact matches, partial proficiencies, and missing competencies with actionable % scores.'
    },
    {
      q: 'Can colleges use this platform to identify outdated academic curricula?',
      a: 'Yes! The College/TPO dashboard generates real-time departmental skill deficiency heatmaps compared against live industry hiring demands (e.g. Docker, Spring Boot 3, MLOps) so universities can update syllabi and conduct targeted Faculty Development Programs.'
    },
    {
      q: 'How do recruiters find pre-vetted candidates without manual resume screening?',
      a: 'Recruiters can filter candidates directly by verified assessment scores, GitHub project verification, and match % thresholds, allowing 1-click shortlisting and instant interview scheduling.'
    },
    {
      q: 'Is this portal applicable for domains beyond Computer Science?',
      a: 'Absolutely. SkillBridge supports Full Stack & Cloud, AI & Data Science, Core Mechanical & Robotics, Electrical & IoT, Ayush HealthTech Informatics, and Business Analytics.'
    }
  ];

  return (
    <div className="space-y-24 py-4">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-6 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="text-center max-w-3xl mx-auto space-y-6">
            
            {/* SIH Hackathon & Team Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-extrabold uppercase tracking-wider animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Smart India Hackathon 2026 • Team Terminal Titan
            </div>

            {/* Exact Required Tagline & Main Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.12]">
              Bridging Industry & Academia through <br />
              <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
                AI-Powered Skill Mapping
              </span>
            </h1>

            <p className="text-slate-300 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
              A unified national ecosystem connecting <strong>Students</strong>, <strong>Colleges</strong>, and <strong>Industry</strong>. Diagnose real skill gaps, generate ML-personalized learning pathways, and achieve smart internship matching.
            </p>

            {/* Clear Required CTAs: “Student Login”, “Industry Login”, “College Login”, “Get Started” */}
            <div className="pt-3 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => {
                  onRoleChange(USER_ROLES.STUDENT);
                  setActiveTab('student_dashboard');
                }}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-black text-sm hover:opacity-95 transition shadow-xl shadow-cyan-500/25 flex items-center gap-2"
              >
                <span>Get Started Free</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  onRoleChange(USER_ROLES.STUDENT);
                  setActiveTab('student_dashboard');
                }}
                className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-xs sm:text-sm transition flex items-center gap-2"
              >
                <Users className="w-4 h-4 text-cyan-400" /> Student Login
              </button>

              <button
                onClick={() => {
                  onRoleChange(USER_ROLES.INDUSTRY);
                  setActiveTab('industry_dashboard');
                }}
                className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-xs sm:text-sm transition flex items-center gap-2"
              >
                <Building2 className="w-4 h-4 text-blue-400" /> Industry Login
              </button>

              <button
                onClick={() => {
                  onRoleChange(USER_ROLES.COLLEGE);
                  setActiveTab('college_dashboard');
                }}
                className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-xs sm:text-sm transition flex items-center gap-2"
              >
                <GraduationCap className="w-4 h-4 text-emerald-400" /> College Login
              </button>
            </div>

            {/* Live Ecosystem 3D Visualizer Toggle */}
            <div className="pt-2">
              <button
                onClick={() => setShow3DNetwork(!show3DNetwork)}
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-slate-300 text-xs font-semibold hover:border-cyan-500/50 hover:text-cyan-400 transition"
              >
                <Network className="w-3.5 h-3.5 text-cyan-400" />
                {show3DNetwork ? 'Hide 3D Neural Ecosystem' : 'Launch Interactive 3D Ecosystem Graph'}
              </button>
            </div>

            {show3DNetwork && (
              <div className="mt-4 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl animate-in zoom-in-95">
                <ThreeEcosystemGraph />
              </div>
            )}

            {/* Exact Required Impact Metrics: Students placed, Skills mapped, Companies onboarded */}
            <div className="pt-6 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg text-center">
                <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                  28,500+
                </div>
                <div className="text-xs font-bold text-white mt-1">Students Placed</div>
                <div className="text-[11px] text-slate-400">Via smart matching</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg text-center">
                <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-emerald-400">
                  1,450+
                </div>
                <div className="text-xs font-bold text-white mt-1">Skills Mapped</div>
                <div className="text-[11px] text-slate-400">AI competency taxonomies</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg text-center">
                <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">
                  480+
                </div>
                <div className="text-xs font-bold text-white mt-1">Companies Onboarded</div>
                <div className="text-[11px] text-slate-400">Infosys, TCS, Persist & more</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg text-center">
                <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-400">
                  94.8%
                </div>
                <div className="text-xs font-bold text-white mt-1">Match Accuracy</div>
                <div className="text-[11px] text-slate-400">Algorithmic precision</div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 2. THE THREE MAIN PROBLEMS SECTION (Required) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-black uppercase tracking-wider text-rose-400 bg-rose-500/10 px-3.5 py-1 rounded-full border border-rose-500/20">
            The Critical Crisis in Higher Education
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-3">
            The Three Major Bottlenecks
          </h2>
          <p className="text-sm text-slate-400 mt-2">
            Why 80% of Indian engineering and science graduates struggle with career readiness.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Problem 1: Skill Gap */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-rose-500/30 shadow-xl flex flex-col justify-between space-y-4 hover:border-rose-500/50 transition">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-0.5 text-[10px] font-black rounded-full bg-rose-500/20 text-rose-300 uppercase">
                Problem 01
              </span>
              <h3 className="text-xl font-bold text-white">The Severe Skill Gap</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Students graduate with theoretical knowledge (e.g. syntax of Java or SQL) but lack hands-on production engineering skills (Spring Boot, Docker, Microservices, CI/CD pipelines, and cloud native architectures) required on Day 1.
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-rose-300">
              <strong>Impact:</strong> 47% of entry-level engineers require 6+ months of costly corporate retraining before billing on projects.
            </div>
          </div>

          {/* Problem 2: Industry-Academia Disconnect */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-amber-500/30 shadow-xl flex flex-col justify-between space-y-4 hover:border-amber-500/50 transition">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Unlink className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-0.5 text-[10px] font-black rounded-full bg-amber-500/20 text-amber-300 uppercase">
                Problem 02
              </span>
              <h3 className="text-xl font-bold text-white">Industry-Academia Disconnect</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                No real-time curricular feedback loop exists between university boards of studies and industry CTOs. University syllabi take 3-4 years to update, while industry tech stacks evolve every 6 months.
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-amber-300">
              <strong>Impact:</strong> Colleges have zero telemetry on which subjects produce low placement conversion or which tools are obsolete.
            </div>
          </div>

          {/* Problem 3: Unstructured Internships */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-blue-500/30 shadow-xl flex flex-col justify-between space-y-4 hover:border-blue-500/50 transition">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <FileX2 className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-0.5 text-[10px] font-black rounded-full bg-blue-500/20 text-blue-300 uppercase">
                Problem 03
              </span>
              <h3 className="text-xl font-bold text-white">Unstructured Internships</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Internships are fragmented across random job boards, fraught with ghosting, lack verified project portfolios, and often result in certificate mills with zero tangible learning or conversion into Pre-Placement Offers (PPOs).
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-blue-300">
              <strong>Impact:</strong> Recruiters drown in thousands of unvetted PDF resumes while deserving students miss legitimate opportunities.
            </div>
          </div>

        </div>
      </section>

      {/* 3. HOW IT WORKS (3-STEP VISUAL FLOW) (Required) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-black uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3.5 py-1 rounded-full border border-cyan-500/20">
            Intelligent 3-Step Process
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-3">
            How SkillBridge Bridges the Divide
          </h2>
          <p className="text-sm text-slate-400 mt-2">
            A frictionless, AI-orchestrated lifecycle transforming students into industry-ready assets.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          
          {/* Step 1 */}
          <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition relative shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center font-black text-xl mb-5 shadow-lg shadow-cyan-500/10">
              01
            </div>
            <span className="text-xs font-extrabold text-cyan-400 uppercase tracking-wider">Step 1 • Diagnostic</span>
            <h3 className="text-xl font-bold text-white mt-1 mb-3">AI Skill Mapping & Profiling</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Students take adaptive technical assessments and link verified GitHub/project repositories. Our AI translates results into a multi-axis <strong>Dynamic Skill Spider Radar Graph</strong>, benchmarked against real corporate job profiles.
            </p>
            <div className="mt-5 pt-4 border-t border-slate-800 flex items-center gap-2 text-xs text-cyan-300 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Automated Skill Gap Detection
            </div>
          </div>

          {/* Step 2 */}
          <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition relative shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-black text-xl mb-5 shadow-lg shadow-emerald-500/10">
              02
            </div>
            <span className="text-xs font-extrabold text-emerald-400 uppercase tracking-wider">Step 2 • Remediation</span>
            <h3 className="text-xl font-bold text-white mt-1 mb-3">Personalized AI Learning Pathway</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Machine learning generates a custom 6-to-8 week bridge roadmap with targeted courses, hands-on micro-projects, and milestone tests to elevate student readiness from 50% to &gt;90% match for Tier-1 positions.
            </p>
            <div className="mt-5 pt-4 border-t border-slate-800 flex items-center gap-2 text-xs text-emerald-300 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Targeted Milestone Progression
            </div>
          </div>

          {/* Step 3 */}
          <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-blue-500/40 transition relative shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center font-black text-xl mb-5 shadow-lg shadow-blue-500/10">
              03
            </div>
            <span className="text-xs font-extrabold text-blue-400 uppercase tracking-wider">Step 3 • Placement</span>
            <h3 className="text-xl font-bold text-white mt-1 mb-3">Smart Matching & Verified Projects</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Recruiters access a pre-assessed talent pipeline with transparent match % scores and verified project portfolios. 1-click interview scheduling accelerates hiring, leading to verifiable blockchain-backed certifications.
            </p>
            <div className="mt-5 pt-4 border-t border-slate-800 flex items-center gap-2 text-xs text-blue-300 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              1-Click Direct Application & PPO
            </div>
          </div>

        </div>
      </section>

      {/* 4. SYSTEM FLOW VISUALIZATION (Required 6-step Interactive Flow) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SystemFlowVisualizer />
      </section>

      {/* 5. THREE-WAY VALUE PROPOSITIONS FOR STAKEHOLDERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-black uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3.5 py-1 rounded-full border border-cyan-500/20">
            Tripartite Stakeholder Synergy
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-3">
            Empowering Every Pillar of Higher Education
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Students */}
          <div className="p-7 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">For Students</h3>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                  Self-assessment with dynamic spider radar
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                  ML-driven learning pathways with milestone tests
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                  Verified industry projects & verifiable badges
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                  Direct interview pipeline to Tier-1 recruiters
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                onRoleChange(USER_ROLES.STUDENT);
                setActiveTab('student_dashboard');
              }}
              className="w-full py-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 font-bold text-xs border border-cyan-500/30 transition flex items-center justify-center gap-1.5"
            >
              Open Student Portal <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Industry */}
          <div className="p-7 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">For Industry</h3>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-400 shrink-0" />
                  Zero unvetted resume screening
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-400 shrink-0" />
                  Pre-assessed candidates with match % scores
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-400 shrink-0" />
                  Live skill demand analytics & CoE partnerships
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-400 shrink-0" />
                  1-Click interview scheduling & offer rollouts
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                onRoleChange(USER_ROLES.INDUSTRY);
                setActiveTab('industry_dashboard');
              }}
              className="w-full py-2.5 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 font-bold text-xs border border-blue-500/30 transition flex items-center justify-center gap-1.5"
            >
              Open Recruiter HUD <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Colleges */}
          <div className="p-7 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <GraduationCap className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">For Colleges & TPOs</h3>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  Department-level curriculum vs industry gap heatmaps
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  Real-time placement statistics & NIRF ranking metrics
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  Automated MoU lifecycle tracking & joint CoE labs
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  Student semester-by-semester skill growth audit
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                onRoleChange(USER_ROLES.COLLEGE);
                setActiveTab('college_dashboard');
              }}
              className="w-full py-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/30 transition flex items-center justify-center gap-1.5"
            >
              Open Institution Dashboard <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </section>

      {/* 6. FREQUENTLY ASKED QUESTIONS */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
            Frequently Asked Questions
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-3">
            Everything You Need to Know About SkillBridge
          </h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden transition"
            >
              <button
                onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                className="w-full p-5 text-left flex items-center justify-between gap-4"
              >
                <span className="font-bold text-sm text-white">{faq.q}</span>
                <span className={`text-cyan-400 transition-transform ${activeFaq === index ? 'rotate-180' : ''}`}>
                  ▼
                </span>
              </button>
              {activeFaq === index && (
                <div className="px-5 pb-5 text-xs text-slate-300 leading-relaxed border-t border-slate-800/80 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* 7. BOTTOM CTA CALLOUT BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-cyan-950/70 border border-cyan-500/30 text-center relative overflow-hidden shadow-2xl">
          <div className="max-w-2xl mx-auto space-y-4 relative z-10">
            <h3 className="text-2xl sm:text-4xl font-black text-white">
              Ready to Transform Academic Outcomes?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Join thousands of students, top Tier-1 institutions, and Fortune 500 recruiters on SkillBridge. Built for Smart India Hackathon.
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => {
                  onRoleChange(USER_ROLES.STUDENT);
                  setActiveTab('student_dashboard');
                }}
                className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black text-sm hover:opacity-95 transition shadow-xl shadow-cyan-500/20 flex items-center gap-2"
              >
                Launch Live Demo <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenAuth}
                className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-sm transition"
              >
                Explore All Roles
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
