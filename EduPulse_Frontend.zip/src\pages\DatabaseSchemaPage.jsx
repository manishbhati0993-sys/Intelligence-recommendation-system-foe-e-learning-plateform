import React, { useState } from 'react';
import {
  Database,
  Table,
  Key,
  Layers,
  Search,
  CheckCircle2,
  Code,
  Copy,
  ExternalLink,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { databaseSchemaMetadata } from '../data/mockData';

export default function DatabaseSchemaPage({ onShowToast }) {
  const [selectedTable, setSelectedTable] = useState(databaseSchemaMetadata[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedQuery, setCopiedQuery] = useState(false);

  const filteredTables = databaseSchemaMetadata.filter((t) =>
    t.table.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sampleRecommendationQuery = `-- Production PostgreSQL Query for Hybrid Recommendation Engine Scoring
SELECT 
    c.id AS course_id,
    c.title,
    c.difficulty_level,
    c.rating,
    -- 1. Content/Interest Match
    (
      SELECT COUNT(*)::float / GREATEST(ARRAY_LENGTH(sp.preferences_json->'interestTags', 1), 1)
      FROM unnest(ARRAY(SELECT jsonb_array_elements_text(sp.preferences_json->'interestTags'))) AS tag
      WHERE c.description ILIKE '%' || tag || '%'
    ) * 100 AS interest_score,
    -- 2. Skill Gap Closure
    COALESCE(
      (SELECT MAX(GREATEST(0, us.target_score - us.current_score))
       FROM CourseSkill cs
       JOIN UserSkill us ON us.skill_id = cs.skill_id AND us.student_id = sp.id
       WHERE cs.course_id = c.id), 
      50
    ) AS skill_gap_score,
    -- 3. Performance / Prerequisite Diagnostic Flag
    CASE 
      WHEN EXISTS (
        SELECT 1 FROM QuizAttempt qa 
        JOIN Quiz q ON q.id = qa.quiz_id 
        WHERE qa.student_id = sp.id AND qa.score_percentage < 70 
          AND q.target_skill_id IN (SELECT skill_id FROM CourseSkill WHERE course_id = c.id)
      ) AND c.difficulty_level = 'Beginner' THEN 98
      ELSE 75
    END AS performance_score
FROM Course c
CROSS JOIN StudentProfile sp
WHERE sp.user_id = 'usr_alex_2026'
  AND NOT EXISTS (
    SELECT 1 FROM Enrollment e 
    WHERE e.student_id = sp.id AND e.course_id = c.id AND e.status = 'completed'
  )
ORDER BY (interest_score * 0.25 + skill_gap_score * 0.20 + performance_score * 0.20) DESC
LIMIT 10;`;

  const handleCopyQuery = () => {
    navigator.clipboard.writeText(sampleRecommendationQuery);
    setCopiedQuery(true);
    onShowToast?.({
      type: 'success',
      title: 'SQL Copied',
      message: 'PostgreSQL recommendation calculation query copied to clipboard.',
    });
    setTimeout(() => setCopiedQuery(false), 3000);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-bold">
              <Database className="w-3.5 h-3.5" />
              <span>Production Relational Schema Architecture</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
              PostgreSQL Database Design & Data Models
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Complete relational models for the 16 platform entities: user telemetry, skill ontology, adaptive learning paths, quiz attempts, and transparent recommendation audit logs.
            </p>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs font-mono text-emerald-400">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>16 Fully Normalized Tables (3NF)</span>
          </div>
        </div>
      </div>

      {/* Main Content Grid: Tables List (Left) and Table Details (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Tables Sidebar */}
        <div className="lg:col-span-4 space-y-4">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search tables or fields..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[600px] overflow-y-auto no-scrollbar pr-1">
            {filteredTables.map((t) => {
              const isSelected = selectedTable.table === t.table;
              return (
                <button
                  key={t.table}
                  onClick={() => setSelectedTable(t)}
                  className={`w-full p-3 rounded-2xl text-left transition-all flex items-center justify-between border ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30 font-bold'
                      : 'bg-slate-900/80 hover:bg-slate-850 text-slate-300 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Table className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-white' : 'text-indigo-400'}`} />
                    <span className="text-xs truncate">{t.table}</span>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                    isSelected ? 'bg-indigo-700 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {t.columns.length} cols
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Table Schema Viewer */}
        <div className="lg:col-span-8 space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-mono uppercase font-bold text-indigo-400 block">
                  Table Definition
                </span>
                <h2 className="text-xl font-extrabold text-white flex items-center gap-2 mt-0.5">
                  <span>{selectedTable.table}</span>
                  <span className="text-xs font-mono font-normal text-slate-400">
                    (PK: {selectedTable.primaryKey})
                  </span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {selectedTable.description}
                </p>
              </div>

              <span className="px-3 py-1 rounded-xl text-xs font-mono bg-slate-950 text-emerald-400 border border-slate-800">
                PostgreSQL 16
              </span>
            </div>

            {/* Columns Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-[10px] uppercase font-bold text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-3">Column Name</th>
                    <th className="p-3">Data Type</th>
                    <th className="p-3">Constraints & References</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {selectedTable.columns.map((col, idx) => (
                    <tr key={idx} className="hover:bg-slate-850/50 transition-colors">
                      <td className="p-3 font-bold text-slate-100 flex items-center gap-1.5">
                        {col.constraints.includes('PRIMARY KEY') && (
                          <Key className="w-3.5 h-3.5 text-amber-400" />
                        )}
                        <span>{col.name}</span>
                      </td>
                      <td className="p-3 text-cyan-400">{col.type}</td>
                      <td className="p-3 text-slate-400 font-sans text-xs">{col.constraints}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Indexes */}
            {selectedTable.indexes?.length > 0 && (
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                  Performance Indexes
                </span>
                <div className="space-y-1 font-mono text-[11px] text-emerald-400 bg-slate-950/80 p-3 rounded-xl border border-slate-800">
                  {selectedTable.indexes.map((idx, i) => (
                    <div key={i}>CREATE INDEX {idx};</div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sample Recommendation Engine SQL Query */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4 text-indigo-400" />
                <h3 className="font-bold text-white text-sm">
                  Production Hybrid Recommendation SQL Query
                </h3>
              </div>
              <button
                onClick={handleCopyQuery}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                {copiedQuery ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedQuery ? 'Copied!' : 'Copy SQL'}</span>
              </button>
            </div>

            <pre className="p-4 rounded-2xl bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed border border-slate-800 max-h-72 no-scrollbar">
              {sampleRecommendationQuery}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
