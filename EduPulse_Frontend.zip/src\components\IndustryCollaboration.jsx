import React from 'react';
import {
  Building2,
  Handshake,
  Award,
  Users,
  Plus,
  CheckCircle2,
  Calendar,
  ExternalLink
} from 'lucide-react';
import { INDUSTRY_MOUS } from '../data/portalData';

export default function IndustryCollaboration({ mous = INDUSTRY_MOUS }) {
  return (
    <div class="max-w-6xl mx-auto py-4 space-y-6">
      
      {/* Header */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                Corporate Partnerships
              </span>
              <span class="text-xs text-slate-400">• Institutional MoUs & CoEs</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-white mt-2">
              Industry Collaboration & MoU Governance
            </h1>
          </div>

          <button
            onClick={() => alert("Initiating new Industry Collaboration MoU Proposal workflow.")}
            class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-cyan-500 text-slate-950 font-extrabold text-xs transition shadow-lg shadow-purple-500/20 flex items-center gap-2"
          >
            <Plus class="w-4 h-4" /> Propose New Corporate MoU
          </button>
        </div>

        <p class="text-xs sm:text-sm text-slate-300">
          Track active corporate memoranda of understanding, joint research laboratories, sponsored hackathons, and corporate-sponsored faculty upskilling programs (FDPs).
        </p>
      </div>

      {/* MoUs Grid */}
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        {mous.map((mou) => (
          <div
            key={mou.id}
            class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-purple-500/40 transition space-y-4 flex flex-col justify-between"
          >
            <div class="space-y-3">
              <div class="flex items-start justify-between gap-3">
                <div class="w-12 h-12 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-purple-400 font-bold">
                  <Building2 class="w-6 h-6" />
                </div>
                <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  {mou.status}
                </span>
              </div>

              <div>
                <h3 class="text-base font-bold text-white">{mou.company}</h3>
                <p class="text-xs text-purple-300 font-medium">{mou.type}</p>
                <p class="text-[11px] text-slate-400 mt-1">Signed: {mou.signedDate}</p>
              </div>
            </div>

            <div class="space-y-2 pt-3 border-t border-slate-800 text-xs">
              <div class="flex items-center justify-between text-slate-300">
                <span>Internships Committed:</span>
                <strong class="text-cyan-400">{mou.internshipsCommitted}</strong>
              </div>
              <div class="flex items-center justify-between text-slate-300">
                <span>Students Placed:</span>
                <strong class="text-emerald-400">{mou.studentsPlaced}</strong>
              </div>
              <div class="flex items-center justify-between text-slate-300">
                <span>Faculty Trained (FDP):</span>
                <strong class="text-amber-400">{mou.facultyTrained}</strong>
              </div>
            </div>

            <button
              onClick={() => alert(`Reviewing signed legal MoU documentation for ${mou.company}`)}
              class="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
            >
              View MoU Terms
            </button>
          </div>
        ))}
      </div>

    </div>
  );
}
