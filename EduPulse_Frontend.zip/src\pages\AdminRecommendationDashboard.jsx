import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Sparkles,
  TrendingUp,
  Users,
  Award,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Save,
  BarChart2,
  PieChart as PieIcon,
  Layers,
  ArrowUpRight,
  Flame,
  Target
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import {
  getRecommendationWeights,
  setRecommendationWeights,
  resetRecommendationWeights,
  DEFAULT_WEIGHTS
} from '../services/recommendationEngine';
import { coursesData } from '../data/mockData';

export default function AdminRecommendationDashboard({
  onShowToast,
  onWeightsUpdated,
}) {
  const [weights, setWeights] = useState(() => {
    const current = getRecommendationWeights();
    return {
      interestMatch: Math.round(current.interestMatch * 100),
      skillMatch: Math.round(current.skillMatch * 100),
      performanceRelevance: Math.round(current.performanceRelevance * 100),
      learningGoalMatch: Math.round(current.learningGoalMatch * 100),
      difficultyFit: Math.round(current.difficultyFit * 100),
      behavioralRelevance: Math.round(current.behavioralRelevance * 100),
    };
  });

  const [hasChanges, setHasChanges] = useState(false);

  // Calculate sum of weights
  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);
  const isValidWeightSum = totalWeight === 100;

  const handleSliderChange = (key, value) => {
    setWeights((prev) => ({
      ...prev,
      [key]: Number(value),
    }));
    setHasChanges(true);
  };

  const handleSaveWeights = () => {
    if (!isValidWeightSum) {
      onShowToast?.({
        type: 'warning',
        title: 'Invalid Weights Sum',
        message: `Recommendation weights must sum to exactly 100%. Current sum: ${totalWeight}%.`,
      });
      return;
    }

    const normalized = {
      interestMatch: weights.interestMatch / 100,
      skillMatch: weights.skillMatch / 100,
      performanceRelevance: weights.performanceRelevance / 100,
      learningGoalMatch: weights.learningGoalMatch / 100,
      difficultyFit: weights.difficultyFit / 100,
      behavioralRelevance: weights.behavioralRelevance / 100,
    };

    setRecommendationWeights(normalized);
    setHasChanges(false);
    onWeightsUpdated?.(normalized);
    onShowToast?.({
      type: 'success',
      title: 'Global Recommendation Weights Saved',
      message: 'New weights deployed live to student recommendation pipelines.',
    });
  };

  const handleResetDefaults = () => {
    resetRecommendationWeights();
    setWeights({
      interestMatch: 25,
      skillMatch: 20,
      performanceRelevance: 20,
      learningGoalMatch: 15,
      difficultyFit: 10,
      behavioralRelevance: 10,
    });
    setHasChanges(false);
    onWeightsUpdated?.(DEFAULT_WEIGHTS);
    onShowToast?.({
      type: 'info',
      title: 'Weights Restored',
      message: 'Restored original default recommendation weights (25/20/20/15/10/10).',
    });
  };

  // Mock analytics data for admin charts
  const conversionByCategoryData = [
    { category: 'AI & Machine Learning', clicks: 14200, conversions: 3820, ctr: '26.9%' },
    { category: 'Data Science & Stats', clicks: 12500, conversions: 3450, ctr: '27.6%' },
    { category: 'Data Engineering & SQL', clicks: 9800, conversions: 2400, ctr: '24.5%' },
    { category: 'Full Stack Web Dev', clicks: 8200, conversions: 1850, ctr: '22.5%' },
    { category: 'Cloud Infrastructure', clicks: 6100, conversions: 1320, ctr: '21.6%' },
    { category: 'Cybersecurity', clicks: 4200, conversions: 910, ctr: '21.6%' },
  ];

  const weakSkillsCohortData = [
    { skill: 'Statistics', studentsWithGap: 48, avgGap: '29%' },
    { skill: 'Machine Learning', studentsWithGap: 42, avgGap: '38%' },
    { skill: 'SQL Optimization', studentsWithGap: 34, avgGap: '22%' },
    { skill: 'Deep Learning', studentsWithGap: 28, avgGap: '26%' },
    { skill: 'Data Visualization', studentsWithGap: 25, avgGap: '18%' },
    { skill: 'Python OOP', studentsWithGap: 14, avgGap: '12%' },
  ];

  const studentInterestsData = [
    { name: 'Data Science', value: 38, color: '#06b6d4' },
    { name: 'Artificial Intelligence', value: 32, color: '#8b5cf6' },
    { name: 'Web Development', value: 16, color: '#3b82f6' },
    { name: 'Cloud Computing', value: 8, color: '#10b981' },
    { name: 'Cybersecurity', value: 6, color: '#f43f5e' },
  ];

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-bold">
              <Sliders className="w-3.5 h-3.5" />
              <span>Platform Administration & Recommendation Orchestrator</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
              Recommendation Engine Operations & Analytics
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Monitor conversion metrics, student skill deficit hotspots, and adjust mathematical recommendation weights in real-time.
            </p>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0">
            <button
              onClick={handleResetDefaults}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>
            <button
              onClick={handleSaveWeights}
              disabled={!hasChanges && isValidWeightSum}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Apply Weights</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80">
          <span className="text-[11px] font-bold text-slate-500 uppercase block">Total Recommendations</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-100 font-mono mt-1">48,290</p>
          <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1 mt-1">
            <ArrowUpRight className="w-3 h-3" />
            +14% this month
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80">
          <span className="text-[11px] font-bold text-slate-500 uppercase block">Recommendation CTR</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-indigo-400 font-mono mt-1">25.8%</p>
          <span className="text-[11px] text-indigo-300 font-medium mt-1 block">Industry Avg: 14.2%</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80">
          <span className="text-[11px] font-bold text-slate-500 uppercase block">Course Enrollment Conversion</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-cyan-400 font-mono mt-1">18.4%</p>
          <span className="text-[11px] text-cyan-300 font-medium mt-1 block">8,885 Enrolled via AI</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80">
          <span className="text-[11px] font-bold text-slate-500 uppercase block">Avg Course Completion Rate</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono mt-1">74.6%</p>
          <span className="text-[11px] text-emerald-300 font-medium mt-1 block">+32% higher for AI-matched</span>
        </div>
      </div>

      {/* Main Interactive Weight Configurator (Prompt Section 5 & 14) */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-indigo-500/30 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-indigo-500/20 text-indigo-400">
                <Sliders className="w-4 h-4" />
              </span>
              <h3 className="font-extrabold text-lg text-white">
                Live Recommendation Weight Configurator
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Adjust the 6 signals used by the multi-criteria ranking algorithm. Changes immediately recalculate student feeds.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-slate-400">Total Sum:</span>
            <span
              className={`px-3 py-1 rounded-xl text-xs font-mono font-bold border ${
                isValidWeightSum
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse'
              }`}
            >
              {totalWeight}% {isValidWeightSum ? '✓ Valid' : '⚠️ Must Equal 100%'}
            </span>
          </div>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
          {/* Factor 1: Interest Match */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-200">1. Interest Match</span>
              <span className="font-mono font-bold text-emerald-400 text-sm">{weights.interestMatch}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={weights.interestMatch}
              onChange={(e) => handleSliderChange('interestMatch', e.target.value)}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Matches course tags, topics, and syllabus keywords against student search terms and interests.
            </p>
          </div>

          {/* Factor 2: Skill Match */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-200">2. Skill Match (Gap Closure)</span>
              <span className="font-mono font-bold text-cyan-400 text-sm">{weights.skillMatch}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={weights.skillMatch}
              onChange={(e) => handleSliderChange('skillMatch', e.target.value)}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Prioritizes courses that bridge identified skill gaps (e.g. Statistics 61% vs 90% benchmark).
            </p>
          </div>

          {/* Factor 3: Performance Relevance */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-200">3. Performance Relevance</span>
              <span className="font-mono font-bold text-indigo-400 text-sm">{weights.performanceRelevance}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={weights.performanceRelevance}
              onChange={(e) => handleSliderChange('performanceRelevance', e.target.value)}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Boosts foundational remedial courses on low prerequisite scores; unlocks advanced topics on high scores.
            </p>
          </div>

          {/* Factor 4: Learning Goal Match */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-200">4. Learning Goal Match</span>
              <span className="font-mono font-bold text-purple-400 text-sm">{weights.learningGoalMatch}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={weights.learningGoalMatch}
              onChange={(e) => handleSliderChange('learningGoalMatch', e.target.value)}
              className="w-full accent-purple-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Weights milestone courses aligning with selected student goal (e.g. Become a Data Scientist).
            </p>
          </div>

          {/* Factor 5: Difficulty Fit */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-200">5. Difficulty Fit</span>
              <span className="font-mono font-bold text-amber-400 text-sm">{weights.difficultyFit}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={weights.difficultyFit}
              onChange={(e) => handleSliderChange('difficultyFit', e.target.value)}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Evaluates course level (Beginner/Intermediate/Advanced) against student readiness.
            </p>
          </div>

          {/* Factor 6: Behavioral Relevance */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-200">6. Behavioral Relevance</span>
              <span className="font-mono font-bold text-rose-400 text-sm">{weights.behavioralRelevance}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={weights.behavioralRelevance}
              onChange={(e) => handleSliderChange('behavioralRelevance', e.target.value)}
              className="w-full accent-rose-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Incorporate watch times, active enrollments, bookmarks, and previous feedback.
            </p>
          </div>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recommendation CTR & Conversion by Category */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-indigo-400" />
            <span>Recommendation Conversions by Subject Cluster</span>
          </h3>
          <p className="text-xs text-slate-400">Total recommendation impressions vs actual enrollments</p>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={conversionByCategoryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="category" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="clicks" name="Recommendation Clicks" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="conversions" name="Enrollment Conversions" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Weak Skill Areas Across Cohorts */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Target className="w-4 h-4 text-rose-400" />
            <span>Top Prerequisite Deficits Across Active Students</span>
          </h3>
          <p className="text-xs text-slate-400">Percentage of students needing foundational remediation</p>

          <div className="space-y-3 pt-2">
            {weakSkillsCohortData.map((item, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="space-y-1">
                  <span className="font-bold text-slate-200">{item.skill}</span>
                  <span className="text-[11px] text-slate-400 block">
                    {item.studentsWithGap}% of enrolled cohort has deficit
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                    Avg Gap: {item.avgGap}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Performing Courses Table */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <h3 className="font-bold text-white text-base flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400" />
          <span>Top Performing Recommended Courses</span>
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[10px] uppercase font-bold text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-3">Course Title</th>
                <th className="p-3">Category</th>
                <th className="p-3">Level</th>
                <th className="p-3">Enrolled</th>
                <th className="p-3">Rating</th>
                <th className="p-3">Completion Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {coursesData.slice(0, 5).map((course) => (
                <tr key={course.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-semibold text-white flex items-center gap-2">
                    <img src={course.thumbnail} alt="" className="w-8 h-8 rounded-lg object-cover" />
                    <span>{course.title}</span>
                  </td>
                  <td className="p-3">{course.category}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {course.level}
                    </span>
                  </td>
                  <td className="p-3 font-mono">{course.enrolledCount.toLocaleString()}</td>
                  <td className="p-3 font-mono text-amber-400">⭐ {course.rating}</td>
                  <td className="p-3 font-mono text-emerald-400 font-bold">78%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
