import React from 'react';
import { Cpu, Sparkles } from 'lucide-react';

export function CourseSkeleton({ count = 3 }) {
  return (
    <>
      {Array.from({ length: count }).map((_, idx) => (
        <div
          key={idx}
          className="bg-slate-900/80 rounded-2xl border border-slate-800/80 overflow-hidden flex flex-col animate-pulse"
        >
          {/* Header pill shimmer */}
          <div className="bg-slate-800/50 h-9 w-full flex items-center justify-between px-4 border-b border-slate-800">
            <div className="h-3 w-44 bg-slate-700/60 rounded-full" />
            <div className="h-4 w-20 bg-slate-700/60 rounded-full" />
          </div>

          {/* Image placeholder */}
          <div className="aspect-video w-full bg-slate-800/60 relative overflow-hidden">
            <div className="absolute inset-0 skeleton-shimmer" />
          </div>

          {/* Body */}
          <div className="p-5 flex flex-col flex-1 space-y-3">
            <div className="flex justify-between items-center">
              <div className="h-4 w-20 bg-slate-800 rounded-full" />
              <div className="h-4 w-14 bg-slate-800 rounded-full" />
            </div>

            <div className="h-5 w-5/6 bg-slate-800 rounded-md" />
            <div className="h-4 w-full bg-slate-800/60 rounded-md" />
            <div className="h-4 w-4/6 bg-slate-800/60 rounded-md" />

            <div className="flex gap-2 pt-2">
              <div className="h-4 w-16 bg-slate-800/80 rounded" />
              <div className="h-4 w-20 bg-slate-800/80 rounded" />
              <div className="h-4 w-14 bg-slate-800/80 rounded" />
            </div>

            <div className="pt-4 border-t border-slate-800/60 flex items-center justify-between mt-auto">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-slate-800" />
                <div className="h-3 w-24 bg-slate-800 rounded" />
              </div>
              <div className="h-7 w-16 bg-slate-800 rounded-xl" />
            </div>
          </div>
        </div>
      ))}
    </>
  );
}

export function RecommendationLoader({ message = 'Computing AI Recommendation Vector Matrix...' }) {
  return (
    <div className="col-span-full py-12 px-6 flex flex-col items-center justify-center text-center bg-slate-900/60 border border-indigo-500/20 rounded-2xl relative overflow-hidden backdrop-blur-md">
      {/* Glow pulse */}
      <div className="absolute w-72 h-72 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none -top-10 -left-10" />
      <div className="absolute w-72 h-72 bg-teal-500/10 rounded-full blur-3xl pointer-events-none -bottom-10 -right-10" />

      <div className="relative mb-5">
        <div className="w-16 h-16 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-xl shadow-indigo-500/20 animate-bounce">
          <Cpu className="w-8 h-8 animate-spin-slow text-indigo-400" />
        </div>
        <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-emerald-500 text-slate-950">
          <Sparkles className="w-3.5 h-3.5" />
        </div>
      </div>

      <h4 className="text-lg font-bold text-slate-100 mb-1">{message}</h4>
      <p className="text-xs text-slate-400 max-w-md mb-6">
        Analyzing your 6 assessed skill vectors, completed prerequisite modules, target career milestones, and peer cohort affinities...
      </p>

      {/* Progress ticker */}
      <div className="flex items-center gap-2 text-xs font-mono text-indigo-300 bg-slate-950/80 px-4 py-2 rounded-xl border border-slate-800">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span>Cosine Vector Match & Ranking in Progress (250+ dimensions)</span>
      </div>
    </div>
  );
}
