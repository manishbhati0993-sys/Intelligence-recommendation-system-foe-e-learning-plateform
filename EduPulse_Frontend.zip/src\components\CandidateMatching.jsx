import React, { useState } from 'react';
import {
  Sparkles,
  Users,
  Search,
  CheckCircle2,
  Calendar,
  Award,
  ExternalLink,
  Github,
  Filter,
  ShieldCheck
} from 'lucide-react';

export default function CandidateMatching({ onShortlistCandidate }) {
  const [minMatch, setMinMatch] = useState(70);

  const candidates = [
    {
      id: 'CAN-01',
      name: 'Aarav Sharma',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      college: 'NIT Karnataka (NITK)',
      degree: 'B.Tech CSE (8.74 CGPA)',
      matchScore: 88,
      topSkills: ['Java (85%)', 'SQL (80%)', 'React (75%)', 'Git (78%)'],
      status: 'Shortlisted for Round 1',
      github: 'https://github.com/aarav',
      resumeName: 'Aarav_Sharma_Resume.pdf'
    },
    {
      id: 'CAN-02',
      name: 'Ananya Verma',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
      college: 'IIT Bombay',
      degree: 'B.Tech Data Science (9.12 CGPA)',
      matchScore: 94,
      topSkills: ['Python (92%)', 'PyTorch (88%)', 'Docker (80%)', 'MLOps (78%)'],
      status: 'Ready for Interview',
      github: 'https://github.com/ananya',
      resumeName: 'Ananya_Verma_IITB_CV.pdf'
    },
    {
      id: 'CAN-03',
      name: 'Rohan Deshmukh',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      college: 'BITS Pilani',
      degree: 'B.E. Computer Science (8.45 CGPA)',
      matchScore: 82,
      topSkills: ['Node.js (84%)', 'TypeScript (80%)', 'PostgreSQL (82%)', 'AWS (70%)'],
      status: 'Under Review',
      github: 'https://github.com/rohan',
      resumeName: 'Rohan_Deshmukh_BITS.pdf'
    }
  ];

  const filtered = candidates.filter(c => c.matchScore >= minMatch);

  return (
    <div class="max-w-6xl mx-auto py-4 space-y-6">
      
      {/* Header */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                AI Talent Matching Engine
              </span>
              <span class="text-xs text-slate-400">• Verified Pre-Assessed Candidates</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-white mt-2">
              AI-Ranked Candidate Talent Pool
            </h1>
          </div>

          {/* Filter slider */}
          <div class="flex items-center gap-3 bg-slate-950 p-3 rounded-2xl border border-slate-800">
            <span class="text-xs font-bold text-slate-400">Min Match: <strong class="text-cyan-400">{minMatch}%</strong></span>
            <input
              type="range"
              min="50"
              max="95"
              value={minMatch}
              onChange={(e) => setMinMatch(Number(e.target.value))}
              class="accent-cyan-500 cursor-pointer w-24"
            />
          </div>
        </div>

        <p class="text-xs sm:text-sm text-slate-300">
          Candidates are automatically sorted by competency match score based on technical assessments and verified academic credentials.
        </p>
      </div>

      {/* Candidate Cards Grid */}
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((candidate) => (
          <div
            key={candidate.id}
            class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/40 transition flex flex-col justify-between space-y-5"
          >
            <div class="space-y-4">
              <div class="flex items-start justify-between gap-3">
                <div class="flex items-center gap-3">
                  <img
                    src={candidate.avatar}
                    alt={candidate.name}
                    class="w-14 h-14 rounded-2xl object-cover border-2 border-slate-700"
                  />
                  <div>
                    <h3 class="text-base font-bold text-white">{candidate.name}</h3>
                    <p class="text-xs text-slate-400 font-medium">{candidate.college}</p>
                    <p class="text-[11px] text-cyan-300">{candidate.degree}</p>
                  </div>
                </div>

                <span class="px-2.5 py-1 text-xs font-black rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shrink-0">
                  {candidate.matchScore}%
                </span>
              </div>

              {/* Skills Chips */}
              <div class="space-y-1.5">
                <div class="text-[10px] uppercase font-bold text-slate-400">Verified Competencies:</div>
                <div class="flex flex-wrap gap-1.5">
                  {candidate.topSkills.map((sk, idx) => (
                    <span key={idx} class="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-200 font-medium">
                      {sk}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div class="pt-4 border-t border-slate-800 space-y-2">
              <div class="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Status: <strong class="text-white">{candidate.status}</strong></span>
              </div>

              <div class="flex items-center gap-2">
                <button
                  onClick={() => alert(`Interview link generated and emailed to ${candidate.name}`)}
                  class="flex-1 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition"
                >
                  Schedule Interview
                </button>
                <button
                  onClick={() => alert(`Reviewing GitHub & Project artifacts for ${candidate.name}`)}
                  class="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                  title="View Portfolio"
                >
                  <Github class="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
