import React, { useState } from 'react';
import { UserCheck, Star, MapPin, Calendar, Clock, CheckCircle2, ShieldCheck, PhoneCall, X } from 'lucide-react';

export default function DoctorMatchmaker({ doctors = [], selectedSpecialty = '' }) {
  const [filterSpecialty, setFilterSpecialty] = useState(selectedSpecialty);
  const [bookingDoctor, setBookingDoctor] = useState(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [appointmentTime, setAppointmentTime] = useState('10:30 AM');

  const filteredDoctors = doctors.filter(doc => {
    if (!filterSpecialty) return true;
    return doc.specialty.toLowerCase().includes(filterSpecialty.toLowerCase());
  });

  const handleConfirmBooking = (e) => {
    e.preventDefault();
    setBookingConfirmed(true);
  };

  return (
    <div class="glass-panel p-6 space-y-6 border border-slate-800">
      
      {/* Header */}
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div class="flex items-center gap-3">
          <div class="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <UserCheck class="w-6 h-6" />
          </div>
          <div>
            <h2 class="text-xl font-extrabold text-white">Matched Specialist Physicians & Telehealth</h2>
            <p class="text-xs text-slate-400">Board-certified clinical specialists matched with your AI diagnosis</p>
          </div>
        </div>

        {/* Filter Dropdown */}
        <select
          value={filterSpecialty}
          onChange={(e) => setFilterSpecialty(e.target.value)}
          class="bg-slate-950 text-xs text-white border border-slate-800 rounded-xl px-3 py-2 font-semibold outline-none focus:border-cyan-500"
        >
          <option value="">All Clinical Specialties</option>
          <option value="Cardiologist">Cardiology</option>
          <option value="Pulmonologist">Pulmonology</option>
          <option value="Neurologist">Neurology</option>
          <option value="Gastroenterologist">Gastroenterology</option>
          <option value="Dermatologist">Dermatology</option>
        </select>
      </div>

      {/* Doctors Grid */}
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDoctors.map((doc) => (
          <div key={doc.id} class="glass-card p-5 space-y-4 border border-slate-800/80 flex flex-col justify-between hover:border-cyan-500/40 transition">
            
            <div class="space-y-3">
              <div class="flex items-start gap-3">
                <img
                  src={doc.avatar}
                  alt={doc.name}
                  class="w-14 h-14 rounded-2xl object-cover border border-cyan-500/30 shadow-md shrink-0"
                />
                <div>
                  <div class="flex items-center gap-1 text-amber-400 text-xs font-bold">
                    <Star class="w-3.5 h-3.5 fill-amber-400" />
                    <span>{doc.rating}</span>
                    <span class="text-slate-500 font-normal">({doc.reviewsCount} reviews)</span>
                  </div>
                  <h3 class="text-base font-extrabold text-white">{doc.name}</h3>
                  <p class="text-xs text-cyan-400 font-semibold">{doc.specialty}</p>
                </div>
              </div>

              <div class="space-y-1.5 text-xs text-slate-300">
                <p class="flex items-center gap-1.5 text-slate-400">
                  <ShieldCheck class="w-4 h-4 text-emerald-400 shrink-0" /> {doc.subspecialty}
                </p>
                <p class="flex items-center gap-1.5 text-slate-400">
                  <MapPin class="w-4 h-4 text-cyan-400 shrink-0" /> {doc.location}
                </p>
                <p class="flex items-center gap-1.5 text-slate-400">
                  <Clock class="w-4 h-4 text-amber-400 shrink-0" /> Available: <strong class="text-white">{doc.availability}</strong>
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => { setBookingDoctor(doc); setBookingConfirmed(false); }}
              class="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
            >
              <Calendar class="w-4 h-4" /> Book Consultation
            </button>

          </div>
        ))}
      </div>

      {/* Appointment Booking Modal */}
      {bookingDoctor && (
        <div class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div class="glass-panel w-full max-w-md p-6 space-y-5 border border-cyan-500/40 relative">
            
            <button
              type="button"
              onClick={() => setBookingDoctor(null)}
              class="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X class="w-5 h-5" />
            </button>

            {!bookingConfirmed ? (
              <>
                <div class="flex items-center gap-3">
                  <img src={bookingDoctor.avatar} alt={bookingDoctor.name} class="w-12 h-12 rounded-xl object-cover border border-cyan-500/40" />
                  <div>
                    <h3 class="text-lg font-bold text-white">{bookingDoctor.name}</h3>
                    <p class="text-xs text-cyan-400 font-semibold">{bookingDoctor.specialty}</p>
                  </div>
                </div>

                <form onSubmit={handleConfirmBooking} class="space-y-4">
                  <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-300">Select Date & Preferred Time:</label>
                    <div class="grid grid-cols-2 gap-2">
                      <input
                        type="date"
                        defaultValue="2026-08-28"
                        class="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                      />
                      <select
                        value={appointmentTime}
                        onChange={(e) => setAppointmentTime(e.target.value)}
                        class="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                      >
                        <option value="09:00 AM">09:00 AM</option>
                        <option value="10:30 AM">10:30 AM</option>
                        <option value="02:00 PM">02:00 PM</option>
                        <option value="04:15 PM">04:15 PM</option>
                      </select>
                    </div>
                  </div>

                  <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
                    <p><strong>Hospital:</strong> {bookingDoctor.hospital}</p>
                    <p><strong>Consultation Fee:</strong> $120 (Covered by Insurance / MediPulse)</p>
                  </div>

                  <button
                    type="submit"
                    class="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-400 text-slate-950 font-extrabold text-xs hover:opacity-95 transition"
                  >
                    Confirm Telehealth Booking
                  </button>
                </form>
              </>
            ) : (
              <div class="text-center space-y-4 py-4">
                <div class="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
                  <CheckCircle2 class="w-6 h-6" />
                </div>
                <div class="space-y-1">
                  <h3 class="text-xl font-bold text-white">Appointment Confirmed!</h3>
                  <p class="text-xs text-slate-300">
                    Your appointment with <strong>{bookingDoctor.name}</strong> is scheduled for tomorrow at <strong>{appointmentTime}</strong>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setBookingDoctor(null)}
                  class="px-6 py-2 rounded-xl bg-slate-800 text-white font-bold text-xs hover:bg-slate-700"
                >
                  Done
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
