import React from 'react';
import {
  LayoutDashboard,
  Sparkles,
  GitMerge,
  BookOpen,
  UserCheck,
  Sliders,
  Flame,
  Clock,
  ChevronRight,
  Brain,
  Layers,
  Award,
} from 'lucide-react';

export default function Sidebar({
  currentView,
  onNavigate,
  user,
  unreadRecommendationsCount = 3,
  isMobileOpen = false,
  onCloseMobile,
}) {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Student Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'recommendations',
      label: 'AI Recommendations',
      icon: Sparkles,
      badge: '98% Top Fit',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    },
    {
      id: 'neural-universe',
      label: '3D Neural Universe',
      icon: Layers,
      badge: '3D AI',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    },
    {
      id: 'skill-gap',
      label: 'Skill Gap & Roadmap',
      icon: GitMerge,
      badge: '2 Gaps',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: 'catalog',
      label: 'Course Catalog',
      icon: BookOpen,
      badge: '15+',
    },
    {
      id: 'profile',
      label: 'Profile & Analytics',
      icon: UserCheck,
      badge: null,
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
        />
      )}

      <aside
        className={`fixed lg:sticky top-16 left-0 z-40 h-[calc(100vh-4rem)] w-64 bg-slate-950/95 lg:bg-slate-950/60 backdrop-blur-xl border-r border-slate-800/80 p-4 flex flex-col justify-between transition-transform duration-300 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Navigation Section */}
        <div className="space-y-6">
          {/* Target Goal Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/20 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl group-hover:bg-indigo-500/20 transition-all pointer-events-none" />
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                Active Career Vector
              </span>
            </div>
            <p className="text-xs font-bold text-slate-100 truncate" title={user?.targetRole}>
              {user?.targetRole || 'AI / Machine Learning Engineer'}
            </p>
            <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400">
              <span>Readiness Index</span>
              <span className="text-emerald-400 font-mono font-bold">78.5%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full"
                style={{ width: '78.5%' }}
              />
            </div>
          </div>

          {/* Primary Nav Menu */}
          <div className="space-y-1">
            <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2">
              Navigation
            </p>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    onCloseMobile?.();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/90'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${
                        isActive
                          ? 'bg-white/20 text-white border-white/30'
                          : item.badgeColor || 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom AI Widget & Stats */}
        <div className="space-y-3 pt-4 border-t border-slate-800/80">
          {/* Weekly Learning Progress Widget */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 text-xs">
            <div className="flex items-center justify-between text-slate-300 mb-1.5 font-medium">
              <span className="flex items-center gap-1.5 text-slate-400">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                Weekly Goal
              </span>
              <span className="font-mono text-slate-200">
                {user?.hoursLearnedThisWeek || 7.5} / {user?.weeklyGoalHours || 10}h
              </span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-gradient-to-r from-indigo-500 to-teal-400 h-full rounded-full"
                style={{
                  width: `${Math.min(100, ((user?.hoursLearnedThisWeek || 7.5) / (user?.weeklyGoalHours || 10)) * 100)}%`,
                }}
              />
            </div>
          </div>

          {/* AI Vector Engine Live Status Pill */}
          <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-[11px] text-emerald-300">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-medium">AI Vector Engine</span>
            </div>
            <span className="text-[10px] text-emerald-400/80 font-mono">v4.2 Live</span>
          </div>
        </div>
      </aside>
    </>
  );
}
