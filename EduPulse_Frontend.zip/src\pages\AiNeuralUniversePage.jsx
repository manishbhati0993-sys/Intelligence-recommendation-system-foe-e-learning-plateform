import React, { useState } from 'react';
import {
  Sparkles,
  Target,
  Brain,
  Zap,
  Layers,
  Compass,
  ArrowRight,
  TrendingUp,
  Cpu,
  BookOpen,
  Award,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import ThreeNeuralUniverse from '../components/ThreeNeuralUniverse';
import AiRecommendationInspector from '../components/AiRecommendationInspector';
import { careerRolesData, coursesData } from '../data/mockData';
import { calculateCourseAiMatch } from '../services/recommendationEngine';

export default function AiNeuralUniversePage({
  user,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onShowToast,
  onUpdateTargetRole,
}) {
  const [selectedTargetRole, setSelectedTargetRole] = useState(
    user?.targetRole || 'AI / Machine Learning Engineer'
  );
  const [inspectedNode, setInspectedNode] = useState(null);

  // Compute top recommended courses for quick action cards
  const topCourses = React.useMemo(() => {
    return coursesData
      .map((c) => {
        const aiMatch = calculateCourseAiMatch(c, user, { targetCareer: selectedTargetRole });
        return { ...c, aiMatch, matchScore: aiMatch.matchPercentage };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, 3);
  }, [user, selectedTargetRole]);

  const handleRoleChange = (roleName) => {
    setSelectedTargetRole(roleName);
    onUpdateTargetRole?.(roleName);
    onShowToast?.({
      type: 'ai',
      title: '3D Neural Graph Reconfigured',
      message: `Calculated dynamic spatial embeddings for "${roleName}".`,
    });
  };

  const handleInspectNode = (nodeData) => {
    setInspectedNode(nodeData);
  };

  const handleCloseInspector = () => {
    setInspectedNode(null);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Hero Banner */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>3D Spatial Knowledge Universe</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
              Interactive 3D Recommendation Topology
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Explore your educational trajectory in three dimensions. Courses, skill deficits, and
              career milestones are mapped using cosine vector similarity in continuous 3D latent space.
            </p>
          </div>

          {/* Telemetry Snapshot Cards */}
          <div className="grid grid-cols-2 gap-3 flex-shrink-0">
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-center min-w-[120px]">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Top AI Match
              </span>
              <span className="text-xl font-extrabold font-mono text-emerald-400">
                {topCourses[0]?.matchScore || 98}%
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Peak Fit</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-center min-w-[120px]">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Career Readiness
              </span>
              <span className="text-xl font-extrabold font-mono text-cyan-400">78.5%</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Vector Index</span>
            </div>
          </div>
        </div>

        {/* Target Career Quick Switcher Pill Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium mr-1 flex items-center gap-1">
            <Target className="w-3.5 h-3.5 text-indigo-400" />
            Projected Career Goal:
          </span>
          {careerRolesData.map((role) => (
            <button
              key={role.id}
              onClick={() => handleRoleChange(role.name)}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                selectedTargetRole === role.name
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-950/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {role.name}
            </button>
          ))}
        </div>
      </div>

      {/* 3D WebGL Neural Canvas */}
      <div className="relative">
        <ThreeNeuralUniverse
          user={user}
          initialTargetRole={selectedTargetRole}
          onSelectCourse={onSelectCourse}
          onToggleBookmark={onToggleBookmark}
          onEnroll={onEnroll}
          onInspectNode={handleInspectNode}
        />
      </div>

      {/* Slide-over Explainable AI Node Inspector */}
      <AiRecommendationInspector
        selectedNode={inspectedNode}
        user={user}
        onClose={handleCloseInspector}
        onSelectCourse={onSelectCourse}
        onToggleBookmark={onToggleBookmark}
        onEnroll={onEnroll}
      />

      {/* Top 3 Direct Recommendations Carousel / Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">
              Highest-Affinity Recommended Courses in 3D Orbit
            </h2>
          </div>
          <span className="text-xs text-slate-400">
            Based on active goal: <strong className="text-indigo-300">{selectedTargetRole}</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {topCourses.map((course) => {
            const isEnrolled = user?.enrolledCourses?.some((enc) => enc.courseId === course.id);
            return (
              <div
                key={course.id}
                className="group p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {course.category}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {course.matchScore}% Match
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-2">
                    {course.title}
                  </h3>

                  <p className="text-xs text-slate-400 line-clamp-2">
                    {course.description}
                  </p>

                  <div className="pt-2 flex flex-wrap gap-1.5">
                    {course.skillsTaught?.slice(0, 2).map((sk, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-slate-950 text-[10px] text-slate-300 border border-slate-800"
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onSelectCourse?.(course)}
                    className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                  >
                    <span>View Syllabus</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onEnroll?.(course.id)}
                    disabled={isEnrolled}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      isEnrolled
                        ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20'
                    }`}
                  >
                    {isEnrolled ? 'Enrolled' : 'Enroll Now'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Explanatory Guide: How 3D Neural Recommendation Works */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <Brain className="w-4 h-4 text-indigo-400" />
          <span>How the 3D Intelligence Recommendation Engine Operates</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-400">
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
            <div className="w-7 h-7 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold text-xs">
              1
            </div>
            <h4 className="font-bold text-slate-200">High-Dimensional Embeddings</h4>
            <p className="leading-relaxed">
              Your completed coursework, quiz results, and career preferences are encoded into a
              128-dimensional latent vector representing your digital learning twin.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
            <div className="w-7 h-7 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-xs">
              2
            </div>
            <h4 className="font-bold text-slate-200">Deficit & Gap Bridging</h4>
            <p className="leading-relaxed">
              The engine detects negative variance between current competencies and industry standards.
              Courses that bridge the widest gaps receive highest gravitational pull.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
            <div className="w-7 h-7 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold text-xs">
              3
            </div>
            <h4 className="font-bold text-slate-200">Synaptic Neural Routing</h4>
            <p className="leading-relaxed">
              Moving light pulses trace optimized learning pathways from your current state to career
              readiness, prioritizing prerequisite chains that maximize retention.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
