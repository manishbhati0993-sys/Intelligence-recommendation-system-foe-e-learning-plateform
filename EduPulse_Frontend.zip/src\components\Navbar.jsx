import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Search,
  Bell,
  Moon,
  Sun,
  User,
  BookOpen,
  ChevronDown,
  Flame,
  X,
  ArrowRight,
  TrendingUp,
  BrainCircuit,
  LogOut,
  Settings,
  Award,
  Network,
  Database,
  ShieldCheck,
} from 'lucide-react';
import { coursesData } from '../data/mockData';

export default function Navbar({
  user,
  currentView,
  onNavigate,
  onSelectCourse,
  isDarkMode,
  onToggleDarkMode,
  onLogout,
  onOpenNotifications,
  onOpenSearch,
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'New 98% AI Match Found',
      message: 'Deep Learning & Neural Networks with PyTorch 2.4 bridges your highest skill gap.',
      time: '15m ago',
      unread: true,
      type: 'match',
      courseId: 'c2',
    },
    {
      id: 2,
      title: 'Streak Milestone Unlocked!',
      message: 'You have maintained your 14-day study streak. Keep going for the 21-day badge.',
      time: '2h ago',
      unread: true,
      type: 'streak',
    },
    {
      id: 3,
      title: 'Curriculum Vector Updated',
      message: 'Target role AI / ML Engineer benchmark updated with vLLM & Agentic frameworks.',
      time: '1d ago',
      unread: false,
      type: 'system',
    },
  ]);

  const searchRef = useRef(null);
  const profileRef = useRef(null);
  const notifRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setIsSearchOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setIsProfileMenuOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setIsNotificationsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchResults = searchQuery.trim() === ''
    ? []
    : coursesData.filter(
        (c) =>
          c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
          c.category.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5);

  const unreadCount = notifications.filter((n) => n.unread).length;

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div
          className="flex items-center gap-3 cursor-pointer group flex-shrink-0"
          onClick={() => onNavigate('dashboard')}
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-teal-400 p-0.5 shadow-lg shadow-indigo-600/30 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <BrainCircuit className="w-5 h-5 text-indigo-400 group-hover:text-teal-300 transition-colors" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
                EduPulse<span className="text-indigo-400">.AI</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                PRO AI
              </span>
            </div>
            <p className="text-[10px] text-slate-400 hidden sm:block">
              Intelligent Adaptive Learning
            </p>
          </div>
        </div>

        {/* Search Bar with Live Instant Popover */}
        <div className="flex-1 max-w-lg relative mx-2" ref={searchRef}>
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search courses, skills, tools (e.g. PyTorch, MLOps, Next.js)..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => {
                if (onOpenSearch) {
                  onOpenSearch();
                } else {
                  setIsSearchOpen(true);
                }
              }}
              className="w-full pl-10 pr-9 py-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Instant Search Results Dropdown */}
          {isSearchOpen && searchQuery.trim() !== '' && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-2xl overflow-hidden z-50 animate-in fade-in duration-200">
              <div className="p-2 border-b border-slate-800 text-[11px] font-semibold text-slate-400 flex items-center justify-between">
                <span>Matching Courses ({searchResults.length})</span>
                <span className="text-indigo-400 text-[10px]">AI Rank Matched</span>
              </div>

              {searchResults.length > 0 ? (
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/60">
                  {searchResults.map((course) => (
                    <div
                      key={course.id}
                      onClick={() => {
                        onSelectCourse?.(course);
                        setIsSearchOpen(false);
                        setSearchQuery('');
                      }}
                      className="p-3 hover:bg-slate-800/70 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={course.thumbnail}
                          alt={course.title}
                          className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-200 truncate group-hover:text-indigo-400">
                            {course.title}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate">
                            {course.category} • {course.level}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {course.baseRelevanceScore}% Match
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 group-hover:translate-x-0.5 transition-all" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center text-xs text-slate-400">
                  No courses found for "{searchQuery}". Try searching for PyTorch, LLMs, or SQL.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Actions: 3D Universe, Streak, Notifications, Dark Mode, Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* 3D Neural Universe Quick Button */}
          <button
            onClick={() => onNavigate('neural-universe')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
              currentView === 'neural-universe'
                ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white border-cyan-400/50 shadow-md shadow-cyan-500/25'
                : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300 hover:bg-cyan-900/40 hover:text-white'
            }`}
            title="Launch 3D Neural Recommendation Universe"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>3D Universe</span>
          </button>

          {/* Active Learning Streak Indicator */}
          <div
            onClick={() => onNavigate('profile')}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 hover:bg-amber-500/20 transition-all cursor-pointer"
            title="14-Day Continuous Daily Study Streak!"
          >
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
            <span className="text-xs font-bold">{user?.streakDays || 14}d Streak</span>
          </div>

          {/* Notifications Dropdown */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="relative p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-all"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-indigo-500 text-[10px] font-bold text-white flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {isNotificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-2xl overflow-hidden z-50 animate-in fade-in duration-200">
                <div className="p-3.5 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">AI Alerts & Insights</span>
                    {unreadCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded text-[10px] bg-indigo-500/20 text-indigo-300">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllRead}
                      className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium"
                    >
                      Mark all as read
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60">
                  {notifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => {
                        if (notif.courseId) {
                          const course = coursesData.find((c) => c.id === notif.courseId);
                          if (course) onSelectCourse?.(course);
                        }
                        setIsNotificationsOpen(false);
                      }}
                      className={`p-3.5 transition-colors cursor-pointer flex gap-3 ${
                        notif.unread ? 'bg-indigo-950/30 hover:bg-indigo-950/50' : 'hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="mt-0.5">
                        {notif.type === 'match' && (
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                            <Sparkles className="w-3.5 h-3.5" />
                          </div>
                        )}
                        {notif.type === 'streak' && (
                          <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                            <Flame className="w-3.5 h-3.5" />
                          </div>
                        )}
                        {notif.type === 'system' && (
                          <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                            <BrainCircuit className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <p className="text-xs font-semibold text-slate-200 truncate">{notif.title}</p>
                          <span className="text-[10px] text-slate-500">{notif.time}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-snug">{notif.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-all"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
          </button>

          {/* User Profile Menu */}
          <div className="relative" ref={profileRef}>
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all"
            >
              <img
                src={user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                alt={user?.name || 'User'}
                className="w-7 h-7 rounded-lg object-cover border border-indigo-500/40"
              />
              <span className="text-xs font-semibold text-slate-200 hidden md:block max-w-[100px] truncate">
                {user?.name?.split(' ')[0] || 'Alex'}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-2xl overflow-hidden z-50 animate-in fade-in duration-200">
                <div className="p-3.5 border-b border-slate-800">
                  <p className="text-xs font-bold text-slate-100">{user?.name}</p>
                  <p className="text-[11px] text-indigo-400 font-medium truncate">{user?.targetRole}</p>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 bg-slate-950/80 px-2 py-1 rounded-lg border border-slate-800">
                    <span>Skill Score:</span>
                    <span className="text-emerald-400 font-bold font-mono">{user?.overallSkillScore}/100</span>
                  </div>
                </div>

                <div className="p-1.5">
                  <button
                    onClick={() => {
                      onNavigate('profile');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors text-left"
                  >
                    <User className="w-4 h-4 text-indigo-400" />
                    <span>Profile & Analytics</span>
                  </button>

                  <button
                    onClick={() => {
                      onNavigate('skill-gap');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors text-left"
                  >
                    <TrendingUp className="w-4 h-4 text-teal-400" />
                    <span>Skill Gap Roadmap</span>
                  </button>

                  <button
                    onClick={() => {
                      onNavigate('recommendations');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors text-left"
                  >
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>AI Recommendations</span>
                  </button>

                  <button
                    onClick={() => {
                      onNavigate('skill-galaxy');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors text-left"
                  >
                    <Network className="w-4 h-4 text-purple-400" />
                    <span>3D Skill Galaxy</span>
                  </button>
                </div>

                <div className="p-1.5 border-t border-slate-800">
                  <button
                    onClick={() => {
                      onNavigate('admin');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors text-left"
                  >
                    <ShieldCheck className="w-4 h-4 text-rose-400" />
                    <span>Admin Dashboard</span>
                  </button>

                  <button
                    onClick={() => {
                      onNavigate('database-schema');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors text-left"
                  >
                    <Database className="w-4 h-4 text-emerald-400" />
                    <span>Database Schema</span>
                  </button>
                </div>

                <div className="p-1.5 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setIsProfileMenuOpen(false);
                      onLogout?.();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors text-left"
                  >
                    <LogOut className="w-4 h-4 text-rose-400" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
