import React from 'react';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
  Legend,
} from 'recharts';

export default function SkillRadarChart({
  data = [],
  roleTitle = 'Target Role Benchmark',
  height = 340,
  showCohort = true,
}) {
  const formattedData = data.map((item) => ({
    skill: item.skill,
    'Current Level': item.currentScore,
    'Target Benchmark': item.targetScore,
    'Cohort Average': item.benchmarkCohortAvg || 60,
    fullMark: 100,
  }));

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900/95 border border-slate-700 p-3 rounded-xl shadow-xl backdrop-blur-md text-xs">
          <p className="font-bold text-slate-100 mb-1.5 text-sm">{label}</p>
          {payload.map((entry, index) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-3 py-0.5">
              <span className="flex items-center gap-1.5" style={{ color: entry.color }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                <span>{entry.name}:</span>
              </span>
              <span className="font-mono font-bold text-slate-200">{entry.value}/100</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full relative" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="75%" data={formattedData}>
          <PolarGrid stroke="#334155" strokeDasharray="3 3" />
          <PolarAngleAxis
            dataKey="skill"
            tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 500 }}
          />
          <PolarRadiusAxis
            angle={30}
            domain={[0, 100]}
            tick={{ fill: '#64748b', fontSize: 10 }}
            stroke="#1e293b"
          />

          <Tooltip content={<CustomTooltip />} />

          {/* Current User Skill Level */}
          <Radar
            name="Your Assessed Score"
            dataKey="Current Level"
            stroke="#6366f1"
            fill="#6366f1"
            fillOpacity={0.45}
            strokeWidth={2.5}
          />

          {/* Target Role Benchmark */}
          <Radar
            name={roleTitle}
            dataKey="Target Benchmark"
            stroke="#10b981"
            fill="#10b981"
            fillOpacity={0.15}
            strokeWidth={2}
            strokeDasharray="4 4"
          />

          {/* Cohort Benchmark */}
          {showCohort && (
            <Radar
              name="Cohort Average"
              dataKey="Cohort Average"
              stroke="#f59e0b"
              fill="transparent"
              strokeWidth={1.5}
              strokeDasharray="2 2"
            />
          )}

          <Legend
            wrapperStyle={{ paddingTop: 10 }}
            formatter={(value) => <span className="text-xs text-slate-300 font-medium">{value}</span>}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
