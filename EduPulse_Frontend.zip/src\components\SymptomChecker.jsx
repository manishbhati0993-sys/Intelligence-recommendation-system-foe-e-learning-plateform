import React, { useState } from 'react';
import { Stethoscope, Mic, MicOff, Plus, X, Sparkles, CheckCircle2, User, Calendar } from 'lucide-react';

export default function SymptomChecker({
  selectedOrgan,
  bodyOrgans = [],
  bodyRegions = {},
  selectedSymptoms,
  onToggleSymptom,
  onAddCustomSymptom,
  onRunDiagnosis,
  patientData,
  onChangePatientData,
  isAnalyzing
}) {
  const [customInput, setCustomInput] = useState('');
  const [isVoiceRecording, setIsVoiceRecording] = useState(false);
  const [activeRegionKey, setActiveRegionKey] = useState('chest');

  const handleAddCustom = (e) => {
    e.preventDefault();
    if (customInput.trim()) {
      onAddCustomSymptom(customInput.trim());
      setCustomInput('');
    }
  };

  const toggleVoiceDictation = () => {
    if (isVoiceRecording) {
      setIsVoiceRecording(false);
    } else {
      setIsVoiceRecording(true);
      setTimeout(() => {
        onAddCustomSymptom("Persistent Sharp Chest Pressure");
        setIsVoiceRecording(false);
      }, 2500);
    }
  };

  const activeRegion = bodyRegions[activeRegionKey] || bodyRegions.chest;

  return (
    <div class="glass-panel p-6 space-y-6 border border-slate-800">
      
      {/* Section Header */}
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div class="flex items-center gap-3">
          <div class="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20">
            <div class="w-full h-full bg-slate-950 rounded-[10px] p-2 flex items-center justify-center">
              <Stethoscope class="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <h2 class="text-xl font-extrabold text-white">AI Symptom & Clinical Questionnaire</h2>
            <p class="text-xs text-slate-400">Select observed symptoms or click organs on the 3D model canvas</p>
          </div>
        </div>

        {/* Patient Demographics */}
        <div class="flex items-center gap-3 bg-slate-900/80 p-2 rounded-xl border border-slate-800">
          <div class="flex items-center gap-1.5 text-xs text-slate-300">
            <User class="w-4 h-4 text-cyan-400" />
            <span>Age:</span>
            <input
              type="number"
              min="1"
              max="120"
              value={patientData.age}
              onChange={(e) => onChangePatientData({ ...patientData, age: parseInt(e.target.value) || 30 })}
              class="w-12 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center font-bold text-cyan-400"
            />
          </div>

          <div class="h-4 w-px bg-slate-800" />

          <select
            value={patientData.gender}
            onChange={(e) => onChangePatientData({ ...patientData, gender: e.target.value })}
            class="bg-slate-950 text-xs text-slate-300 border border-slate-700 rounded px-2 py-1 font-semibold"
          >
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {/* Body Region Selector Tabs */}
      <div class="space-y-2">
        <label class="text-xs font-bold text-slate-300 uppercase tracking-wider">Select Body System / Region:</label>
        <div class="flex flex-wrap gap-2">
          {Object.entries(bodyRegions).map(([key, region]) => (
            <button
              key={key}
              type="button"
              onClick={() => setActiveRegionKey(key)}
              class={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeRegionKey === key
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              {region.name}
            </button>
          ))}
        </div>
      </div>

      {/* Symptoms Chips Options */}
      <div class="space-y-3">
        <label class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
          <span>{activeRegion.name} Symptoms:</span>
          <span class="text-[11px] text-cyan-400 font-medium">Click to select/unselect</span>
        </label>
        <div class="flex flex-wrap gap-2">
          {activeRegion.symptoms.map((symptom) => {
            const isSelected = selectedSymptoms.has(symptom);
            return (
              <button
                key={symptom}
                type="button"
                onClick={() => onToggleSymptom(symptom)}
                class={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-gradient-to-r from-cyan-500 to-emerald-400 text-slate-950 font-extrabold shadow-lg shadow-cyan-500/20 scale-105'
                    : 'bg-slate-900/80 border border-slate-800 text-slate-300 hover:bg-slate-800 hover:border-cyan-500/30'
                }`}
              >
                {isSelected ? <CheckCircle2 class="w-3.5 h-3.5" /> : <Plus class="w-3.5 h-3.5 text-slate-500" />}
                {symptom}
              </button>
            );
          })}
        </div>
      </div>

      {/* Voice & Custom Input Area */}
      <div class="space-y-2">
        <label class="text-xs font-bold text-slate-300 uppercase tracking-wider">Add Custom Symptom or Dictate:</label>
        <form onSubmit={handleAddCustom} class="flex items-center gap-2">
          <input
            type="text"
            placeholder="Type symptom (e.g., retrosternal squeezing, sharp dizziness)..."
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            class="flex-1 bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none transition"
          />
          <button
            type="submit"
            class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition border border-slate-700"
          >
            Add
          </button>
          <button
            type="button"
            onClick={toggleVoiceDictation}
            class={`p-2.5 rounded-xl border transition ${
              isVoiceRecording
                ? 'bg-rose-500/20 text-rose-400 border-rose-500 animate-pulse'
                : 'bg-slate-800 text-slate-400 hover:text-white border-slate-700'
            }`}
            title="Voice Dictation"
          >
            {isVoiceRecording ? <Mic class="w-4 h-4" /> : <MicOff class="w-4 h-4" />}
          </button>
        </form>
        {isVoiceRecording && (
          <p class="text-[11px] text-rose-400 font-semibold animate-pulse flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span> Listening to clinical dictation...
          </p>
        )}
      </div>

      {/* Active Selected Symptoms List */}
      {selectedSymptoms.size > 0 && (
        <div class="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-2">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
              <Sparkles class="w-3.5 h-3.5" /> Selected Clinical Presentation ({selectedSymptoms.size}):
            </span>
          </div>
          <div class="flex flex-wrap gap-1.5">
            {Array.from(selectedSymptoms).map((sym) => (
              <span
                key={sym}
                class="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-medium flex items-center gap-1.5"
              >
                {sym}
                <button
                  type="button"
                  onClick={() => onToggleSymptom(sym)}
                  class="text-slate-400 hover:text-rose-400"
                >
                  <X class="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Run AI Diagnosis Action Button */}
      <button
        type="button"
        onClick={onRunDiagnosis}
        disabled={selectedSymptoms.size === 0 || isAnalyzing}
        class={`w-full py-3.5 rounded-xl font-extrabold text-sm transition shadow-lg flex items-center justify-center gap-2 ${
          selectedSymptoms.size > 0 && !isAnalyzing
            ? 'bg-gradient-to-r from-cyan-500 via-emerald-400 to-teal-400 text-slate-950 hover:opacity-95 shadow-cyan-500/25 scale-[1.01]'
            : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
        }`}
      >
        {isAnalyzing ? (
          <>
            <Sparkles class="w-5 h-5 animate-spin" />
            Computing ICD-10 Differential Diagnosis...
          </>
        ) : (
          <>
            <Sparkles class="w-5 h-5" />
            Execute AI Clinical Diagnosis ({selectedSymptoms.size} Symptoms)
          </>
        )}
      </button>

    </div>
  );
}
