import React from 'react';
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Building2,
  ChevronRight,
  Sparkles,
  MessageSquare,
  FileText
} from 'lucide-react';

export default function ApplicationTracker({ applications = [] }) {
  const steps = [
    { num: 1, label: 'Applied' },
    { num: 2, label: 'Under Review' },
    { num: 3, label: 'Shortlisted' },
    { num: 4, label: 'Interview' },
    { num: 5, label: 'Selected' }
  ];

  return (
    <div class="max-w-5xl mx-auto py-4 space-y-6">
      
      {/* Header */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div class="flex items-center gap-2">
          <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            Real-Time ATS Tracking
          </span>
          <span class="text-xs text-slate-400">• Application Status Pipeline</span>
        </div>
        <h1 class="text-2xl sm:text-3xl font-extrabold text-white">
          Internship & Placement Application Tracker
        </h1>
        <p class="text-xs sm:text-sm text-slate-300">
          Track stage-by-stage progression of your active applications, scheduled technical interviews, and recruiter evaluation feedback.
        </p>
      </div>

      {/* Applications List */}
      <div class="space-y-4">
        {applications.length === 0 ? (
          <div class="p-12 text-center rounded-2xl bg-slate-900/60 border border-slate-800 text-slate-400 text-xs">
            No active applications yet. Browse the Marketplace to apply to matching opportunities!
          </div>
        ) : (
          applications.map((app) => (
            <div
              key={app.id}
              class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-5 hover:border-cyan-500/40 transition"
            >
              {/* Card Header */}
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono font-bold text-cyan-400">{app.id}</span>
                    <span class="text-xs text-slate-400">• Applied on {app.appliedDate}</span>
                  </div>
                  <h3 class="text-lg font-bold text-white mt-1">{app.title}</h3>
                  <p class="text-xs text-slate-400 font-medium">{app.company}</p>
                </div>

                <div class="flex items-center gap-3">
                  <span class="px-3 py-1 text-xs font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                    Match: {app.matchScore}%
                  </span>
                  <span class="px-3 py-1 text-xs font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {app.status}
                  </span>
                </div>
              </div>

              {/* Progress Steps Timeline */}
              <div class="py-3">
                <div class="grid grid-cols-5 gap-2 relative before:absolute before:top-1/2 before:-translate-y-1/2 before:inset-x-6 before:h-0.5 before:bg-slate-800">
                  {steps.map((step) => {
                    const isPassed = app.statusStep >= step.num;
                    const isCurrent = app.statusStep === step.num;
                    return (
                      <div key={step.num} class="relative flex flex-col items-center text-center space-y-1 z-10">
                        <div class={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition ${
                          isPassed
                            ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                            : 'bg-slate-950 border border-slate-800 text-slate-500'
                        }`}>
                          {isPassed ? <CheckCircle2 class="w-4 h-4" /> : step.num}
                        </div>
                        <span class={`text-[10px] font-bold ${isCurrent ? 'text-cyan-400' : isPassed ? 'text-slate-300' : 'text-slate-600'}`}>
                          {step.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Interview / Recruiter Feedback Section */}
              {(app.interviewDate || app.feedback) && (
                <div class="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2 text-xs">
                  {app.interviewDate && (
                    <div class="flex items-center gap-2 text-amber-300 font-semibold">
                      <Calendar class="w-4 h-4 text-amber-400" />
                      <span>Interview Round: {app.interviewDate} ({app.interviewMode})</span>
                    </div>
                  )}
                  {app.feedback && (
                    <div class="flex items-start gap-2 text-slate-300">
                      <MessageSquare class="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>Recruiter Note: {app.feedback}</span>
                    </div>
                  )}
                </div>
              )}

            </div>
          ))
        )}
      </div>

    </div>
  );
}
