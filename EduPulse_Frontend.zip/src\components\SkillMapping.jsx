import React from 'react';
import { SKILL_BENCHMARKS } from '../data/portalData';
import { Target, Sparkles, BookOpen, ArrowRight, ShieldCheck, CheckCircle2, TrendingUp } from 'lucide-react';

export default function SkillMapping({ userSkills = [], onSelectCourse }) {
  const targetCareerPaths = [
    {
      title: 'Ayush Phytomedicine R&D Specialist',
      matchPct: 92,
      demandLevel: 'High Demand',
      avgSalary: '₹6.5 - 10 LPA',
      skillsMatched: ['Ayurvedic Pharmacognosy', 'HPLC & Spectroscopy', 'Herbal Drug Standardization'],
      gapSkillsNeeded: ['AI in Phytochemistry'],
      topRecruiters: ['Dabur Ayush', 'Patanjali Research', 'Himalaya Wellness']
    },
    {
      title: 'AI HealthTech & Phytochemistry Analyst',
      matchPct: 78,
      demandLevel: 'Emerging High Growth',
      avgSalary: '₹8.0 - 14 LPA',
      skillsMatched: ['Ayurvedic Pharmacognosy', 'Scientific Paper Writing'],
      gapSkillsNeeded: ['AI in Phytochemistry', 'Bioinformatics & Molecular Docking'],
      topRecruiters: ['Patanjali BioResearch', 'CSIR-CIMAP', 'MedGenome']
    },
    {
      title: 'AYUSH Clinical Trial Operations Associate',
      matchPct: 84,
      demandLevel: 'Stable Core',
      avgSalary: '₹5.5 - 8.5 LPA',
      skillsMatched: ['Clinical Trial Protocols (AYUSH GCP)', 'Good Manufacturing Practices (GMP)'],
      gapSkillsNeeded: ['Scientific Patenting & IPR'],
      topRecruiters: ['Charak Pharma', 'Baidyanath', 'AIIA New Delhi']
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Banner */}
      <div className="glass-panel p-6 sm:p-8 border border-cyan-500/30 relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Target className="w-3.5 h-3.5" /> Core Feature #2 • Intelligent Skill Mapping & Career Paths
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Skill-to-Industry <span className="gradient-text">Mapping & Growth Pathways</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Our recommendation engine analyzes your validated skill profile to match compatible career tracks, high-growth industry roles, and targeted skill-development programs.
          </p>
        </div>
      </div>

      {/* Career Pathways Cards */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <span>Top Matched Industry Career Pathways</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {targetCareerPaths.map((path, idx) => (
            <div
              key={idx}
              className="glass-panel p-6 border border-slate-800 hover:border-cyan-500/40 transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {path.matchPct}% Skill Fit
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">{path.demandLevel}</span>
                </div>

                <h4 className="text-base font-bold text-white leading-snug">{path.title}</h4>
                <p className="text-xs text-cyan-400 font-extrabold">Est. Package: {path.avgSalary}</p>

                {/* Skills Matched */}
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Strong Skills Matched:</span>
                  <div className="flex flex-wrap gap-1">
                    {path.skillsMatched.map((s, i) => (
                      <span key={i} className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        ✓ {s}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Gap Skills Needed */}
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Recommended Upgrades:</span>
                  <div className="flex flex-wrap gap-1">
                    {path.gapSkillsNeeded.map((s, i) => (
                      <span key={i} className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        ⚡ {s}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Recruiters List */}
              <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                <span className="font-bold text-white block">Key Hiring Partners:</span>
                <span>{path.topRecruiters.join(' • ')}</span>
              </div>

            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
