import React from 'react';
import ThreeNeuralUniverse from './ThreeNeuralUniverse';

const RecommendationConstellation = ({
  user,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onInspectNode,
}) => {
  return (
    <div className="w-full h-full min-h-[550px]">
      <ThreeNeuralUniverse
        user={user}
        onSelectCourse={onSelectCourse}
        onToggleBookmark={onToggleBookmark}
        onEnroll={onEnroll}
        onInspectNode={onInspectNode}
      />
    </div>
  );
};

export default RecommendationConstellation;
