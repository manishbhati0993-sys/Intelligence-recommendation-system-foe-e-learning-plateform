import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Lock,
  Play,
  BookOpen,
  Award,
  AlertTriangle,
  ChevronRight,
  X,
  Target,
  Layers,
  Brain
} from 'lucide-react';
import { adaptiveLearningPathsData } from '../data/mockData';

export default function AdaptiveLearningPath({
  user,
  onSelectCourse,
  onEnroll,
}) {
  const [selectedNode, setSelectedNode] = useState(null);
  const [pathSteps, setPathSteps] = useState(adaptiveLearningPathsData);

  const handleNodeClick = (step) => {
    setSelectedNode(step);
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Layers className="w-4 h-4" />
            </span>
            <h2 className="text-xl font-extrabold text-white">Your Adaptive Learning Path</h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Interactive 3D Pathway
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Dynamically sequenced roadmap for <strong className="text-slate-200">{user?.targetRole || 'Become a Data Scientist'}</strong>. Prerequisite performance adapts the path.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
            <span>Completed</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.8)] animate-pulse" />
            <span>Active</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
            <span>Upcoming</span>
          </div>
        </div>
      </div>

      {/* Visual Roadmap Nodes Sequence */}
      <div className="relative p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-2xl">
        {/* Ambient Glow */}
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-40 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-96 h-40 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Nodes Container */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 sm:gap-4">
          {pathSteps.map((step, idx) => {
            const isCompleted = step.status === 'completed';
            const isCurrent = step.status === 'current';
            const isUpcoming = step.status === 'upcoming';
            const isLocked = step.status === 'locked';

            return (
              <div
                key={step.id}
                onClick={() => handleNodeClick(step)}
                className={`group relative flex flex-col p-4 rounded-2xl cursor-pointer transition-all duration-300 ${
                  isCompleted
                    ? 'bg-emerald-950/20 border border-emerald-500/40 hover:border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.15)] hover:scale-105'
                    : isCurrent
                    ? 'bg-gradient-to-b from-indigo-950/60 to-slate-900/90 border-2 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.35)] scale-[1.03]'
                    : isUpcoming
                    ? 'bg-slate-950/60 border border-slate-800 hover:border-slate-700 hover:scale-102'
                    : 'bg-slate-950/40 border border-slate-800/50 opacity-60 hover:opacity-80'
                }`}
              >
                {/* Connecting Line (for desktop) */}
                {idx < pathSteps.length - 1 && (
                  <div className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-0.5 bg-gradient-to-r from-slate-700 to-slate-800 z-0 pointer-events-none" />
                )}

                {/* Node Top Indicator */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span
                    className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-mono font-bold ${
                      isCompleted
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : isCurrent
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/50'
                        : isUpcoming
                        ? 'bg-slate-800 text-slate-300'
                        : 'bg-slate-900 text-slate-600'
                    }`}
                  >
                    {isCompleted ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : isLocked ? <Lock className="w-3.5 h-3.5" /> : step.stepNumber}
                  </span>

                  {step.isPrerequisiteAlert && (
                    <span className="p-1 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30" title="Foundational Prerequisite Flag">
                      <AlertTriangle className="w-3.5 h-3.5" />
                    </span>
                  )}

                  {isCurrent && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 animate-pulse">
                      Active
                    </span>
                  )}
                </div>

                {/* Step Title */}
                <h3 className="font-bold text-sm text-slate-100 group-hover:text-indigo-400 transition-colors line-clamp-1 mb-1">
                  {step.title}
                </h3>

                <p className="text-[11px] text-slate-400 line-clamp-2 mb-3 leading-relaxed">
                  {step.courseTitle}
                </p>

                {/* Progress or Score Pill */}
                <div className="mt-auto pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  {isCompleted ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-3 h-3" />
                      {step.score}% Mastered
                    </span>
                  ) : isCurrent ? (
                    <span className="text-indigo-400 font-bold font-mono">
                      {step.progress}% Done
                    </span>
                  ) : (
                    <span className="text-slate-500 font-medium">
                      {step.duration.split(' ')[0]} {step.duration.split(' ')[1]}
                    </span>
                  )}
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Node Details Modal / Drawer */}
      {selectedNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-indigo-500/30 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-5 text-slate-100">
            {/* Header */}
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] uppercase font-bold tracking-wider text-indigo-400">
                  Milestone Step {selectedNode.stepNumber} of 6
                </span>
                <h3 className="text-xl font-bold text-white mt-0.5">
                  {selectedNode.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  {selectedNode.courseTitle}
                </p>
              </div>
              <button
                onClick={() => setSelectedNode(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Prerequisite Alert Banner if present */}
            {selectedNode.isPrerequisiteAlert && (
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-semibold">Adaptive Recommendation Notice</strong>
                  <span>{selectedNode.alertReason}</span>
                </div>
              </div>
            )}

            {/* Description */}
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
              {selectedNode.description}
            </p>

            {/* Metadata Grid */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Estimated Duration</span>
                <span className="text-slate-200 font-semibold mt-0.5 block">{selectedNode.duration}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Status</span>
                <span className={`font-semibold mt-0.5 block capitalize ${
                  selectedNode.status === 'completed'
                    ? 'text-emerald-400'
                    : selectedNode.status === 'current'
                    ? 'text-indigo-400'
                    : 'text-slate-400'
                }`}>
                  {selectedNode.status === 'completed' ? `Completed (${selectedNode.score}%)` : selectedNode.status}
                </span>
              </div>
            </div>

            {/* Skills Gained */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Skills Gained in this Step
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {selectedNode.skillsGained?.map((sk, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg text-xs font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                  >
                    {sk}
                  </span>
                ))}
              </div>
            </div>

            {/* Recommended Resources List */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Recommended Resources & Quizzes
              </h4>
              <div className="space-y-2">
                {selectedNode.recommendedResources?.map((res, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                      <span className="text-slate-200">{res.title}</span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                      {res.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedNode(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setSelectedNode(null);
                  onEnroll?.(selectedNode.courseId);
                }}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 flex items-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{selectedNode.status === 'completed' ? 'Review Material' : 'Open Milestone'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
