/**
 * EduRecommend API Service (React ES Module)
 * Connects React Frontend to FastAPI backend on http://127.0.0.1:8000/api/v1
 */

const API_BASE = (typeof window !== 'undefined' && window.EDU_API_BASE)
  || import.meta.env?.VITE_API_BASE_URL
  || 'http://127.0.0.1:8000/api/v1';

let accessToken = null;
let currentUser = null;
let refreshPromise = null;

async function request(endpoint, options = {}, isRetry = false) {
  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  }

  const config = {
    ...options,
    headers,
    credentials: options.credentials || 'include',
  };

  let response;
  try {
    response = await fetch(url, config);
  } catch (networkErr) {
    console.warn(`[EduApi] Request to ${url} failed:`, networkErr);
    throw new Error(`Backend connection to ${API_BASE} unavailable.`);
  }

  if (response.status === 401 && !isRetry && !endpoint.startsWith('/auth/')) {
    try {
      await refreshSession();
      return await request(endpoint, options, true);
    } catch {
      accessToken = null;
      currentUser = null;
      throw new Error('Session expired. Please log in again.');
    }
  }

  if (response.status === 204) {
    return null;
  }

  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json')
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    const errorMsg = (data && data.error && data.error.message)
      || (data && data.detail)
      || `Request failed with status ${response.status}`;
    const err = new Error(errorMsg);
    err.status = response.status;
    err.data = data;
    throw err;
  }

  return data;
}

async function refreshSession() {
  if (refreshPromise) return refreshPromise;

  refreshPromise = (async () => {
    try {
      const res = await fetch(`${API_BASE}/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'fetch',
        },
        credentials: 'include',
      });

      if (!res.ok) {
        accessToken = null;
        currentUser = null;
        throw new Error('Refresh failed');
      }

      const data = await res.json();
      accessToken = data.access_token || data.token || null;
      if (data.user) currentUser = data.user;
      return accessToken;
    } finally {
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

export const EduApi = {
  get API_BASE() { return API_BASE; },
  get accessToken() { return accessToken; },
  get currentUser() { return currentUser; },

  setAccessToken(token) { accessToken = token; },
  setCurrentUser(user) { currentUser = user; },

  async restoreSession() {
    try {
      await refreshSession();
      if (accessToken) {
        currentUser = await this.getProfile();
        return currentUser;
      }
    } catch {
      accessToken = null;
      currentUser = null;
    }
    return null;
  },

  async login(email, password) {
    const data = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    accessToken = data.access_token || data.token;
    currentUser = data.user || (await this.getProfile());
    return { token: accessToken, user: currentUser };
  },

  async register(userData) {
    const data = await request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    accessToken = data.access_token || data.token;
    currentUser = data.user || (await this.getProfile());
    return { token: accessToken, user: currentUser };
  },

  async logout() {
    try {
      await request('/auth/logout', {
        method: 'POST',
        headers: { 'X-Requested-With': 'fetch' },
      });
    } catch (err) {
      console.warn('[EduApi] Logout returned:', err);
    } finally {
      accessToken = null;
      currentUser = null;
    }
  },

  async getProfile() {
    const profile = await request('/me');
    currentUser = profile;
    return profile;
  },

  async updateProfile(updates) {
    const profile = await request('/me', {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
    currentUser = profile;
    return profile;
  },

  async updateSkills(skillsList) {
    return await request('/me/skills', {
      method: 'PUT',
      body: JSON.stringify(skillsList),
    });
  },

  async getCourses(params = {}) {
    const query = new URLSearchParams();
    if (params.q) query.set('q', params.q);
    if (params.category && params.category !== 'All') query.set('category', params.category);
    if (params.level && params.level !== 'All') query.set('level', params.level);
    if (params.page) query.set('page', params.page);
    if (params.limit) query.set('limit', params.limit);
    const qs = query.toString();
    return await request(`/courses${qs ? `?${qs}` : ''}`);
  },

  async getCourse(courseId) {
    return await request(`/courses/${courseId}`);
  },

  async getRecommendations(limit = 6, refresh = false) {
    return await request(`/me/recommendations?limit=${limit}&refresh=${refresh}`);
  },

  async startCourse(courseId) {
    return await request(`/courses/${courseId}/start`, { method: 'POST' });
  },

  async getEnrollments() {
    return await request('/me/enrollments');
  },

  async updateEnrollmentProgress(enrollmentId, progressPct) {
    return await request(`/enrollments/${enrollmentId}`, {
      method: 'PATCH',
      body: JSON.stringify({ progress_pct: progressPct }),
    });
  },

  async getLearningPath() {
    return await request('/me/learning-path');
  },

  async regenerateLearningPath() {
    return await request('/me/learning-path/regenerate', { method: 'POST' });
  },

  async getProgress() {
    return await request('/me/progress');
  },

  async trackEvents(events) {
    return await request('/interactions', {
      method: 'POST',
      body: JSON.stringify(events),
    });
  },

  async sendFeedback(rating, message = '', courseId = null) {
    const payload = { rating: Number(rating) };
    if (message) payload.message = message;
    if (courseId) payload.course_id = courseId;
    return await request('/feedback', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async checkHealth() {
    try {
      const root = API_BASE.replace('/api/v1', '');
      const res = await fetch(`${root}/health`);
      return await res.json();
    } catch (err) {
      return { status: 'down', error: err.message };
    }
  },
};

export default EduApi;
