import React from 'react';
import { SearchX, Filter, RotateCcw, Sparkles } from 'lucide-react';

export default function EmptyState({
  title = 'No Matching Recommendations Found',
  description = 'Try broadening your filter criteria or lowering the minimum AI match threshold.',
  onReset,
  icon: Icon = SearchX,
  actionLabel = 'Reset All Filters',
}) {
  return (
    <div className="col-span-full py-16 px-6 flex flex-col items-center justify-center text-center bg-slate-900/40 border border-slate-800 rounded-2xl">
      <div className="w-16 h-16 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-slate-400 mb-4 shadow-inner">
        <Icon className="w-8 h-8 text-slate-400" />
      </div>
      <h3 className="text-lg font-bold text-slate-100 mb-1.5">{title}</h3>
      <p className="text-xs text-slate-400 max-w-sm mb-6 leading-relaxed">
        {description}
      </p>

      {onReset && (
        <button
          onClick={onReset}
          className="py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-2 transition-all shadow-md shadow-indigo-600/20 active:scale-95"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );
}
