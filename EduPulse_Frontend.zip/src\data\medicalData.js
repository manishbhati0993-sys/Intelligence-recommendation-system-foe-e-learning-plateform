/**
 * MediPulse AI - Medical Knowledge Base & Clinical Dataset
 */

export const MEDICAL_DATA = {
  bodyOrgans: [
    { id: 'brain', name: 'Brain & Cranial Nerves', region: 'head', symptoms: ['Headache', 'Dizziness', 'Vision Blur', 'Memory Fog'] },
    { id: 'lungs', name: 'Lungs & Bronchial Tree', region: 'chest', symptoms: ['Shortness of Breath', 'Persistent Cough', 'Wheezing', 'Chest Tightness'] },
    { id: 'heart', name: 'Heart & Cardiovascular', region: 'chest', symptoms: ['Chest Pain', 'Palpitations', 'Irregular Heartbeat', 'Dizziness'] },
    { id: 'stomach', name: 'Stomach & GI Tract', region: 'abdomen', symptoms: ['Abdominal Pain', 'Nausea', 'Vomiting', 'Acid Reflux'] },
    { id: 'liver', name: 'Liver & Gallbladder', region: 'abdomen', symptoms: ['Jaundice (Yellowing)', 'Loss of Appetite', 'Abdominal Swelling', 'Fatigue'] },
    { id: 'kidneys', name: 'Kidneys & Renal', region: 'abdomen', symptoms: ['Lower Back Pain', 'Dark Urine', 'Swelling in Legs', 'Fatigue'] },
    { id: 'spine', name: 'Spine & Musculoskeletal', region: 'limbs', symptoms: ['Joint Pain', 'Muscle Weakness', 'Numbness / Tingling', 'Limited Mobility'] },
    { id: 'skin', name: 'Integumentary (Skin)', region: 'skin', symptoms: ['Skin Rash', 'Itching', 'Lesion or Discoloration', 'Hives'] }
  ],

  bodyRegions: {
    head: {
      name: "Head & Neck",
      symptoms: ["Headache", "Dizziness", "Vision Blur", "Sore Throat", "Neck Stiffness", "Facial Pain", "Tinnitus"]
    },
    chest: {
      name: "Chest & Respiratory",
      symptoms: ["Chest Pain", "Shortness of Breath", "Persistent Cough", "Palpitations", "Wheezing", "Tightness in Chest"]
    },
    abdomen: {
      name: "Abdomen & Digestive",
      symptoms: ["Abdominal Pain", "Nausea", "Vomiting", "Loss of Appetite", "Bloating", "Acid Reflux", "Diarrhea"]
    },
    limbs: {
      name: "Arms & Legs (Musculoskeletal)",
      symptoms: ["Joint Pain", "Muscle Weakness", "Swelling in Legs", "Numbness / Tingling", "Limited Mobility", "Tremors"]
    },
    general: {
      name: "General / Systemic",
      symptoms: ["High Fever", "Fatigue / Exhaustion", "Chills & Sweats", "Unexplained Weight Loss", "Night Sweats", "Dehydration"]
    },
    skin: {
      name: "Skin & Dermatological",
      symptoms: ["Skin Rash", "Itching", "Lesion or Discoloration", "Hives", "Dry Flaky Skin", "Jaundice (Yellowing)"]
    }
  },

  conditions: [
    {
      id: "COND-001",
      name: "Acute Bronchitis / Lower Respiratory Infection",
      icd10: "J20.9",
      category: "Respiratory",
      urgency: "Moderate",
      urgencyCode: "routine",
      matchKeywords: ["Persistent Cough", "Shortness of Breath", "High Fever", "Wheezing", "Fatigue / Exhaustion", "Chest Tightness"],
      baseConfidence: 88,
      specialist: "Pulmonologist / General Physician",
      summary: "Inflammation of the bronchial tubes leading to cough, mucus production, and mild shortness of breath.",
      recommendations: [
        "Get plenty of rest and drink warmed fluids.",
        "Use a cool-mist humidifier in your sleeping area.",
        "Monitor oxygen saturation with a pulse oximeter.",
        "Seek emergency care if breathing becomes severely laboured."
      ],
      medicationNotice: "OTC bronchodilators or mucolytics may be advised by a clinician. Avoid self-medicating with antibiotics unless prescribed."
    },
    {
      id: "COND-002",
      name: "Angina Pectoris / Coronary Ischemia Risk",
      icd10: "I20.9",
      category: "Cardiovascular",
      urgency: "Emergency",
      urgencyCode: "emergency",
      matchKeywords: ["Chest Pain", "Tightness in Chest", "Shortness of Breath", "Palpitations", "Dizziness", "Chills & Sweats", "Irregular Heartbeat"],
      baseConfidence: 94,
      specialist: "Cardiologist / Emergency Medicine",
      summary: "Reduced blood flow to the heart muscle causing pressure or squeezing tightness in the chest.",
      recommendations: [
        "IMMEDIATE ACTION: Rest immediately and dial Emergency Services (911 / 108).",
        "Do not engage in physical exertion.",
        "Keep aspirin available if recommended by your emergency hotline.",
        "Obtain an urgent 12-lead ECG and Troponin blood check."
      ],
      medicationNotice: "Sublingual Nitroglycerin under strict medical supervision."
    },
    {
      id: "COND-003",
      name: "Migraine with Aura / Tension Headache",
      icd10: "G43.909",
      category: "Neurological",
      urgency: "Mild",
      urgencyCode: "self-care",
      matchKeywords: ["Headache", "Vision Blur", "Nausea", "Dizziness", "Fatigue / Exhaustion", "Memory Fog"],
      baseConfidence: 85,
      specialist: "Neurologist / Primary Care",
      summary: "Neurological condition characterized by intense throbbing pain, sensory sensitivity, and potential visual disturbances.",
      recommendations: [
        "Rest in a quiet, darkened room.",
        "Apply cold compresses to the forehead or nape of neck.",
        "Maintain consistent hydration and avoid sensory triggers.",
        "Keep a daily headache diary tracking onset and dietary factors."
      ],
      medicationNotice: "NSAIDs (e.g. Ibuprofen) or Triptans as prescribed by physician."
    },
    {
      id: "COND-004",
      name: "Acute Gastroenteritis",
      icd10: "A09",
      category: "Gastrointestinal",
      urgency: "Moderate",
      urgencyCode: "routine",
      matchKeywords: ["Abdominal Pain", "Nausea", "Vomiting", "Diarrhea", "Loss of Appetite", "High Fever", "Chills & Sweats", "Bloating"],
      baseConfidence: 89,
      specialist: "Gastroenterologist",
      summary: "Intestinal infection marked by watery diarrhea, abdominal cramps, nausea or vomiting, and fever.",
      recommendations: [
        "Rehydrate frequently using Oral Rehydration Salts (ORS) or electrolyte solutions.",
        "Follow a gentle BRAT diet (Bananas, Rice, Applesauce, Toast).",
        "Monitor for dehydration symptoms (dark urine, dry mouth, dizziness).",
        "Consult doctor if symptoms persist past 48 hours."
      ],
      medicationNotice: "Probiotics & antiemetics if advised. Avoid antimotility meds if bacterial infection is suspected."
    },
    {
      id: "COND-005",
      name: "Hypertensive Crisis Risk / Uncontrolled Hypertension",
      icd10: "I16.9",
      category: "Cardiovascular",
      urgency: "Emergency",
      urgencyCode: "emergency",
      matchKeywords: ["Headache", "Dizziness", "Vision Blur", "Tinnitus", "Chest Pain", "Palpitations", "Neck Stiffness"],
      baseConfidence: 91,
      specialist: "Cardiologist / Nephrologist",
      summary: "Severely elevated systemic blood pressure with risk of end-organ vascular strain.",
      recommendations: [
        "Re-check blood pressure twice after 5 minutes of quiet rest.",
        "Contact urgent care clinic if Systolic exceeds 180 mmHg or Diastolic exceeds 120 mmHg.",
        "Limit sodium intake immediately and avoid caffeine/stimulants.",
        "Prepare current medication list for clinical evaluation."
      ],
      medicationNotice: "Antihypertensive regimen adjustment under physician guidance."
    },
    {
      id: "COND-006",
      name: "Allergic Dermatitis / Urticaria",
      icd10: "L23.9",
      category: "Dermatology",
      urgency: "Mild",
      urgencyCode: "self-care",
      matchKeywords: ["Skin Rash", "Itching", "Lesion or Discoloration", "Hives", "Dry Flaky Skin"],
      baseConfidence: 86,
      specialist: "Dermatologist / Allergist",
      summary: "Inflammatory skin reaction triggered by contact allergen, food, or immune response.",
      recommendations: [
        "Avoid scratch impulses to prevent secondary bacterial skin infections.",
        "Apply soothing calamine or fragrance-free moisturizing barrier cream.",
        "Take cool oatmeal baths to alleviate generalized itching.",
        "Identify and isolate recent allergen exposures (soaps, plants, cosmetics)."
      ],
      medicationNotice: "Oral H1 Antihistamines (Cetirizine/Loratadine) and topical hydrocortisone."
    }
  ],

  scans: [
    {
      id: "SCAN-01",
      title: "3D Volumetric Pulmonary Scan & Bronchial Tree",
      type: "3D Radiology AI",
      image: "/assets/scan_3d_lungs.jpg",
      heatmapColor: "rgba(245, 158, 11, 0.35)",
      findings: [
        { title: "Amber Opacity Zone (RUL)", confidence: "96.8%", location: "Right Upper Lobe (Seg 3)", status: "High Risk" },
        { title: "Bronchovascular Markings", confidence: "91.2%", location: "Bilateral Main Stem", status: "Moderate" },
        { title: "Cardiac Silhouette & Ribcage Integrity", confidence: "99.1%", location: "Thoracic Cage", status: "Clear" }
      ],
      summary: "3D Volumetric AI analysis detected focal consolidation in the Right Upper Lobe (315.8 cm³). Increased vascularity noted. High probability of interstitial inflammatory change."
    },
    {
      id: "SCAN-02",
      title: "Dermoscopy - Cutaneous Lesion",
      type: "Dermatology",
      image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=800&q=80",
      heatmapColor: "rgba(245, 158, 11, 0.4)",
      findings: [
        { title: "Asymmetric Pigment Network", confidence: "89.6%", location: "x: 50%, y: 45%", status: "Atypical" },
        { title: "Irregular Border Contour", confidence: "83.1%", location: "x: 52%, y: 40%", status: "Borderline" },
        { title: "Uniform Diameter < 6mm", confidence: "95.0%", location: "x: 48%, y: 52%", status: "Clear" }
      ],
      summary: "Atypical melanocytic nevus exhibiting mild structural asymmetry. ABCDE criteria score is 3.2/10. Routine dermatological mapping advised."
    },
    {
      id: "SCAN-03",
      title: "Retinal Fundus Photography",
      type: "Ophthalmology",
      image: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80",
      heatmapColor: "rgba(16, 185, 129, 0.4)",
      findings: [
        { title: "Optic Disc Margin Sharpness", confidence: "99.1%", location: "x: 32%, y: 46%", status: "Normal" },
        { title: "Macular Foveal Reflex Intact", confidence: "97.4%", location: "x: 60%, y: 50%", status: "Normal" },
        { title: "Microaneurysms Detected: 0", confidence: "99.5%", location: "Full Field", status: "Clear" }
      ],
      summary: "No signs of diabetic retinopathy or hypertensive vascular nicking detected. Macular region clear."
    }
  ],

  doctors: [
    {
      id: "DOC-01",
      name: "Dr. Elena Vance, MD",
      specialty: "Cardiologist",
      hospital: "St. Jude Heart Institute",
      rating: "4.9 ★",
      distance: "1.2 miles away",
      available: "Today at 2:30 PM",
      avatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=200&q=80"
    },
    {
      id: "DOC-02",
      name: "Dr. Marcus Thorne, MD",
      specialty: "Pulmonologist",
      hospital: "Metro General Hospital",
      rating: "4.8 ★",
      distance: "2.5 miles away",
      available: "Tomorrow at 10:00 AM",
      avatar: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=200&q=80"
    },
    {
      id: "DOC-03",
      name: "Dr. Sophia Patel, MD",
      specialty: "Gastroenterologist",
      hospital: "City Health Care Center",
      rating: "4.9 ★",
      distance: "0.8 miles away",
      available: "Today at 4:15 PM",
      avatar: "https://images.unsplash.com/photo-1594824813566-78a9c2d1264c?auto=format&fit=crop&w=200&q=80"
    },
    {
      id: "DOC-04",
      name: "Dr. David Kim, MD",
      specialty: "Neurologist",
      hospital: "University Neuroscience Clinic",
      rating: "4.9 ★",
      distance: "3.4 miles away",
      available: "Thursday at 11:30 AM",
      avatar: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=200&q=80"
    },
    {
      id: "DOC-05",
      name: "Dr. Rachel Green, MD",
      specialty: "Dermatologist",
      hospital: "Skin & Laser Center",
      rating: "4.9 ★",
      distance: "2.1 miles away",
      available: "Friday at 9:00 AM",
      avatar: "https://images.unsplash.com/photo-1594824813566-78a9c2d1264c?auto=format&fit=crop&w=200&q=80"
    }
  ],

  vitalsNorms: {
    heartRate: { min: 60, max: 100, unit: "BPM", normalRange: "60 - 100 BPM" },
    bpSystolic: { min: 90, max: 120, unit: "mmHg", normalRange: "90 - 120 mmHg" },
    bpDiastolic: { min: 60, max: 80, unit: "mmHg", normalRange: "60 - 80 mmHg" },
    spo2: { min: 95, max: 100, unit: "%", normalRange: "95% - 100%" },
    temp: { min: 97.0, max: 99.0, unit: "°F", normalRange: "97.0°F - 99.0°F" }
  }
};
