import React, { useState } from 'react';
import {
  FileCheck,
  Clock,
  Award,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Check
} from 'lucide-react';
import { ASSESSMENT_QUESTIONS } from '../data/portalData';

export default function SkillAssessment({ setActiveTab, onAssessmentComplete }) {
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [assessmentResult, setAssessmentResult] = useState(null);

  const questions = ASSESSMENT_QUESTIONS;
  const currentQ = questions[currentQuestionIdx];

  const handleSelectOption = (optionIndex) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [currentQ.id]: optionIndex
    });
  };

  const handleNext = () => {
    if (currentQuestionIdx < questions.length - 1) {
      setCurrentQuestionIdx(currentQuestionIdx + 1);
    }
  };

  const handlePrev = () => {
    if (currentQuestionIdx > 0) {
      setCurrentQuestionIdx(currentQuestionIdx - 1);
    }
  };

  const handleSubmitAssessment = async () => {
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/assess', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers: selectedAnswers })
      });
      const data = await res.json();
      if (data.success) {
        setAssessmentResult(data);
        if (onAssessmentComplete) onAssessmentComplete(data);
        setIsSubmitting(false);
        return;
      }
    } catch (err) {
      // Offline fallback grading
      let correctCount = 0;
      const breakdown = questions.map((q) => {
        const isCorrect = selectedAnswers[q.id] === q.correctOption;
        if (isCorrect) correctCount++;
        return {
          id: q.id,
          skillTested: q.skillTested,
          category: q.category,
          isCorrect,
          weight: q.weight
        };
      });

      const overallScore = Math.round((correctCount / questions.length) * 100);
      const fallbackData = {
        success: true,
        overallScore,
        correctCount,
        totalQuestions: questions.length,
        breakdown,
        feedback: overallScore >= 80
          ? 'Outstanding mastery of core backend architectures and query optimizations. Recommended for immediate Tier-1 interview fast-tracking.'
          : overallScore >= 60
          ? 'Good functional comprehension. Minor skill gaps identified in Spring Boot microservices and REST idempotency.'
          : 'Foundational concepts require strengthening before applying to Tier-1 backend roles.'
      };

      setAssessmentResult(fallbackData);
      if (onAssessmentComplete) onAssessmentComplete(fallbackData);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRetake = () => {
    setSelectedAnswers({});
    setCurrentQuestionIdx(0);
    setAssessmentResult(null);
  };

  return (
    <div class="max-w-4xl mx-auto py-4 space-y-6">
      
      {/* Header Banner */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              Adaptive Technical Assessment
            </span>
            <span class="text-xs text-slate-400">• Java & Cloud Backend</span>
          </div>
          <div class="flex items-center gap-1.5 text-xs font-mono text-amber-400 bg-amber-500/10 px-3 py-1 rounded-lg border border-amber-500/20">
            <Clock class="w-3.5 h-3.5" /> 15:00 Mins Allotted
          </div>
        </div>

        <h1 class="text-2xl sm:text-3xl font-extrabold text-white">
          AI Industry Competency Evaluation
        </h1>
        <p class="text-xs sm:text-sm text-slate-300">
          This assessment tests production engineering concepts (Java 17+ internals, REST idempotency, PostgreSQL indexes, and Spring Boot architecture) to calibrate your official Industry Readiness Score.
        </p>
      </div>

      {!assessmentResult ? (
        /* QUIZ QUESTION VIEW */
        <div class="p-6 sm:p-8 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-6">
          
          {/* Progress Indicator */}
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Question {currentQuestionIdx + 1} of {questions.length}</span>
            <span class="font-bold text-cyan-400">Category: {currentQ.category}</span>
          </div>
          <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              class="bg-gradient-to-r from-cyan-500 to-emerald-500 h-full transition-all duration-300"
              style={{ width: `${((currentQuestionIdx + 1) / questions.length) * 100}%` }}
            ></div>
          </div>

          {/* Question Body */}
          <div class="space-y-4 pt-2">
            <div class="inline-block px-2.5 py-0.5 rounded text-[11px] font-bold bg-slate-800 text-cyan-300">
              Skill Tested: {currentQ.skillTested} ({currentQ.difficulty})
            </div>
            <h3 class="text-base sm:text-lg font-bold text-white leading-relaxed">
              {currentQ.question}
            </h3>

            {/* Options */}
            <div class="space-y-3 pt-2">
              {currentQ.options.map((opt, idx) => {
                const isSelected = selectedAnswers[currentQ.id] === idx;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectOption(idx)}
                    class={`w-full p-4 rounded-xl text-left text-xs sm:text-sm font-medium transition flex items-center justify-between border ${
                      isSelected
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200 font-bold shadow-lg shadow-cyan-500/10'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <div class="flex items-center gap-3">
                      <span class={`w-6 h-6 rounded-full text-xs flex items-center justify-center font-bold ${
                        isSelected ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{opt}</span>
                    </div>
                    {isSelected && <Check class="w-4 h-4 text-cyan-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Nav Buttons */}
          <div class="flex items-center justify-between pt-6 border-t border-slate-800">
            <button
              onClick={handlePrev}
              disabled={currentQuestionIdx === 0}
              class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 disabled:opacity-40 transition"
            >
              Previous
            </button>

            {currentQuestionIdx < questions.length - 1 ? (
              <button
                onClick={handleNext}
                class="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition"
              >
                Next Question
              </button>
            ) : (
              <button
                onClick={handleSubmitAssessment}
                disabled={isSubmitting}
                class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-xs transition shadow-lg shadow-emerald-500/20"
              >
                {isSubmitting ? 'Evaluating with AI...' : 'Submit Assessment'}
              </button>
            )}
          </div>

        </div>
      ) : (
        /* ASSESSMENT RESULTS SUMMARY */
        <div class="p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-emerald-500/40 space-y-6">
          
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div>
              <span class="px-3 py-1 text-xs font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">
                Assessment Completed
              </span>
              <h2 class="text-2xl font-extrabold text-white mt-2">
                Overall Score: <span class="text-emerald-400">{assessmentResult.overallScore}%</span>
              </h2>
              <p class="text-xs text-slate-400 mt-1">
                {assessmentResult.correctCount} of {assessmentResult.totalQuestions} questions answered accurately
              </p>
            </div>

            <div class="flex items-center gap-3">
              <button
                onClick={handleRetake}
                class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition flex items-center gap-1.5"
              >
                <RotateCcw class="w-3.5 h-3.5" /> Retake Test
              </button>
              <button
                onClick={() => setActiveTab('skill_analysis')}
                class="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center gap-1.5"
              >
                <Sparkles class="w-3.5 h-3.5" /> View AI Skill Gap
              </button>
            </div>
          </div>

          <div class="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
            <strong class="text-emerald-400">AI Evaluation Summary:</strong> {assessmentResult.summary}
          </div>

          {/* Evaluated Skills Breakdown Table */}
          <div class="space-y-3">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400">Skill-by-Skill Performance</h3>
            <div class="space-y-2">
              {assessmentResult.evaluatedSkills?.map((item, idx) => (
                <div key={idx} class="p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div class="text-xs font-bold text-white flex items-center gap-2">
                      {item.skill}
                      <span class={`px-2 py-0.5 text-[10px] font-bold rounded ${item.status === 'Strong' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                        {item.status}
                      </span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">{item.recommendation}</div>
                  </div>
                  <div class="text-right shrink-0">
                    <span class="text-xs font-mono font-bold text-cyan-400">Score: {item.userLevel}%</span>
                    <div class="text-[10px] text-slate-500">Benchmark: {item.industryDemand}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
