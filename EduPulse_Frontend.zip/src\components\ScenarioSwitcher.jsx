import React, { useState } from 'react';
import {
  Users,
  Target,
  Sparkles,
  ChevronDown,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Zap,
  RotateCcw,
  Sliders,
  Layers,
  Eye,
  SlidersHorizontal
} from 'lucide-react';
import { studentPersonas, availableGoals } from '../data/mockData';

export default function ScenarioSwitcher({
  currentPersonaKey = 'alex',
  onSwitchPersona,
  activeGoal,
  onSwitchGoal,
  onShowToast,
  is2DForced,
  onToggle2D,
  reducedMotion,
  onToggleReducedMotion,
}) {
  const [isOpen, setIsOpen] = useState(false);

  const personas = [
    {
      key: 'alex',
      name: 'Alex (Established)',
      role: 'Become a Data Scientist',
      badge: 'Canonical Demo',
      badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      description: 'Python 82%, Stats 61%, SQL 74%, ML 42%. Completed Python Fundamentals.',
    },
    {
      key: 'jordan',
      name: 'Jordan (Cold Start)',
      role: 'Become a Web Developer',
      badge: 'New Student (0 History)',
      badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
      description: '0 completed courses, 0 hours. Cold start recommendation test.',
    },
    {
      key: 'marcus',
      name: 'Marcus (Remedial)',
      role: 'Become a Data Scientist',
      badge: 'Failed Prereq (Stats 48%)',
      badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      description: 'Struggling in prerequisite statistics. Tests foundational recommendation rule.',
    },
    {
      key: 'sophia',
      name: 'Sophia (Advanced)',
      role: 'Learn Artificial Intelligence',
      badge: 'High Performer (96%+)',
      badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
      description: 'High quiz scores. Tests promotion of advanced frontier AI & multi-agent modules.',
    },
  ];

  return (
    <div className="relative z-30">
      {/* Bar Pill */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 px-4 py-2 rounded-2xl bg-slate-900/90 border border-indigo-500/30 backdrop-blur-xl shadow-lg text-xs">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-bold text-slate-300">Verification Scenario Tester:</span>
        </div>

        {/* Persona Selector Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {personas.map((p) => {
            const isSelected = currentPersonaKey === p.key;
            return (
              <button
                key={p.key}
                onClick={() => {
                  onSwitchPersona?.(p.key);
                  onShowToast?.({
                    type: 'ai',
                    title: `Switched Persona to ${p.name}`,
                    message: p.description,
                  });
                }}
                className={`px-3 py-1 rounded-xl font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                    : 'bg-slate-950/80 text-slate-400 hover:text-slate-200 border-slate-800'
                }`}
              >
                <span>{p.name.split(' ')[0]}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded ${isSelected ? 'bg-indigo-700 text-white' : 'bg-slate-800 text-slate-400'}`}>
                  {p.key === 'alex' ? 'Alex' : p.key}
                </span>
              </button>
            );
          })}
        </div>

        {/* Goal Quick Switcher */}
        <div className="flex items-center gap-2">
          <select
            value={activeGoal || 'Become a Data Scientist'}
            onChange={(e) => {
              onSwitchGoal?.(e.target.value);
              onShowToast?.({
                type: 'ai',
                title: 'Target Goal Updated',
                message: `Personalized learning path reconfigured for "${e.target.value}".`,
              });
            }}
            className="px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            {availableGoals.map((g) => (
              <option key={g} value={g}>
                Goal: {g}
              </option>
            ))}
          </select>

          {/* 2D / 3D Toggle */}
          <button
            onClick={onToggle2D}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold border transition-all ${
              is2DForced
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
            title="Toggle between 3D WebGL and 2D accessible fallback"
          >
            {is2DForced ? '2D Fallback Active' : '3D Mode'}
          </button>
        </div>
      </div>
    </div>
  );
}
