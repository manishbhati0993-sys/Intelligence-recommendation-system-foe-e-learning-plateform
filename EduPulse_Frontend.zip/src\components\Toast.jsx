import React, { useEffect } from 'react';
import { CheckCircle, AlertCircle, Info, X, Sparkles } from 'lucide-react';

export default function Toast({ toast, onClose }) {
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => {
      onClose();
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast, onClose]);

  if (!toast) return null;

  const icons = {
    success: <CheckCircle className="w-4 h-4 text-emerald-400" />,
    error: <AlertCircle className="w-4 h-4 text-rose-400" />,
    info: <Info className="w-4 h-4 text-indigo-400" />,
    ai: <Sparkles className="w-4 h-4 text-cyan-400" />,
  };

  const borders = {
    success: 'border-emerald-500/40 bg-slate-900/95 text-emerald-200',
    error: 'border-rose-500/40 bg-slate-900/95 text-rose-200',
    info: 'border-indigo-500/40 bg-slate-900/95 text-indigo-200',
    ai: 'border-cyan-500/40 bg-slate-900/95 text-cyan-200',
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-bounce-in max-w-sm">
      <div
        className={`flex items-center gap-3 px-4 py-3 rounded-2xl border shadow-2xl backdrop-blur-xl ${
          borders[toast.type] || borders.info
        }`}
      >
        <div className="flex-shrink-0">{icons[toast.type] || icons.info}</div>
        <div className="flex-1 text-xs">
          {toast.title && <p className="font-bold text-slate-100">{toast.title}</p>}
          <p className="text-slate-300 font-medium">{toast.message}</p>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
