import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Filter,
  Search,
  SlidersHorizontal,
  RotateCcw,
  Zap,
  ArrowUpDown,
  BookOpen,
  Target,
  CheckCircle2,
  Cpu,
  BrainCircuit,
} from 'lucide-react';
import CourseCard from '../components/CourseCard';
import { CourseSkeleton, RecommendationLoader } from '../components/CourseSkeleton';
import EmptyState from '../components/EmptyState';
import { fetchRecommendations } from '../services/recommendationEngine';
import { careerRolesData } from '../data/mockData';
import ThreeNeuralUniverse from '../components/ThreeNeuralUniverse';
import AiRecommendationInspector from '../components/AiRecommendationInspector';
import ExplainableAiModal from '../components/ExplainableAiModal';

export default function RecommendationsPage({
  user,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onShowToast,
}) {
  const [courses, setCourses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRecalculating, setIsRecalculating] = useState(false);
  const [viewMode, setViewMode] = useState('list'); // 'list' or '3d'
  const [inspectedNode, setInspectedNode] = useState(null);
  const [selectedCourseForWhyThis, setSelectedCourseForWhyThis] = useState(null);

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');
  const [selectedDuration, setSelectedDuration] = useState('All');
  const [minMatchScore, setMinMatchScore] = useState(70);
  const [sortBy, setSortBy] = useState('match');
  const [selectedTargetRole, setSelectedTargetRole] = useState(user?.targetRole || 'AI / Machine Learning Engineer');

  // Categories list
  const categories = [
    'All',
    'AI & Machine Learning',
    'MLOps & Cloud Infrastructure',
    'Full Stack Web Development',
    'Data Engineering & Big Data',
    'Cybersecurity & Secure AI',
    'UI/UX & AI-Assisted Design',
    'Mobile App Development',
  ];

  const levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];
  const durations = ['All', 'Short (< 25 hrs)', 'Medium (25 - 35 hrs)', 'Long (> 35 hrs)'];

  // Load recommendations
  const loadRecommendations = async (latency = 450) => {
    setIsLoading(true);
    try {
      const filters = {
        searchQuery,
        category: selectedCategory,
        level: selectedLevel,
        duration: selectedDuration,
        minScore: minMatchScore,
        sortBy,
      };
      const customPreferences = {
        ...user.preferences,
        targetCareer: selectedTargetRole,
      };
      const results = await fetchRecommendations(user.id, filters, customPreferences, latency);
      setCourses(results);
    } catch (err) {
      console.error('Failed to fetch recommendations:', err);
    } finally {
      setIsLoading(false);
      setIsRecalculating(false);
    }
  };

  useEffect(() => {
    loadRecommendations(350);
  }, [searchQuery, selectedCategory, selectedLevel, selectedDuration, minMatchScore, sortBy, selectedTargetRole]);

  // Handle explicit AI Recalculation
  const handleTriggerAiRecalculate = () => {
    setIsRecalculating(true);
    loadRecommendations(800);
    onShowToast?.({
      type: 'ai',
      title: 'Neural Vector Match Recalculated',
      message: `Reranked course recommendations based on ${selectedTargetRole} competency profile.`,
    });
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedLevel('All');
    setSelectedDuration('All');
    setMinMatchScore(70);
    setSortBy('match');
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header Banner */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Vector Similarity Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
              Personalized AI Course Recommendations
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Every course card below is scored via multidimensional vector cosine similarity against your target career (
              <span className="text-indigo-300 font-semibold">{selectedTargetRole}</span>) and identified skill deficits.
            </p>
          </div>

          {/* Recalculate Button */}
          <div className="flex flex-col sm:flex-row items-center gap-3 flex-shrink-0">
            <button
              onClick={handleTriggerAiRecalculate}
              disabled={isRecalculating}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center gap-2 hover:scale-105 active:scale-95 disabled:opacity-50"
            >
              <Cpu className={`w-4 h-4 text-amber-300 ${isRecalculating ? 'animate-spin' : ''}`} />
              <span>{isRecalculating ? 'Computing Vectors...' : 'Re-calculate AI Vectors'}</span>
            </button>
          </div>
        </div>

        {/* Target Career Quick Switcher Pill Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium mr-1 flex items-center gap-1">
            <Target className="w-3.5 h-3.5 text-indigo-400" />
            Active Target Role:
          </span>
          {careerRolesData.map((role) => (
            <button
              key={role.id}
              onClick={() => setSelectedTargetRole(role.name)}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                selectedTargetRole === role.name
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-950/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {role.name}
            </button>
          ))}
        </div>
      </div>

      {/* Filter & Control Bar */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-4 items-center">
          {/* Search Input */}
          <div className="lg:col-span-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter by keyword (e.g. PyTorch, MLOps, RAG)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Level Filter */}
          <div className="lg:col-span-2">
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
            >
              <option value="All">Level: All Levels</option>
              {levels.filter((l) => l !== 'All').map((l) => (
                <option key={l} value={l}>Level: {l}</option>
              ))}
            </select>
          </div>

          {/* Duration Filter */}
          <div className="lg:col-span-3">
            <select
              value={selectedDuration}
              onChange={(e) => setSelectedDuration(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
            >
              <option value="All">Duration: Any Length</option>
              {durations.filter((d) => d !== 'All').map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          {/* Sort By */}
          <div className="lg:col-span-3">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
            >
              <option value="match">Sort: AI Match (Highest First)</option>
              <option value="rating">Sort: Student Rating (Highest)</option>
              <option value="enrolled">Sort: Most Popular</option>
              <option value="duration_asc">Sort: Duration (Shortest)</option>
              <option value="duration_desc">Sort: Duration (Longest)</option>
            </select>
          </div>
        </div>

        {/* Category Horizontal Filter Chips */}
        <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full text-xs no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 font-bold'
                    : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Reset Filters button */}
          <button
            onClick={handleResetFilters}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 whitespace-nowrap px-2 py-1 rounded-lg hover:bg-slate-800"
            title="Reset Filters"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        </div>

        {/* Minimum Match Score Slider */}
        <div className="pt-2 border-t border-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <span className="text-slate-400 font-medium flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              Minimum AI Match Score:
            </span>
            <span className="font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              {minMatchScore}%+
            </span>
          </div>

          <div className="flex items-center gap-2 max-w-xs w-full">
            <span className="text-[10px] text-slate-500">60%</span>
            <input
              type="range"
              min="60"
              max="95"
              step="5"
              value={minMatchScore}
              onChange={(e) => setMinMatchScore(Number(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500">95%</span>
          </div>
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <p>
          Showing <strong className="text-slate-200 font-mono">{courses.length}</strong> AI-ranked courses for{' '}
          <span className="text-indigo-400 font-semibold">{selectedTargetRole}</span>
        </p>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setViewMode(prev => prev === 'list' ? '3d' : 'list')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {viewMode === 'list' ? 'Show 3D Graph' : 'Show List View'}
          </button>
          <span className="text-emerald-400 font-medium flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Vectors Calibrated
          </span>
        </div>
      </div>

      {viewMode === '3d' ? (
        <div className="w-full mt-4">
          <ThreeNeuralUniverse
            user={user}
            initialTargetRole={selectedTargetRole}
            onSelectCourse={onSelectCourse}
            onToggleBookmark={onToggleBookmark}
            onEnroll={onEnroll}
            onInspectNode={setInspectedNode}
          />
        </div>
      ) : (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading || isRecalculating ? (
          isRecalculating ? (
            <RecommendationLoader message={`Recalculating Neural Affinity for ${selectedTargetRole}...`} />
          ) : (
            <CourseSkeleton count={6} />
          )
        ) : courses.length > 0 ? (
          courses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              onSelectCourse={onSelectCourse}
              onToggleBookmark={onToggleBookmark}
              onEnroll={onEnroll}
              onWhyThis={(c) => setSelectedCourseForWhyThis(c)}
              isBookmarked={user.bookmarkedCourseIds?.includes(course.id)}
              isEnrolled={user.enrolledCourses?.some((enc) => enc.courseId === course.id)}
              enrolledProgress={
                user.enrolledCourses?.find((enc) => enc.courseId === course.id)?.progress || 0
              }
              showAiMatch={true}
            />
          ))
        ) : (
          <EmptyState
            title="No Matching Courses Found"
            description="No courses met your current filter combination and minimum match threshold. Try resetting filters or lowering the minimum score."
            onReset={handleResetFilters}
          />
        )}
      </div>
      )}

      {/* 3D Node Inspector */}
      <AiRecommendationInspector
        selectedNode={inspectedNode}
        user={user}
        onClose={() => setInspectedNode(null)}
        onSelectCourse={onSelectCourse}
        onToggleBookmark={onToggleBookmark}
        onEnroll={onEnroll}
      />

      {/* Explainable AI Modal */}
      <ExplainableAiModal
        course={selectedCourseForWhyThis}
        user={user}
        isOpen={Boolean(selectedCourseForWhyThis)}
        onClose={() => setSelectedCourseForWhyThis(null)}
        onEnroll={onEnroll}
        onToggleBookmark={onToggleBookmark}
        onFeedbackGiven={(cid, type) => {
          onShowToast?.({
            type: 'ai',
            title: 'Feedback Saved',
            message: `Recorded "${type}" preference. Neural recommendations updated.`,
          });
          loadRecommendations(200);
        }}
      />
    </div>
  );
}
