// Intelligent AI Recommendation Engine for EduPulse
// Hybrid Recommendation Approach: Content-based, Behavior-based, Performance-based, and Goal-based.
import {
  coursesData,
  initialUserProfile,
  careerRolesData,
  adaptiveLearningPathsData,
  multiModalRecommendationsData,
} from '../data/mockData';
import EduApi from './eduApi';

// Default Weights as specified in Prompt Section 5:
// Recommendation Score = 0.25 × Interest Match + 0.20 × Skill Match + 0.20 × Performance Relevance + 0.15 × Learning Goal Match + 0.10 × Difficulty Fit + 0.10 × Behavioral Relevance
export const DEFAULT_WEIGHTS = {
  interestMatch: 0.25,
  skillMatch: 0.20,
  performanceRelevance: 0.20,
  learningGoalMatch: 0.15,
  difficultyFit: 0.10,
  behavioralRelevance: 0.10,
};

const WEIGHTS_STORAGE_KEY = 'edupulse_recommendation_weights_v2';
const FEEDBACK_STORAGE_KEY = 'edupulse_recommendation_feedback_v2';

/**
 * Retrieve current recommendation weights from localStorage or fallback to defaults
 */
export function getRecommendationWeights() {
  if (typeof window === 'undefined') return { ...DEFAULT_WEIGHTS };
  try {
    const saved = localStorage.getItem(WEIGHTS_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Validate that weights exist
      if (parsed.interestMatch !== undefined) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Could not read weights from storage', err);
  }
  return { ...DEFAULT_WEIGHTS };
}

/**
 * Save new recommendation weights
 */
export function setRecommendationWeights(newWeights) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(WEIGHTS_STORAGE_KEY, JSON.stringify(newWeights));
  } catch (err) {
    console.warn('Could not save weights to storage', err);
  }
}

/**
 * Reset recommendation weights to factory defaults
 */
export function resetRecommendationWeights() {
  if (typeof window === 'undefined') return DEFAULT_WEIGHTS;
  try {
    localStorage.removeItem(WEIGHTS_STORAGE_KEY);
  } catch (err) {
    console.warn('Could not reset weights', err);
  }
  return { ...DEFAULT_WEIGHTS };
}

/**
 * Retrieve user feedback records from localStorage
 */
export function getFeedbackRecords() {
  if (typeof window === 'undefined') return {};
  try {
    const saved = localStorage.getItem(FEEDBACK_STORAGE_KEY);
    return saved ? JSON.parse(saved) : {};
  } catch {
    return {};
  }
}

/**
 * Record feedback on a course recommendation
 */
export function recordRecommendationFeedback(courseId, feedbackType) {
  if (typeof window === 'undefined') return;
  try {
    const current = getFeedbackRecords();
    current[courseId] = {
      type: feedbackType,
      timestamp: new Date().toISOString(),
    };
    localStorage.setItem(FEEDBACK_STORAGE_KEY, JSON.stringify(current));
  } catch (err) {
    console.warn('Could not record feedback', err);
  }
}

/**
 * Calculates the transparent 6-factor hybrid match score and explanations for a given course.
 */
export function calculateCourseAiMatch(course, user = initialUserProfile, customPreferences = null, overrideWeights = null) {
  const prefs = customPreferences || user.preferences || {};
  const targetGoal = prefs.targetCareer || user.targetRole || user.goal || 'Become a Data Scientist';
  const weights = overrideWeights || prefs.weights || getRecommendationWeights();
  const feedbackRecords = getFeedbackRecords();
  const courseFeedback = feedbackRecords[course.id]?.type;

  // Normalized Student Skills map (e.g. { 'Python': 82, 'Statistics': 61, ... })
  const userSkillsMap = {};
  if (user.skills) {
    Object.assign(userSkillsMap, user.skills);
  } else if (user.skillCompetencies) {
    user.skillCompetencies.forEach((sc) => {
      userSkillsMap[sc.skill] = sc.currentScore;
    });
  }

  // Active Role / Target Goal Benchmarks
  const activeRole = careerRolesData.find(
    (r) => r.name.toLowerCase() === targetGoal.toLowerCase() ||
           r.name.toLowerCase().includes(targetGoal.toLowerCase()) ||
           targetGoal.toLowerCase().includes(r.name.toLowerCase())
  ) || careerRolesData[0];

  // --------------------------------------------------------------------------
  // Factor 1: Content / Interest Match (0.25)
  // Evaluates interest tags, course description, topics, and syllabus keywords
  // --------------------------------------------------------------------------
  const interestTags = prefs.interestTags || user.preferences?.interestTags || [];
  const searchHistory = user.behaviorHistory?.searchHistory || [];
  const allInterestKeywords = [...interestTags, ...searchHistory].map((s) => s.toLowerCase());

  let interestHits = 0;
  course.tags.forEach((t) => {
    if (allInterestKeywords.some((kw) => kw.includes(t.toLowerCase()) || t.toLowerCase().includes(kw))) {
      interestHits += 2;
    }
  });
  if (allInterestKeywords.some((kw) => course.title.toLowerCase().includes(kw))) {
    interestHits += 3;
  }
  if (allInterestKeywords.some((kw) => course.category.toLowerCase().includes(kw))) {
    interestHits += 2;
  }

  const interestScore = Math.min(100, Math.max(50, Math.round((interestHits / Math.max(course.tags.length + 2, 4)) * 100)));

  // --------------------------------------------------------------------------
  // Factor 2: Skill Match (0.20)
  // Evaluates whether course addresses student skill deficits vs target benchmark
  // --------------------------------------------------------------------------
  let highestSkillGap = 0;
  let topDeficitSkill = '';
  let relatedSkillsCount = 0;

  course.skillsTaught.forEach((skillName) => {
    // Find matching user skill
    let userScore = 50; // default assumed if untracked
    Object.keys(userSkillsMap).forEach((usKey) => {
      if (skillName.toLowerCase().includes(usKey.toLowerCase()) || usKey.toLowerCase().includes(skillName.toLowerCase())) {
        userScore = userSkillsMap[usKey];
        relatedSkillsCount++;
      }
    });

    const targetBenchmark = 90;
    const gap = Math.max(0, targetBenchmark - userScore);
    if (gap > highestSkillGap) {
      highestSkillGap = gap;
      topDeficitSkill = skillName;
    }
  });

  // Gap closure: larger gap = higher need for this course
  const skillScore = Math.min(100, Math.max(55, Math.round(50 + (highestSkillGap / 50) * 45)));

  // --------------------------------------------------------------------------
  // Factor 3: Performance Relevance (0.20)
  // Checks quiz scores, failed attempts, and prerequisite readiness.
  // Rule: If poor performance in prerequisite (<70%), prioritize foundational material.
  // Rule: If high performance (>85%), promote advanced material.
  // --------------------------------------------------------------------------
  let performanceScore = 75;
  let performanceNote = '';
  const quizHistory = user.quizHistory || [];
  const averageQuiz = user.behaviorHistory?.averageQuizScore || 70;

  // Check if course is a foundational prerequisite
  const isFoundational = course.level === 'Beginner' || course.badge?.includes('Foundation') || course.id === 'c_stats' || course.id === 'c1';
  const isAdvanced = course.level === 'Advanced';

  // Check if student has low scores in any related prerequisite
  const hasLowPrereqScore = Object.entries(userSkillsMap).some(([sk, val]) => {
    return val < 70 && course.skillsTaught.some((cs) => cs.toLowerCase().includes(sk.toLowerCase()));
  });

  const hasHighQuizMastery = quizHistory.some((q) => q.score >= 90 && q.passed);

  if (hasLowPrereqScore && isFoundational) {
    // Student needs foundational remediation! Boost foundation course
    performanceScore = 98;
    performanceNote = 'Prioritized to reinforce foundational prerequisite topics where your diagnostic score is below 70%';
  } else if (hasHighQuizMastery && isAdvanced && !hasLowPrereqScore) {
    // Student scored high, promote advanced challenge
    performanceScore = 96;
    performanceNote = 'Promoted because your recent quiz score (>90%) shows readiness for advanced topics';
  } else if (isAdvanced && hasLowPrereqScore) {
    // Student hasn't mastered basics yet, slightly penalize advanced courses
    performanceScore = 65;
    performanceNote = 'Advanced course requiring prerequisite reinforcement in core skills first';
  } else {
    // Normal calibration
    performanceScore = Math.min(100, Math.max(65, Math.round(averageQuiz + 15)));
  }

  // --------------------------------------------------------------------------
  // Factor 4: Learning Goal Match (0.15)
  // Aligns with user's selected career milestone / goal path
  // --------------------------------------------------------------------------
  let goalScore = 70;
  const isDirectGoalMatch =
    (targetGoal.toLowerCase().includes('data scientist') && (course.category.includes('AI') || course.tags.includes('Data Science') || course.id === 'c_stats' || course.id === 'c1' || course.id === 'c3' || course.id === 'c13')) ||
    (targetGoal.toLowerCase().includes('web developer') && (course.category.includes('Web') || course.tags.includes('React') || course.id === 'c7' || course.id === 'c13')) ||
    (targetGoal.toLowerCase().includes('artificial intelligence') && (course.category.includes('AI') || course.tags.includes('PyTorch') || course.id === 'c2' || course.id === 'c5' || course.id === 'c15')) ||
    (targetGoal.toLowerCase().includes('cybersecurity') && (course.category.includes('Security') || course.id === 'c10')) ||
    (targetGoal.toLowerCase().includes('cloud') && (course.category.includes('Cloud') || course.id === 'c4' || course.id === 'c8'));

  if (isDirectGoalMatch) {
    goalScore = 98;
  } else {
    goalScore = 65;
  }

  // --------------------------------------------------------------------------
  // Factor 5: Difficulty Fit (0.10)
  // Evaluates difficulty fit against user's level and stated preference
  // --------------------------------------------------------------------------
  const preferredDiff = (prefs.preferredDifficulty || 'Intermediate').toLowerCase();
  let difficultyScore = 75;
  if (course.level.toLowerCase() === preferredDiff) {
    difficultyScore = 100;
  } else if (
    (preferredDiff.includes('intermediate') && (course.level === 'Beginner' || course.level === 'Intermediate')) ||
    (preferredDiff.includes('advanced') && course.level === 'Advanced')
  ) {
    difficultyScore = 90;
  } else {
    difficultyScore = 70;
  }

  // --------------------------------------------------------------------------
  // Factor 6: Behavioral Relevance (0.10)
  // Analyzes viewed courses, started courses, bookmarks, and video completions
  // --------------------------------------------------------------------------
  let behaviorScore = 75;
  const isBookmarked = user.bookmarkedCourseIds?.includes(course.id);
  const isEnrolled = user.enrolledCourses?.some((enc) => enc.courseId === course.id);
  const isCompleted = user.completedCourseIds?.includes(course.id);
  const isViewed = user.behaviorHistory?.coursesViewed?.includes(course.id);

  if (isBookmarked) behaviorScore += 18;
  if (isViewed) behaviorScore += 8;
  if (isEnrolled) behaviorScore += 10;
  if (isCompleted) behaviorScore -= 20; // Don't redundantly push completed courses

  behaviorScore = Math.min(100, Math.max(50, behaviorScore));

  // --------------------------------------------------------------------------
  // Feedback Adjustments:
  // Thumbs up/down, "Not interested", "Already know this", etc.
  // --------------------------------------------------------------------------
  let feedbackPenalty = 0;
  if (courseFeedback === 'useful') {
    behaviorScore = Math.min(100, behaviorScore + 15);
  } else if (courseFeedback === 'not_useful') {
    feedbackPenalty = 15;
  } else if (courseFeedback === 'not_interested' || courseFeedback === 'already_know') {
    feedbackPenalty = 40; // heavily downrank rejected items
  } else if (courseFeedback === 'too_difficult') {
    difficultyScore = Math.max(40, difficultyScore - 25);
  } else if (courseFeedback === 'too_easy') {
    difficultyScore = Math.max(40, difficultyScore - 20);
  }

  // --------------------------------------------------------------------------
  // Compute Weighted Recommendation Score
  // --------------------------------------------------------------------------
  const weightedTotal = (
    interestScore * weights.interestMatch +
    skillScore * weights.skillMatch +
    performanceScore * weights.performanceRelevance +
    goalScore * weights.learningGoalMatch +
    difficultyScore * weights.difficultyFit +
    behaviorScore * weights.behavioralRelevance
  ) - feedbackPenalty;

  // Scale score to a natural 60 - 99% range
  const matchPercentage = Math.min(99, Math.max(55, Math.round(weightedTotal)));

  // --------------------------------------------------------------------------
  // Explainable AI: Generate Transparent Reasons (Prompt Section 5 & 7)
  // --------------------------------------------------------------------------
  let dynamicReason = '';
  const explanationBulletPoints = [];

  // Goal match reason
  explanationBulletPoints.push(`✓ Matches your selected goal: ${targetGoal}`);

  // Skill & Performance reasons
  if (userSkillsMap['Python'] && course.skillsTaught.includes('Python')) {
    explanationBulletPoints.push(`✓ Builds on Python skills you already learned (${userSkillsMap['Python']}% proficiency)`);
  } else if (course.skillsTaught.length > 0) {
    explanationBulletPoints.push(`✓ Bridges essential capabilities in ${course.skillsTaught[0]}`);
  }

  if (hasLowPrereqScore && isFoundational) {
    explanationBulletPoints.push(`✓ Recommended because Statistics is one of your weaker prerequisite skills (${userSkillsMap['Statistics'] || 61}%)`);
  } else if (hasHighQuizMastery) {
    explanationBulletPoints.push(`✓ Your recent quiz results (91% in Python Quiz) show you are ready for this topic`);
  } else {
    explanationBulletPoints.push(`✓ Calibrated to your current study pace and diagnostic progress`);
  }

  explanationBulletPoints.push(`✓ Similar learners pursuing ${targetGoal} often study this topic next`);

  // Main single-line dynamic reason
  if (hasLowPrereqScore && isFoundational) {
    dynamicReason = `Recommended because you completed Python Basics, scored 91% in Python Quiz, and Statistics is a weaker prerequisite (${userSkillsMap['Statistics'] || 61}%) for ${targetGoal}.`;
  } else if (matchPercentage >= 95) {
    dynamicReason = `Recommended because you completed Python Fundamentals, scored 91% in Python Quiz, and selected ${targetGoal} as your goal.`;
  } else if (matchPercentage >= 90) {
    dynamicReason = `Recommended because it bridges your target skill gap in ${topDeficitSkill || course.category} for ${targetGoal}.`;
  } else {
    dynamicReason = `Recommended based on your ${course.category} interests and active weekly study behavior.`;
  }

  return {
    matchPercentage,
    dynamicReason,
    explanationBulletPoints,
    topGapSkill: topDeficitSkill,
    factors: {
      interestMatch: Math.round(interestScore),
      skillMatch: Math.round(skillScore),
      performanceRelevance: Math.round(performanceScore),
      learningGoalMatch: Math.round(goalScore),
      difficultyFit: Math.round(difficultyScore),
      behavioralRelevance: Math.round(behaviorScore),
    },
    performanceNote,
    weightsUsed: weights,
    userFeedback: courseFeedback,
  };
}

/**
 * Simulates async API call to the AI Recommendation Service with full filter, search & sort logic.
 */
export async function fetchRecommendations(
  userId = 'usr_alex_2026',
  filters = {},
  customPreferences = null,
  latencyMs = 350,
  userProfile = initialUserProfile
) {
  // 1. Attempt to fetch live recommendations from FastAPI backend if connected
  try {
    if (EduApi.accessToken) {
      const liveRes = await EduApi.getRecommendations(filters.limit || 8, false);
      const items = liveRes?.items || (Array.isArray(liveRes) ? liveRes : null);
      if (items && items.length > 0) {
        let liveMapped = items.map((item) => {
          const matchCourse = coursesData.find(
            (c) => c.id === item.course_id || c.title.toLowerCase() === item.title.toLowerCase()
          );
          return {
            ...(matchCourse || {}),
            id: item.course_id || item.id || `live_${Math.random()}`,
            title: item.title,
            description: item.description || matchCourse?.description || '',
            category: item.category || matchCourse?.category || 'AI & Machine Learning',
            level: item.level || matchCourse?.level || 'Intermediate',
            rating: matchCourse?.rating || 4.9,
            durationHours: matchCourse?.durationHours || 28,
            enrolledCount: matchCourse?.enrolledCount || 14000,
            skillsTaught: matchCourse?.skillsTaught || (item.skills ? item.skills.split(', ') : ['Data Science', 'Machine Learning']),
            tags: matchCourse?.tags || ['AI', 'Recommended'],
            thumbnail: matchCourse?.thumbnail || 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
            matchPercentage: item.match_pct || item.matchPercentage || 94,
            dynamicReason: item.reason || `🎯 ${item.match_pct || 94}% Match: Hybrid model alignment for ${userProfile?.targetRole || 'Data Science'}`,
            explanationBulletPoints: [
              `Recommender Algorithm: ${item.algo || 'hybrid'}`,
              item.reason || 'Calculated from user competency vector and curriculum taxonomy',
            ],
            algo: item.algo || 'hybrid',
            userFeedback: null,
          };
        });

        // Apply any active UI filters
        if (filters.category && filters.category !== 'All') {
          liveMapped = liveMapped.filter((c) => c.category === filters.category);
        }
        if (filters.level && filters.level !== 'All') {
          liveMapped = liveMapped.filter((c) => c.level === filters.level);
        }
        if (filters.searchQuery) {
          const q = filters.searchQuery.toLowerCase().trim();
          liveMapped = liveMapped.filter((c) => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
        }
        if (liveMapped.length > 0) {
          return liveMapped;
        }
      }
    }
  } catch (err) {
    // Graceful fallback to local simulated vector match
    console.info('[RecommendationEngine] Operating in local simulated mode:', err.message);
  }

  return new Promise((resolve) => {
    setTimeout(() => {
      // Local fallback calculation
      let scoredCourses = coursesData.map((course) => {
        const aiMetrics = calculateCourseAiMatch(course, userProfile, customPreferences);
        return {
          ...course,
          matchPercentage: aiMetrics.matchPercentage,
          dynamicReason: aiMetrics.dynamicReason,
          explanationBulletPoints: aiMetrics.explanationBulletPoints,
          factors: aiMetrics.factors,
          aiMetrics,
          userFeedback: aiMetrics.userFeedback,
        };
      });

      // Filter out rejected items unless explicitly searched
      if (!filters.searchQuery) {
        scoredCourses = scoredCourses.filter(
          (c) => c.userFeedback !== 'not_interested' && c.userFeedback !== 'already_know'
        );
      }

      // 2. Apply Search Query Filter
      if (filters.searchQuery && filters.searchQuery.trim() !== '') {
        const query = filters.searchQuery.toLowerCase().trim();
        scoredCourses = scoredCourses.filter((c) =>
          c.title.toLowerCase().includes(query) ||
          c.description.toLowerCase().includes(query) ||
          c.category.toLowerCase().includes(query) ||
          c.instructor.name.toLowerCase().includes(query) ||
          c.tags.some((t) => t.toLowerCase().includes(query)) ||
          c.skillsTaught.some((s) => s.toLowerCase().includes(query))
        );
      }

      // 3. Category Filter
      if (filters.category && filters.category !== 'All') {
        scoredCourses = scoredCourses.filter((c) => c.category === filters.category);
      }

      // 4. Difficulty Level Filter
      if (filters.level && filters.level !== 'All') {
        scoredCourses = scoredCourses.filter((c) => c.level === filters.level);
      }

      // 5. Duration Filter
      if (filters.duration && filters.duration !== 'All') {
        if (filters.duration === 'Short (< 25 hrs)') {
          scoredCourses = scoredCourses.filter((c) => c.durationHours < 25);
        } else if (filters.duration === 'Medium (25 - 35 hrs)') {
          scoredCourses = scoredCourses.filter((c) => c.durationHours >= 25 && c.durationHours <= 35);
        } else if (filters.duration === 'Long (> 35 hrs)') {
          scoredCourses = scoredCourses.filter((c) => c.durationHours > 35);
        }
      }

      // 6. Minimum AI Match Score Filter
      if (filters.minScore && filters.minScore > 0) {
        scoredCourses = scoredCourses.filter((c) => c.matchPercentage >= filters.minScore);
      }

      // 7. Sorting
      const sortBy = filters.sortBy || 'match';
      scoredCourses.sort((a, b) => {
        if (sortBy === 'match') {
          return b.matchPercentage - a.matchPercentage;
        } else if (sortBy === 'rating') {
          return b.rating - a.rating;
        } else if (sortBy === 'enrolled') {
          return b.enrolledCount - a.enrolledCount;
        } else if (sortBy === 'duration_asc') {
          return a.durationHours - b.durationHours;
        } else if (sortBy === 'duration_desc') {
          return b.durationHours - a.durationHours;
        }
        return 0;
      });

      resolve(scoredCourses);
    }, latencyMs);
  });
}

/**
 * Calculates skill gaps for a user against a target career path
 */
export function calculateSkillGapAnalysis(userSkills = initialUserProfile.skillCompetencies, roleName = 'Become a Data Scientist') {
  const role = careerRolesData.find((r) => r.name.toLowerCase() === roleName.toLowerCase()) || careerRolesData[0];

  let totalCurrent = 0;
  let totalTarget = 0;

  const gapBreakdown = (userSkills || []).map((userSkill) => {
    const roleTarget = role.targetCompetencies.find((t) => t.skill.toLowerCase().includes(userSkill.skill.toLowerCase()));
    const targetScore = roleTarget ? roleTarget.targetScore : userSkill.targetScore || 90;
    const importance = roleTarget ? roleTarget.importance : 'Medium';
    const gap = Math.max(0, targetScore - userSkill.currentScore);
    const masteryPercentage = Math.round((userSkill.currentScore / targetScore) * 100);

    totalCurrent += userSkill.currentScore;
    totalTarget += targetScore;

    return {
      skill: userSkill.skill,
      currentScore: userSkill.currentScore,
      targetScore,
      benchmarkCohortAvg: userSkill.benchmarkCohortAvg || 70,
      gap,
      masteryPercentage: Math.min(100, masteryPercentage),
      importance,
      status: gap === 0 ? 'Mastered' : gap <= 10 ? 'Near Target' : 'Action Required',
    };
  });

  const overallReadinessIndex = totalTarget > 0 ? Math.round((totalCurrent / totalTarget) * 100) : 75;
  const prioritizedGaps = [...gapBreakdown].sort((a, b) => b.gap - a.gap);

  return {
    role,
    overallReadinessIndex,
    prioritizedGaps,
    gapBreakdown,
  };
}

/**
 * Returns multi-modal recommendations: lessons, videos, quizzes, projects, practice exercises
 */
export function fetchMultiModalRecommendations(user = initialUserProfile) {
  return { ...multiModalRecommendationsData };
}

/**
 * Returns adaptive learning path steps
 */
export function fetchAdaptiveLearningPath(goal = 'Become a Data Scientist') {
  return adaptiveLearningPathsData;
}
