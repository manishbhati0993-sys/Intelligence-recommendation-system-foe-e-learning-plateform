import React, { useState } from 'react';
import {
  Building2,
  Users,
  Briefcase,
  Sparkles,
  Plus,
  TrendingUp,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronRight,
  Filter,
  ShieldCheck,
  Calendar,
  BarChart3,
  Search,
  MessageSquare,
  Award,
  ChevronDown,
  UserCheck,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { SKILL_BENCHMARKS } from '../data/portalData';

export default function IndustryDashboard({
  currentUser,
  portalData,
  setActiveTab,
  onOpenCreateJobModal
}) {
  const [pipelineStage, setPipelineStage] = useState('All');
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [interviewStatusToast, setInterviewStatusToast] = useState(null);

  const internships = portalData?.internships || [];
  const jobs = portalData?.jobs || [];
  const applications = portalData?.applications || [];

  // Extended talent pipeline candidates
  const pipelineCandidates = [
    {
      id: 'CAN-101',
      name: 'Aarav Sharma',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      college: 'NIT Karnataka (NITK)',
      degree: 'B.Tech CSE (8.74 CGPA)',
      targetRole: 'Cloud Backend & Microservices Intern',
      matchScore: 88,
      stage: 'Interview Scheduled',
      interviewTime: '04 Sept 2026, 03:00 PM IST',
      interviewMode: 'Google Meet (Technical Round 1)',
      topSkills: ['Java (85%)', 'SQL (80%)', 'REST APIs (60%)', 'Git (78%)'],
      notes: 'Strong core Java foundation. Fast-track for Cloud Architecture group.'
    },
    {
      id: 'CAN-102',
      name: 'Ananya Verma',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
      college: 'IIT Bombay',
      degree: 'B.Tech Data Science (9.12 CGPA)',
      targetRole: 'AI / ML Computer Vision Intern',
      matchScore: 94,
      stage: 'Offer Released',
      interviewTime: 'Completed (Score: 96/100)',
      interviewMode: 'Offer Accepted',
      topSkills: ['Python (92%)', 'PyTorch (88%)', 'Docker (80%)', 'MLOps (78%)'],
      notes: 'Rank 1 candidate. Offered ₹40,000/mo stipend + ₹14 LPA PPO.'
    },
    {
      id: 'CAN-103',
      name: 'Rohan Deshmukh',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      college: 'BITS Pilani',
      degree: 'B.E. Computer Science (8.45 CGPA)',
      targetRole: 'Full Stack Web & AI Systems Intern',
      matchScore: 82,
      stage: 'Shortlisted',
      interviewTime: 'Slot pending selection',
      interviewMode: 'Virtual Panel',
      topSkills: ['Node.js (84%)', 'TypeScript (80%)', 'PostgreSQL (82%)'],
      notes: 'GitHub portfolio verified with 4 production web apps.'
    },
    {
      id: 'CAN-104',
      name: 'Divya Iyer',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
      college: 'College of Engineering Guindy (Anna Univ)',
      degree: 'B.Tech IT (8.90 CGPA)',
      targetRole: 'Cloud Backend & Microservices Intern',
      matchScore: 86,
      stage: 'Under Review',
      interviewTime: 'Under initial screening',
      interviewMode: 'Automated Code Evaluation',
      topSkills: ['Java (82%)', 'Spring Boot (70%)', 'PostgreSQL (78%)'],
      notes: 'Excellent performance on proctored coding assessment.'
    }
  ];

  const filteredCandidates = pipelineStage === 'All'
    ? pipelineCandidates
    : pipelineCandidates.filter(c => c.stage === pipelineStage);

  const triggerInterviewUpdate = (candidateName, action) => {
    setInterviewStatusToast(`${action} for ${candidateName}`);
    setTimeout(() => setInterviewStatusToast(null), 3000);
  };

  return (
    <div className="space-y-8 py-4 max-w-7xl mx-auto">
      
      {/* Toast alert */}
      {interviewStatusToast && (
        <div className="fixed top-20 right-6 z-50 p-4 rounded-2xl bg-slate-900 border border-emerald-500 shadow-2xl text-xs font-bold text-white flex items-center gap-2 animate-in slide-in-from-top">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{interviewStatusToast}</span>
        </div>
      )}

      {/* 1. HEADER BANNER WITH VERIFIED BADGE */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          <div className="lg:col-span-8 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <img
              src={currentUser?.companyLogo || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=150&q=80'}
              alt={currentUser?.company}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-700 shadow-md"
            />
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-0.5 text-xs font-black rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Government Verified Corporate Partner
                </span>
                <span className="text-xs text-slate-400">• SIH Recruiter Accreditation #IND-9021</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white">{currentUser?.company}</h1>
              <p className="text-xs text-slate-300 font-medium">
                {currentUser?.name} — <span className="text-cyan-400">{currentUser?.title}</span> • {currentUser?.location}
              </p>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-wrap lg:justify-end items-center gap-3">
            <button
              onClick={onOpenCreateJobModal}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:opacity-95 text-white font-extrabold text-xs transition shadow-lg shadow-blue-500/25 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Post New Opening
            </button>
            <button
              onClick={() => setActiveTab('candidate_matching')}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition flex items-center gap-1.5 border border-slate-700"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> AI Candidate Pool
            </button>
          </div>

        </div>
      </div>

      {/* 2. RECRUITER METRICS KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Listings</div>
          <div className="text-2xl font-black text-white mt-2">{internships.length + jobs.length} Postings</div>
          <p className="text-[11px] text-cyan-400 mt-1">4 Internships, 2 Graduate FTEs</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Pre-Assessed Applicants</div>
          <div className="text-2xl font-black text-emerald-400 mt-2">142 Candidates</div>
          <p className="text-[11px] text-emerald-300 mt-1">Avg 86% Technical Match</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Talent Funnel</div>
          <div className="text-2xl font-black text-amber-400 mt-2">28 Shortlisted</div>
          <p className="text-[11px] text-amber-300 mt-1">12 Technical Rounds Scheduled</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Academic MoUs & CoEs</div>
          <div className="text-2xl font-black text-purple-400 mt-2">14 Institutions</div>
          <p className="text-[11px] text-purple-300 mt-1">NITK, IIT Bombay, BITS Pilani</p>
        </div>

      </div>

      {/* 3. TALENT PIPELINE DASHBOARD & SHORTLIST MANAGEMENT */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-blue-500/10 text-blue-400 text-xs font-bold border border-blue-500/20 mb-1">
              <Users className="w-3.5 h-3.5" />
              Talent Pipeline Dashboard
            </div>
            <h3 className="text-xl font-black text-white">
              Vetted Candidate Funnel & Interview Management
            </h3>
            <p className="text-xs text-slate-400">
              Ranked by AI skill match algorithm based on proctored code evaluations
            </p>
          </div>

          {/* Pipeline Stage Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {['All', 'Shortlisted', 'Interview Scheduled', 'Offer Released'].map((stg) => (
              <button
                key={stg}
                onClick={() => setPipelineStage(stg)}
                className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
                  pipelineStage === stg
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {stg}
              </button>
            ))}
          </div>
        </div>

        {/* Candidate Pipeline Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCandidates.map((cand) => (
            <div
              key={cand.id}
              className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-blue-500/40 transition space-y-4 shadow-lg"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={cand.avatar}
                    alt={cand.name}
                    className="w-12 h-12 rounded-xl object-cover border border-cyan-500/30"
                  />
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      {cand.name}
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    </h4>
                    <p className="text-xs text-slate-400">{cand.college} • <span className="text-slate-300 font-semibold">{cand.degree}</span></p>
                    <p className="text-[11px] text-cyan-300 mt-0.5">{cand.targetRole}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="px-2.5 py-1 text-xs font-black rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    {cand.matchScore}% Match
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1">{cand.stage}</div>
                </div>
              </div>

              {/* Verified skills badges */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {cand.topSkills.map((sk, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300">
                    {sk}
                  </span>
                ))}
              </div>

              {/* Interview / Schedule Status Details */}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-medium">Interview Schedule:</span>
                  <span className="text-white font-bold">{cand.interviewTime}</span>
                </div>
                <div className="text-[10px] text-slate-400 truncate">
                  Mode: <strong className="text-cyan-300">{cand.interviewMode}</strong>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                <button
                  onClick={() => triggerInterviewUpdate(cand.name, 'Technical feedback submitted')}
                  className="text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-cyan-400" /> Add Notes
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => triggerInterviewUpdate(cand.name, 'Interview rescheduled')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-semibold text-white transition"
                  >
                    Reschedule
                  </button>
                  <button
                    onClick={() => triggerInterviewUpdate(cand.name, 'Shortlist confirmed & Offer drafted')}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-[11px] font-bold text-white transition shadow-sm"
                  >
                    Advance Candidate →
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* 4. DUAL GRID: ACTIVE OPENINGS vs SKILL DEMAND ANALYTICS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left 7 Cols: Active Openings & Benchmark Requirements */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-cyan-400" /> Active Job & Internship Listings
            </h3>
            <button
              onClick={onOpenCreateJobModal}
              className="text-xs font-bold text-cyan-400 hover:underline"
            >
              + Create Listing
            </button>
          </div>

          <div className="space-y-3">
            {internships.map((item) => (
              <div
                key={item.id}
                className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-white">{item.title}</h4>
                    <p className="text-xs text-slate-400">{item.type} • {item.location} • <strong className="text-cyan-300">{item.stipend}</strong></p>
                  </div>
                  <span className="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Active • {item.vacancies} Vacancies
                  </span>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {item.requiredSkills.map((sk, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300">
                      {sk}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs text-slate-400">
                  <span>Deadline: <strong className="text-slate-300">{item.deadline}</strong></span>
                  <button
                    onClick={() => setActiveTab('candidate_matching')}
                    className="font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                  >
                    View Pre-Vetted Matches →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 5 Cols: Skill Demand Analytics (Supply vs Demand Bar Comparison) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-400" /> Skill Demand Analytics
            </h3>
            <span className="text-[11px] text-slate-400">AI National Benchmarks</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <p className="text-xs text-slate-300 leading-relaxed">
              Comparison between <strong>Industry Hiring Demand</strong> and <strong>Current Academic Student Supply</strong>. Large deficits identify immediate campus training opportunities.
            </p>

            <div className="space-y-3.5 pt-2">
              {SKILL_BENCHMARKS.slice(0, 5).map((bm, i) => (
                <div key={i} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">{bm.name}</span>
                    <span className="text-[11px] text-cyan-400 font-mono font-bold">{bm.growthRate}</span>
                  </div>

                  {/* Dual Bar (Demand vs Supply) */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>Industry Demand: {bm.avgIndustryDemand}%</span>
                      <span>Student Supply: {bm.studentAvg}%</span>
                    </div>
                    <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden flex gap-0.5">
                      <div className="bg-blue-500 h-full rounded-l-full" style={{ width: `${bm.avgIndustryDemand}%` }}></div>
                      <div className="bg-amber-400/80 h-full rounded-r-full" style={{ width: `${bm.studentAvg}%` }}></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                <span>Recruiter Demand</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span>Academic Supply</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
