import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  Sparkles,
  Maximize2,
  Minimize2,
  RotateCcw,
  SlidersHorizontal,
  Layers,
  Zap,
  Info,
  Compass,
  Eye,
  Filter,
  Flame,
  Award
} from 'lucide-react';
import { calculateCourseAiMatch } from '../services/recommendationEngine';
import { coursesData } from '../data/mockData';

// Color palette by Category
const CATEGORY_COLORS = {
  'AI & Machine Learning': 0x10b981, // Emerald
  'MLOps & Cloud Infrastructure': 0x8b5cf6, // Violet
  'Full Stack Web Development': 0x3b82f6, // Blue
  'Data Engineering & Big Data': 0x06b6d4, // Cyan
  'Cybersecurity & Secure AI': 0xf43f5e, // Rose
  'UI/UX & AI-Assisted Design': 0xec4899, // Pink
  'Mobile App Development': 0xf59e0b, // Amber
  'default': 0x6366f1, // Indigo
};

// Helper: Create high-resolution text sprite using HTML5 2D Canvas
function createTextSprite(text, { color = '#ffffff', fontSize = 28, bgColor = 'rgba(15, 23, 42, 0.75)', borderColor = 'rgba(99, 102, 241, 0.4)' } = {}) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  canvas.width = 512;
  canvas.height = 128;

  // Background pill
  ctx.fillStyle = bgColor;
  ctx.strokeStyle = borderColor;
  ctx.lineWidth = 4;
  const radius = 24;
  const x = 16, y = 16, w = 480, h = 96;

  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Text
  ctx.font = `bold ${fontSize}px Inter, system-ui, sans-serif`;
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Truncate if long
  let displayText = text;
  if (text.length > 28) {
    displayText = text.substring(0, 26) + '...';
  }
  ctx.fillText(displayText, 256, 64);

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false });
  const sprite = new THREE.Sprite(spriteMat);
  sprite.scale.set(6.4, 1.6, 1);
  return sprite;
}

export default function ThreeNeuralUniverse({
  user,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onInspectNode,
  initialTargetRole = null,
  compact = false,
}) {
  const containerRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [layoutMode, setLayoutMode] = useState('constellation'); // 'constellation', 'highway', 'affinity'
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [minScore, setMinScore] = useState(70);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [animatePulses, setAnimatePulses] = useState(true);
  const [showControls, setShowControls] = useState(true);

  // References for Three.js objects
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const controlsRef = useRef(null);
  const rendererRef = useRef(null);
  const nodesGroupRef = useRef(null);
  const linksGroupRef = useRef(null);
  const pulsesGroupRef = useRef(null);
  const particlesRef = useRef(null);
  const coreMeshRef = useRef(null);
  const targetBeaconRef = useRef(null);
  const animationFrameId = useRef(null);
  const targetCamPos = useRef(null);
  const targetLookAt = useRef(null);

  // Active target role
  const activeRole = initialTargetRole || user?.targetRole || 'AI / Machine Learning Engineer';

  // Compute recommendation scores for all courses
  const scoredCourses = useMemo(() => {
    return coursesData.map((course) => {
      const match = calculateCourseAiMatch(course, user, { targetCareer: activeRole });
      return {
        ...course,
        aiMatch: match,
        matchScore: match.matchPercentage,
      };
    });
  }, [user, activeRole]);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set(coursesData.map((c) => c.category));
    return ['All', ...Array.from(set)];
  }, []);

  // Fullscreen toggle handler
  const handleToggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => console.error(err));
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch((err) => console.error(err));
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Main Three.js Scene Setup & Initialization
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x060913, 0.012);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1500);
    camera.position.set(0, 18, 52);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x060913, 1);
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 180;
    controls.minDistance = 12;
    controls.target.set(0, 0, 0);
    controlsRef.current = controls;

    // 5. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const cyanPoint = new THREE.PointLight(0x06b6d4, 4, 120);
    cyanPoint.position.set(0, 0, 0);
    scene.add(cyanPoint);

    const emeraldPoint = new THREE.PointLight(0x10b981, 3, 150);
    emeraldPoint.position.set(30, 20, 20);
    scene.add(emeraldPoint);

    const violetPoint = new THREE.PointLight(0x8b5cf6, 3, 150);
    violetPoint.position.set(-30, -15, -20);
    scene.add(violetPoint);

    // 6. Cosmic Starfield / Neural Dust
    const particleCount = 1400;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const radius = 60 + Math.random() * 120;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      particlePositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = radius * Math.cos(phi);

      const colorVariant = Math.random();
      if (colorVariant < 0.4) {
        // Cyan / Blue
        particleColors[i * 3] = 0.1;
        particleColors[i * 3 + 1] = 0.6;
        particleColors[i * 3 + 2] = 0.9;
      } else if (colorVariant < 0.7) {
        // Emerald
        particleColors[i * 3] = 0.1;
        particleColors[i * 3 + 1] = 0.8;
        particleColors[i * 3 + 2] = 0.5;
      } else {
        // Violet
        particleColors[i * 3] = 0.6;
        particleColors[i * 3 + 1] = 0.3;
        particleColors[i * 3 + 2] = 0.9;
      }
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 1.1,
      vertexColors: true,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);
    particlesRef.current = particles;

    // 7. Node and Link Containers
    const nodesGroup = new THREE.Group();
    scene.add(nodesGroup);
    nodesGroupRef.current = nodesGroup;

    const linksGroup = new THREE.Group();
    scene.add(linksGroup);
    linksGroupRef.current = linksGroup;

    const pulsesGroup = new THREE.Group();
    scene.add(pulsesGroup);
    pulsesGroupRef.current = pulsesGroup;

    // 8. Central Learner Core Mesh
    const coreGroup = new THREE.Group();
    
    // Inner glowing sphere
    const innerGeo = new THREE.SphereGeometry(2.4, 32, 32);
    const innerMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x0284c7,
      emissiveIntensity: 1.4,
      roughness: 0.1,
      metalness: 0.2,
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    coreGroup.add(innerMesh);

    // Wireframe icosahedron shell
    const outerGeo = new THREE.IcosahedronGeometry(3.6, 2);
    const outerMat = new THREE.MeshPhongMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const outerMesh = new THREE.Mesh(outerGeo, outerMat);
    coreGroup.add(outerMesh);

    // Orbital Rings
    const ringGeo = new THREE.TorusGeometry(4.6, 0.08, 16, 100);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.45 });
    const ring1 = new THREE.Mesh(ringGeo, ringMat);
    ring1.rotation.x = Math.PI / 3;
    coreGroup.add(ring1);

    const ring2 = new THREE.Mesh(ringGeo, ringMat);
    ring2.rotation.y = Math.PI / 3;
    coreGroup.add(ring2);

    // Learner Core Sprite Label
    const coreLabel = createTextSprite(`Learner: ${user?.name || 'Alex Morgan'}`, {
      color: '#38bdf8',
      fontSize: 26,
      bgColor: 'rgba(6, 182, 212, 0.25)',
      borderColor: 'rgba(56, 189, 248, 0.6)',
    });
    coreLabel.position.set(0, -4.8, 0);
    coreGroup.add(coreLabel);

    coreGroup.userData = {
      type: 'user',
      label: user?.name || 'Alex Morgan',
      user,
    };
    scene.add(coreGroup);
    coreMeshRef.current = coreGroup;

    // 9. Resize Listener
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // 10. Animation Loop
    let clock = new THREE.Clock();
    const animate = () => {
      animationFrameId.current = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Controls update
      controls.update();

      // Slowly rotate starfield
      if (particlesRef.current) {
        particlesRef.current.rotation.y = time * 0.012;
      }

      // Rotate learner core & rings
      if (coreMeshRef.current) {
        outerMesh.rotation.y = time * 0.25;
        outerMesh.rotation.x = time * 0.15;
        ring1.rotation.z = time * 0.35;
        ring2.rotation.x = time * 0.25;
      }

      // Rotate target beacon crystal
      if (targetBeaconRef.current) {
        targetBeaconRef.current.rotation.y = time * 0.5;
        targetBeaconRef.current.rotation.x = time * 0.3;
      }

      // Camera lerp transition if focused
      if (targetCamPos.current && targetLookAt.current) {
        camera.position.lerp(targetCamPos.current, 0.05);
        controls.target.lerp(targetLookAt.current, 0.05);
        if (camera.position.distanceTo(targetCamPos.current) < 0.2) {
          targetCamPos.current = null;
          targetLookAt.current = null;
        }
      }

      // Animate photon pulses along synapses
      if (pulsesGroupRef.current && animatePulses) {
        pulsesGroupRef.current.children.forEach((pulse) => {
          if (pulse.userData.curve) {
            pulse.userData.progress = (pulse.userData.progress + delta * pulse.userData.speed) % 1;
            const pt = pulse.userData.curve.getPoint(pulse.userData.progress);
            pulse.position.copy(pt);
          }
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      controls.dispose();
    };
  }, []);

  // Update Nodes and Links when ScoredCourses, LayoutMode, or Filters Change
  useEffect(() => {
    if (!sceneRef.current || !nodesGroupRef.current || !linksGroupRef.current || !pulsesGroupRef.current) return;

    const nodesGroup = nodesGroupRef.current;
    const linksGroup = linksGroupRef.current;
    const pulsesGroup = pulsesGroupRef.current;

    // Clear previous dynamic meshes
    while (nodesGroup.children.length > 0) {
      nodesGroup.remove(nodesGroup.children[0]);
    }
    while (linksGroup.children.length > 0) {
      linksGroup.remove(linksGroup.children[0]);
    }
    while (pulsesGroup.children.length > 0) {
      pulsesGroup.remove(pulsesGroup.children[0]);
    }

    // Filter courses based on active filters
    const filteredCourses = scoredCourses.filter((course) => {
      const matchCat = selectedCategory === 'All' || course.category === selectedCategory;
      const matchMinScore = course.matchScore >= minScore;
      return matchCat && matchMinScore;
    });

    // 1. POSITIONING ALGORITHMS
    const nodeDataList = [];

    // TARGET ROLE BEACON
    let beaconPos = new THREE.Vector3(42, 14, 8);
    if (layoutMode === 'highway') {
      beaconPos = new THREE.Vector3(46, 0, 0);
    } else if (layoutMode === 'affinity') {
      beaconPos = new THREE.Vector3(0, 36, 0);
    }

    // Create Target Beacon Mesh
    const beaconGroup = new THREE.Group();
    const beaconGeo = new THREE.OctahedronGeometry(2.8, 1);
    const beaconMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0x7c3aed,
      emissiveIntensity: 1.5,
      metalness: 0.8,
      roughness: 0.2,
      wireframe: false,
    });
    const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
    beaconGroup.add(beaconMesh);

    const beaconWireGeo = new THREE.OctahedronGeometry(3.6, 1);
    const beaconWireMat = new THREE.MeshBasicMaterial({
      color: 0xc084fc,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const beaconWire = new THREE.Mesh(beaconWireGeo, beaconWireMat);
    beaconGroup.add(beaconWire);

    beaconGroup.position.copy(beaconPos);
    const beaconLabel = createTextSprite(`Goal: ${activeRole}`, {
      color: '#c084fc',
      fontSize: 24,
      bgColor: 'rgba(126, 34, 206, 0.3)',
      borderColor: 'rgba(192, 132, 252, 0.6)',
    });
    beaconLabel.position.set(0, -4.5, 0);
    beaconGroup.add(beaconLabel);

    beaconGroup.userData = {
      type: 'role',
      label: activeRole,
    };
    nodesGroup.add(beaconGroup);
    targetBeaconRef.current = beaconGroup;

    // 2. SKILL GAP NODES
    const skillNodes = user?.skillCompetencies || [
      { skill: 'Deep Learning & PyTorch', currentScore: 68, targetScore: 92 },
      { skill: 'MLOps & Cloud Deploy', currentScore: 52, targetScore: 88 },
      { skill: 'LLMs & GenAI Systems', currentScore: 58, targetScore: 90 },
      { skill: 'Data Pipelines & SQL', currentScore: 78, targetScore: 85 },
    ];

    const skillPositions = [];
    skillNodes.forEach((sk, idx) => {
      const gap = sk.targetScore - sk.currentScore;
      let pos = new THREE.Vector3();

      if (layoutMode === 'highway') {
        const yOffset = (idx - (skillNodes.length - 1) / 2) * 9;
        pos.set(-18, yOffset, (idx % 2 === 0 ? 4 : -4));
      } else if (layoutMode === 'affinity') {
        const angle = (idx / skillNodes.length) * Math.PI * 2;
        pos.set(Math.cos(angle) * 16, Math.sin(angle) * 16, 0);
      } else {
        // Constellation: intermediate shell around learner core
        const angle = (idx / skillNodes.length) * Math.PI * 2;
        const radius = 15;
        pos.set(Math.cos(angle) * radius, (Math.sin(angle * 2) * 6), Math.sin(angle) * radius);
      }

      skillPositions.push({ ...sk, pos, id: `skill_${idx}`, gap });

      // Create 3D Mesh for Skill Gap
      const skillColor = gap > 25 ? 0xf43f5e : gap > 15 ? 0xf59e0b : 0x10b981;
      const skillGeo = new THREE.DodecahedronGeometry(1.4, 0);
      const skillMat = new THREE.MeshStandardMaterial({
        color: skillColor,
        emissive: skillColor,
        emissiveIntensity: 0.8,
        roughness: 0.3,
        metalness: 0.4,
      });
      const skillMesh = new THREE.Mesh(skillGeo, skillMat);
      skillMesh.position.copy(pos);

      const skillLabel = createTextSprite(`${sk.skill} (${gap}% gap)`, {
        color: gap > 20 ? '#fda4af' : '#fde68a',
        fontSize: 22,
        bgColor: 'rgba(15, 23, 42, 0.8)',
        borderColor: gap > 20 ? 'rgba(244, 63, 94, 0.5)' : 'rgba(245, 158, 11, 0.5)',
      });
      skillLabel.position.set(0, -2.6, 0);
      skillMesh.add(skillLabel);

      skillMesh.userData = {
        type: 'skill',
        label: sk.skill,
        currentScore: sk.currentScore,
        targetScore: sk.targetScore,
        gap,
      };
      nodesGroup.add(skillMesh);

      // Link Core to Skill Gap
      const curve = new THREE.QuadraticBezierCurve3(
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(pos.x * 0.5, pos.y * 0.5 + 2, pos.z * 0.5),
        pos
      );
      const points = curve.getPoints(24);
      const linkGeo = new THREE.BufferGeometry().setFromPoints(points);
      const linkMat = new THREE.LineBasicMaterial({
        color: skillColor,
        transparent: true,
        opacity: 0.35,
      });
      const linkLine = new THREE.Line(linkGeo, linkMat);
      linksGroup.add(linkLine);

      // Energy Pulse
      const pulseGeo = new THREE.SphereGeometry(0.35, 12, 12);
      const pulseMat = new THREE.MeshBasicMaterial({ color: skillColor });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      pulseMesh.userData = { curve, progress: Math.random(), speed: 0.25 };
      pulsesGroup.add(pulseMesh);
    });

    // 3. COURSE NODES
    filteredCourses.forEach((course, index) => {
      let pos = new THREE.Vector3();
      const score = course.matchScore;
      const isTopMatch = score >= 90;

      if (layoutMode === 'highway') {
        // Milestone progression:
        // Score >= 92 -> Advanced Milestone 2 (pos.x ~ 26)
        // Score >= 85 -> Foundation / Milestone 1 (pos.x ~ 4)
        // Score < 85 -> Complementary (pos.x ~ 14)
        const stageX = score >= 92 ? 26 : score >= 85 ? 4 : 14;
        const row = (index % 5) - 2;
        pos.set(stageX + (Math.sin(index) * 2), row * 6.5, (index % 2 === 0 ? 6 : -6));
      } else if (layoutMode === 'affinity') {
        // Closer distance for higher match score!
        const radius = 18 + (100 - score) * 0.6; // 98% -> r=19.2, 70% -> r=36
        const phi = Math.acos(-1 + (2 * index) / filteredCourses.length);
        const theta = Math.sqrt(filteredCourses.length * Math.PI) * phi;
        pos.set(
          radius * Math.cos(theta) * Math.sin(phi),
          radius * Math.sin(theta) * Math.sin(phi),
          radius * Math.cos(phi)
        );
      } else {
        // Constellation: Spherical spiral with clustering
        const radius = 24 + ((100 - score) * 0.35);
        const phi = Math.acos(-1 + (2 * index) / Math.max(1, filteredCourses.length));
        const theta = Math.sqrt(filteredCourses.length * Math.PI) * phi + (index * 0.4);
        pos.set(
          radius * Math.cos(theta) * Math.sin(phi),
          radius * Math.sin(theta) * Math.sin(phi) + Math.sin(index) * 4,
          radius * Math.cos(phi)
        );
      }

      const isCompleted = user?.completedCourseIds?.includes(course.id);
      const isAdvancedLocked = course.level === 'Advanced' && !isTopMatch && !isCompleted;

      // Adjust distance: Top recommended courses appear closer and brighter!
      if (isTopMatch) {
        pos.multiplyScalar(0.75); // 25% closer to center
      } else if (isAdvancedLocked) {
        pos.multiplyScalar(1.28); // 28% farther away
      }

      // Base radius and color
      const nodeColor = isCompleted
        ? 0x10b981 // Emerald for completed
        : CATEGORY_COLORS[course.category] || CATEGORY_COLORS['default'];
      const nodeRadius = 1.0 + (score / 100) * 0.9; // larger for higher match

      const nodeGeo = new THREE.SphereGeometry(nodeRadius, 24, 24);
      const nodeMat = new THREE.MeshStandardMaterial({
        color: nodeColor,
        emissive: nodeColor,
        emissiveIntensity: isCompleted ? 1.0 : isTopMatch ? 0.95 : isAdvancedLocked ? 0.35 : 0.55,
        roughness: 0.25,
        metalness: isCompleted ? 0.6 : 0.3,
        transparent: isAdvancedLocked,
        opacity: isAdvancedLocked ? 0.65 : 1.0,
      });
      const courseMesh = new THREE.Mesh(nodeGeo, nodeMat);
      courseMesh.position.copy(pos);

      // Glowing orbital halo ring for top matches & completed courses
      if (isCompleted) {
        // Distinct completed halo ring (gold/emerald)
        const ringGeo = new THREE.RingGeometry(nodeRadius * 1.35, nodeRadius * 1.6, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xfbbf24,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.8,
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2;
        courseMesh.add(ringMesh);
      } else if (isTopMatch) {
        const ringGeo = new THREE.RingGeometry(nodeRadius * 1.35, nodeRadius * 1.55, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0x34d399,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.6,
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2;
        courseMesh.add(ringMesh);
      }

      // Floating Canvas Label
      const labelText = isCompleted
        ? `✓ Completed | ${course.title}`
        : isAdvancedLocked
        ? `🔒 Adv | ${course.title}`
        : `${score}% | ${course.title}`;

      const spriteLabel = createTextSprite(labelText, {
        color: isCompleted ? '#fef08a' : isTopMatch ? '#6ee7b7' : isAdvancedLocked ? '#94a3b8' : '#e2e8f0',
        fontSize: 22,
        bgColor: isCompleted
          ? 'rgba(120, 53, 15, 0.8)'
          : isTopMatch
          ? 'rgba(6, 78, 59, 0.75)'
          : 'rgba(15, 23, 42, 0.75)',
        borderColor: isCompleted
          ? 'rgba(251, 191, 36, 0.8)'
          : isTopMatch
          ? 'rgba(52, 211, 153, 0.6)'
          : 'rgba(100, 116, 139, 0.4)',
      });
      spriteLabel.position.set(0, -nodeRadius - 1.8, 0);
      courseMesh.add(spriteLabel);

      courseMesh.userData = {
        type: 'course',
        course,
        matchScore: score,
        aiMatch: course.aiMatch,
        label: course.title,
        isCompleted,
        isAdvancedLocked,
      };
      nodesGroup.add(courseMesh);

      // 4. SYNAPSE CONNECTIONS
      // Connect course to relevant skill gap or learner core
      const matchingSkill = skillPositions.find((sk) =>
        course.skillsTaught?.includes(sk.skill)
      );

      const sourcePos = matchingSkill ? matchingSkill.pos : new THREE.Vector3(0, 0, 0);
      const midPoint = new THREE.Vector3(
        (sourcePos.x + pos.x) * 0.5,
        (sourcePos.y + pos.y) * 0.5 + 3,
        (sourcePos.z + pos.z) * 0.5
      );

      const curve = new THREE.QuadraticBezierCurve3(sourcePos, midPoint, pos);
      const points = curve.getPoints(24);
      const linkGeo = new THREE.BufferGeometry().setFromPoints(points);
      const linkMat = new THREE.LineBasicMaterial({
        color: nodeColor,
        transparent: true,
        opacity: isTopMatch ? 0.45 : 0.2,
        linewidth: isTopMatch ? 2 : 1,
      });
      const linkLine = new THREE.Line(linkGeo, linkMat);
      linksGroup.add(linkLine);

      // If high match, also connect course to Target Role Beacon!
      if (isTopMatch) {
        const beaconCurve = new THREE.QuadraticBezierCurve3(
          pos,
          new THREE.Vector3((pos.x + beaconPos.x) * 0.5, (pos.y + beaconPos.y) * 0.5 + 2, (pos.z + beaconPos.z) * 0.5),
          beaconPos
        );
        const beaconPoints = beaconCurve.getPoints(24);
        const beaconLinkGeo = new THREE.BufferGeometry().setFromPoints(beaconPoints);
        const beaconLinkMat = new THREE.LineBasicMaterial({
          color: 0xa855f7,
          transparent: true,
          opacity: 0.35,
        });
        linksGroup.add(new THREE.Line(beaconLinkGeo, beaconLinkMat));

        // Pulsing photon to beacon
        const pulseGeo = new THREE.SphereGeometry(0.3, 10, 10);
        const pulseMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
        const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
        pulseMesh.userData = { curve: beaconCurve, progress: Math.random(), speed: 0.3 };
        pulsesGroup.add(pulseMesh);
      }

      // Standard Synapse Pulse
      const pulseGeo = new THREE.SphereGeometry(0.28, 10, 10);
      const pulseMat = new THREE.MeshBasicMaterial({ color: nodeColor });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      pulseMesh.userData = { curve, progress: Math.random(), speed: 0.2 + (score / 100) * 0.2 };
      pulsesGroup.add(pulseMesh);
    });

  }, [scoredCourses, layoutMode, selectedCategory, minScore, activeRole, user]);

  // Handle Raycasting for Hover & Click Events
  const handlePointerMove = useCallback((e) => {
    const container = containerRef.current;
    if (!container || !cameraRef.current || !sceneRef.current) return;

    const rect = container.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );

    setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    const interactiveMeshes = [];
    if (nodesGroupRef.current) {
      nodesGroupRef.current.children.forEach((group) => {
        if (group.isMesh) interactiveMeshes.push(group);
        group.children?.forEach((child) => {
          if (child.isMesh && group.userData?.type) interactiveMeshes.push(child);
        });
      });
    }
    if (coreMeshRef.current) {
      coreMeshRef.current.children.forEach((c) => {
        if (c.isMesh) interactiveMeshes.push(c);
      });
    }

    const intersects = raycaster.intersectObjects(interactiveMeshes, false);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      const data = hit.userData?.type ? hit.userData : hit.parent?.userData;
      if (data && data.type) {
        setHoveredNode(data);
        container.style.cursor = 'pointer';
        return;
      }
    }

    setHoveredNode(null);
    container.style.cursor = 'grab';
  }, []);

  const handleClick = useCallback((e) => {
    const container = containerRef.current;
    if (!container || !cameraRef.current || !sceneRef.current) return;

    const rect = container.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    const interactiveMeshes = [];
    if (nodesGroupRef.current) {
      nodesGroupRef.current.children.forEach((group) => {
        if (group.isMesh) interactiveMeshes.push(group);
        group.children?.forEach((child) => {
          if (child.isMesh && group.userData?.type) interactiveMeshes.push(child);
        });
      });
    }
    if (coreMeshRef.current) {
      coreMeshRef.current.children.forEach((c) => {
        if (c.isMesh) interactiveMeshes.push(c);
      });
    }

    const intersects = raycaster.intersectObjects(interactiveMeshes, false);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      const data = hit.userData?.type ? hit.userData : hit.parent?.userData;
      if (data) {
        // Trigger Inspector
        onInspectNode?.(data);

        // Smooth camera lerp toward node
        const worldPos = new THREE.Vector3();
        (hit.parent?.userData?.type ? hit.parent : hit).getWorldPosition(worldPos);

        const offset = new THREE.Vector3(12, 8, 16);
        targetCamPos.current = worldPos.clone().add(offset);
        targetLookAt.current = worldPos.clone();
      }
    }
  }, [onInspectNode]);

  // Recenter Camera Handler
  const handleRecenter = () => {
    if (controlsRef.current && cameraRef.current) {
      targetCamPos.current = new THREE.Vector3(0, 18, 52);
      targetLookAt.current = new THREE.Vector3(0, 0, 0);
    }
  };

  return (
    <div
      className={`relative w-full overflow-hidden rounded-3xl border border-indigo-500/20 bg-slate-950 shadow-2xl transition-all duration-300 ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none border-none h-screen' : compact ? 'h-[500px]' : 'h-[640px]'
      }`}
    >
      {/* Three.js Canvas Container */}
      <div
        ref={containerRef}
        onMouseMove={handlePointerMove}
        onClick={handleClick}
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* 3D HUD Tooltip on Hover */}
      {hoveredNode && (
        <div
          style={{
            left: `${mousePos.x + 16}px`,
            top: `${mousePos.y + 16}px`,
          }}
          className="pointer-events-none absolute z-40 max-w-xs transform -translate-y-1/2 p-3.5 rounded-2xl bg-slate-900/95 backdrop-blur-xl border border-indigo-500/30 text-white shadow-2xl transition-all duration-75 animate-fade-in"
        >
          <div className="flex items-center gap-2 mb-1">
            <span
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                hoveredNode.type === 'course'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : hoveredNode.type === 'skill'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : hoveredNode.type === 'role'
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
              }`}
            >
              {hoveredNode.type}
            </span>

            {hoveredNode.matchScore && (
              <span className="text-[11px] font-mono font-bold text-emerald-400">
                {hoveredNode.matchScore}% Match
              </span>
            )}
          </div>

          <h4 className="text-xs font-bold text-slate-100 leading-snug">
            {hoveredNode.label || hoveredNode.course?.title}
          </h4>

          {hoveredNode.course && (
            <p className="mt-1 text-[11px] text-slate-400 line-clamp-2">
              {hoveredNode.course.category} • {hoveredNode.course.level}
            </p>
          )}

          {hoveredNode.gap !== undefined && (
            <p className="mt-1 text-[11px] text-amber-300">
              Skill Deficit Gap: <strong>{hoveredNode.gap}%</strong>
            </p>
          )}

          <div className="mt-2 pt-2 border-t border-slate-800 text-[10px] text-indigo-300 flex items-center gap-1">
            <Zap className="w-3 h-3" />
            <span>Click to inspect explainable AI vector</span>
          </div>
        </div>
      )}

      {/* Top Floating Controls Bar */}
      <div className="absolute top-4 left-4 right-4 z-30 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        {/* Left: Universe Title & Live Telemetry Badge */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="px-3.5 py-1.5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-indigo-500/30 shadow-lg flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-bold text-white tracking-wide">
              Neural 3D Intelligence Graph
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
              Vector Space
            </span>
          </div>
        </div>

        {/* Right: Layout Switcher & Action Icons */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Layout Mode Selector */}
          <div className="p-1 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-800 shadow-lg flex items-center text-xs">
            <button
              onClick={() => setLayoutMode('constellation')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                layoutMode === 'constellation'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Constellation
            </button>
            <button
              onClick={() => setLayoutMode('highway')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                layoutMode === 'highway'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Career Highway
            </button>
            <button
              onClick={() => setLayoutMode('affinity')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                layoutMode === 'affinity'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              High-Affinity
            </button>
          </div>

          {/* Toggle Synapse Pulses */}
          <button
            onClick={() => setAnimatePulses(!animatePulses)}
            className={`p-2.5 rounded-2xl bg-slate-900/90 backdrop-blur-md border shadow-lg transition-colors ${
              animatePulses
                ? 'border-emerald-500/40 text-emerald-400'
                : 'border-slate-800 text-slate-500 hover:text-slate-300'
            }`}
            title={animatePulses ? 'Pause Neural Pulses' : 'Resume Neural Pulses'}
          >
            <Zap className="w-4 h-4" />
          </button>

          {/* Recenter Camera */}
          <button
            onClick={handleRecenter}
            className="p-2.5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-800 text-slate-300 hover:text-white shadow-lg transition-colors"
            title="Recenter 3D View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={handleToggleFullscreen}
            className="p-2.5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-800 text-slate-300 hover:text-white shadow-lg transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Bottom Floating Shelf: Filters & Interactive Legend */}
      <div className="absolute bottom-4 left-4 right-4 z-30 pointer-events-none flex flex-col sm:flex-row items-end sm:items-center justify-between gap-3">
        {/* Category Pills & Score Slider */}
        <div className="pointer-events-auto p-2.5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-800 shadow-xl flex flex-wrap items-center gap-2 max-w-full overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-1.5 mr-2 text-xs text-slate-400 font-medium">
            <Filter className="w-3.5 h-3.5 text-indigo-400" />
            <span>Category:</span>
          </div>

          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}

          {/* Match Score Slider */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800 text-xs">
            <span className="text-slate-400 text-[11px] whitespace-nowrap">Min Match:</span>
            <input
              type="range"
              min="65"
              max="95"
              step="5"
              value={minScore}
              onChange={(e) => setMinScore(Number(e.target.value))}
              className="w-20 accent-indigo-500 cursor-pointer"
            />
            <span className="font-mono text-emerald-400 text-[11px] font-bold">{minScore}%+</span>
          </div>
        </div>

        {/* 3D Legend Pill */}
        <div className="pointer-events-auto px-3 py-2 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-800 shadow-xl flex items-center gap-3 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400" />
            <span>Learner Core</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <span>Skill Gap</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400" />
            <span>Top Course</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500 shadow-sm shadow-purple-500" />
            <span>Career Goal</span>
          </div>
        </div>
      </div>
    </div>
  );
}
