import React, { useState, useMemo } from 'react';
import {
  Search,
  Sparkles,
  BookOpen,
  Brain,
  Layers,
  User,
  ArrowRight,
  Clock,
  Star,
  CheckCircle2,
  X
} from 'lucide-react';
import { coursesData, skillGalaxyData, adaptiveLearningPathsData } from '../data/mockData';

export default function SearchAndDiscovery({
  isOpen,
  onClose,
  onSelectCourse,
  onShowToast,
}) {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All'); // 'All', 'Courses', 'Skills', 'Instructors', 'Paths'

  // Intelligent Search and Did-you-mean fuzzy suggestions
  const { results, didYouMean, relatedSuggestion } = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return { results: [], didYouMean: null, relatedSuggestion: null };
    }

    // Common typos & corrections dictionary
    const corrections = {
      'pyton': 'python',
      'pythn': 'python',
      'statstics': 'statistics',
      'stats': 'statistics',
      'padas': 'pandas',
      'machin': 'machine learning',
      'deeplearning': 'deep learning',
      'neurall': 'neural networks',
      'sqll': 'sql',
    };

    let suggestion = null;
    Object.keys(corrections).forEach((typo) => {
      if (q.includes(typo)) {
        suggestion = q.replace(typo, corrections[typo]);
      }
    });

    // "Because you searched for X, you may also like..." contextual recommendation
    let related = null;
    if (q.includes('python')) {
      related = {
        keyword: 'Python',
        course: coursesData.find((c) => c.id === 'c3') || coursesData[1],
        reason: 'Because you searched for Python, learners often also study Scikit-Learn Ensembles next.',
      };
    } else if (q.includes('statistics') || q.includes('stats')) {
      related = {
        keyword: 'Statistics',
        course: coursesData.find((c) => c.id === 'c_dataviz') || coursesData[2],
        reason: 'Because you searched for Statistics, interactive visual storytelling with Plotly pairs naturally.',
      };
    } else if (q.includes('sql') || q.includes('database')) {
      related = {
        keyword: 'SQL',
        course: coursesData.find((c) => c.id === 'c6') || coursesData[3],
        reason: 'Because you searched for SQL, distributed Spark & Kafka pipelines scale relational queries.',
      };
    }

    // Search across courses
    const matchingCourses = coursesData.filter((c) =>
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.tags.some((t) => t.toLowerCase().includes(q)) ||
      c.skillsTaught.some((s) => s.toLowerCase().includes(q))
    ).map((c) => ({ ...c, resultType: 'Course' }));

    // Search across instructors
    const matchingInstructors = coursesData.filter((c) =>
      c.instructor.name.toLowerCase().includes(q) ||
      c.instructor.bio.toLowerCase().includes(q)
    ).map((c) => ({ ...c, resultType: 'Instructor' }));

    // Search across skills
    const matchingSkills = [];
    skillGalaxyData.categories.forEach((cat) => {
      cat.skills.forEach((sk) => {
        if (sk.name.toLowerCase().includes(q) || sk.description.toLowerCase().includes(q)) {
          matchingSkills.push({
            id: sk.id,
            title: sk.name,
            description: sk.description,
            score: sk.score,
            category: cat.name,
            resultType: 'Skill',
          });
        }
      });
    });

    // Search across learning paths
    const matchingPaths = adaptiveLearningPathsData.filter((p) =>
      p.title.toLowerCase().includes(q) ||
      p.courseTitle.toLowerCase().includes(q)
    ).map((p) => ({ ...p, resultType: 'Learning Path' }));

    let combined = [];
    if (activeFilter === 'All') {
      combined = [...matchingCourses, ...matchingSkills, ...matchingPaths];
    } else if (activeFilter === 'Courses') {
      combined = matchingCourses;
    } else if (activeFilter === 'Skills') {
      combined = matchingSkills;
    } else if (activeFilter === 'Paths') {
      combined = matchingPaths;
    }

    return {
      results: combined.slice(0, 10),
      didYouMean: suggestion,
      relatedSuggestion: related,
    };
  }, [query, activeFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 pt-16 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-indigo-500/30 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col">
        {/* Search Header Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/80 flex items-center gap-3">
          <Search className="w-5 h-5 text-indigo-400 flex-shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search courses, skills, topics, instructors, learning paths..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm sm:text-base text-white placeholder:text-slate-500 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
          >
            Esc
          </button>
        </div>

        {/* Filter Pills */}
        <div className="px-5 py-2.5 bg-slate-950/40 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar text-xs">
          {['All', 'Courses', 'Skills', 'Paths'].map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1 rounded-xl font-medium transition-all ${
                activeFilter === f
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Modal Results Body */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[60vh] overflow-y-auto no-scrollbar">
          {/* Did You Mean Suggestion (Prompt Section 11) */}
          {didYouMean && (
            <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs flex items-center justify-between text-indigo-300">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>
                  Did you mean: <strong className="text-white underline cursor-pointer" onClick={() => setQuery(didYouMean)}>{didYouMean}</strong>?
                </span>
              </div>
              <button
                onClick={() => setQuery(didYouMean)}
                className="text-[11px] font-bold text-cyan-300 hover:text-white"
              >
                Apply
              </button>
            </div>
          )}

          {/* Contextual Recommendation Suggestion (Prompt Section 11) */}
          {relatedSuggestion && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/40 to-slate-900 border border-emerald-500/30 text-xs flex items-start justify-between gap-3">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Intelligent Discovery
                </span>
                <p className="text-slate-300 leading-snug">
                  {relatedSuggestion.reason}
                </p>
                <span className="text-xs font-bold text-white block mt-0.5">
                  👉 {relatedSuggestion.course.title}
                </span>
              </div>

              <button
                onClick={() => {
                  onSelectCourse?.(relatedSuggestion.course);
                  onClose();
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex-shrink-0"
              >
                View
              </button>
            </div>
          )}

          {/* Results List */}
          {results.length > 0 ? (
            <div className="space-y-2">
              {results.map((res, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    if (res.resultType === 'Course') {
                      onSelectCourse?.(res);
                      onClose();
                    } else {
                      onShowToast?.({
                        type: 'info',
                        title: `${res.resultType} Selected`,
                        message: `Opened ${res.title}.`,
                      });
                    }
                  }}
                  className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 hover:border-indigo-500/50 cursor-pointer transition-all flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-indigo-400 flex-shrink-0 group-hover:scale-105 transition-transform">
                      {res.resultType === 'Course' && <BookOpen className="w-4 h-4" />}
                      {res.resultType === 'Skill' && <Brain className="w-4 h-4 text-cyan-400" />}
                      {res.resultType === 'Learning Path' && <Layers className="w-4 h-4 text-purple-400" />}
                      {res.resultType === 'Instructor' && <User className="w-4 h-4 text-emerald-400" />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                          {res.resultType}
                        </span>
                        {res.category && (
                          <span className="text-[10px] text-indigo-400">
                            • {res.category}
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-slate-100 text-sm truncate group-hover:text-indigo-400 transition-colors">
                        {res.title}
                      </h4>
                      <p className="text-xs text-slate-400 truncate">
                        {res.description || res.courseTitle || (res.instructor && `Instructor: ${res.instructor.name}`)}
                      </p>
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 group-hover:translate-x-1 transition-all flex-shrink-0" />
                </div>
              ))}
            </div>
          ) : query ? (
            <div className="py-8 text-center text-slate-400 space-y-1">
              <p className="text-sm font-semibold">No direct results found for "{query}"</p>
              <p className="text-xs text-slate-500">Try searching for "Python", "Statistics", "Machine Learning", or "SQL".</p>
            </div>
          ) : (
            <div className="py-6 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                Trending Searches in Data Science
              </span>
              <div className="flex flex-wrap gap-2 text-xs">
                {['Python Pandas', 'Statistics Diagnostic', 'SQL Window Functions', 'Machine Learning XGBoost', 'PyTorch Transformers'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
