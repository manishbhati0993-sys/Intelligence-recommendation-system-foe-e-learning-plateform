import React from 'react';

export default function ProgressBar({
  progress = 0,
  label = '',
  size = 'md',
  showPercentage = true,
  variant = 'indigo',
  className = '',
}) {
  const clampedProgress = Math.min(100, Math.max(0, Math.round(progress)));

  const heightClasses = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-4',
  };

  const gradientClasses = {
    indigo: 'from-indigo-500 via-purple-500 to-indigo-600',
    emerald: 'from-emerald-400 to-teal-500',
    amber: 'from-amber-400 to-orange-500',
    rose: 'from-rose-500 to-pink-600',
    cyan: 'from-cyan-400 to-blue-500',
  };

  return (
    <div className={`w-full ${className}`}>
      {(label || showPercentage) && (
        <div className="flex items-center justify-between text-xs font-medium mb-1.5">
          {label && <span className="text-slate-300 dark:text-slate-300 font-semibold">{label}</span>}
          {showPercentage && (
            <span className="text-slate-400 dark:text-slate-400 ml-auto font-mono">
              {clampedProgress}%
            </span>
          )}
        </div>
      )}
      <div
        className={`w-full bg-slate-800/80 dark:bg-slate-800/80 rounded-full overflow-hidden p-0.5 border border-slate-700/50 ${heightClasses[size] || heightClasses.md}`}
      >
        <div
          className={`h-full rounded-full bg-gradient-to-r ${gradientClasses[variant] || gradientClasses.indigo} transition-all duration-700 ease-out`}
          style={{ width: `${clampedProgress}%` }}
        />
      </div>
    </div>
  );
}
