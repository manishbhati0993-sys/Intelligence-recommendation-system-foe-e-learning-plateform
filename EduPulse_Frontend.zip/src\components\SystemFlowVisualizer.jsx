import React, { useState } from 'react';
import {
  UserCheck,
  FileCheck,
  Cpu,
  Building2,
  Briefcase,
  Award,
  ArrowRight,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  Zap,
  Activity,
  ShieldCheck
} from 'lucide-react';

export default function SystemFlowVisualizer({ onSelectStep }) {
  const [activeStepIndex, setActiveStepIndex] = useState(2); // default highlighting Skill Mapping Engine

  const steps = [
    {
      id: 'step-1',
      number: '01',
      title: 'Student Onboarding',
      icon: UserCheck,
      color: 'from-blue-500 to-cyan-500',
      tag: 'Input Layer',
      subtitle: 'Profile & Academic Baseline',
      desc: 'Students register with university credentials, CGPA, target career aspirations, and initial self-reported skill proficiencies.',
      metrics: '48,000+ Active Profiles',
      features: ['DigiLocker / College ID Auth', 'GitHub & LeetCode Integration', 'Academic Transcript Parsing']
    },
    {
      id: 'step-2',
      number: '02',
      title: 'Skill Assessment',
      icon: FileCheck,
      color: 'from-cyan-500 to-teal-500',
      tag: 'Diagnostic Testing',
      subtitle: 'Adaptive MCQ + Project Lab',
      desc: 'Dynamic timed coding evaluations, cognitive assessments, and project repository analyzers quantify real hands-on competency.',
      metrics: '120+ Verified Competency Tracks',
      features: ['Anti-cheat Proctored Quizzes', 'Dockerized Code Sandbox', 'Git Commit Velocity Auditing']
    },
    {
      id: 'step-3',
      number: '03',
      title: 'Skill Mapping Engine',
      icon: Cpu,
      color: 'from-teal-500 to-emerald-500',
      tag: 'Core AI Core',
      subtitle: 'Vector Embeddings & Gap Analysis',
      desc: 'Transforms student scores into multi-dimensional skill vectors and calculates Euclidean distance against live Tier-1 industry hiring benchmarks.',
      metrics: 'Real-time Vector Cosine Matching',
      features: ['Continuous Curricular Gap Detection', 'Personalized Learning Milestones', 'Departmental Syllabus Insights']
    },
    {
      id: 'step-4',
      number: '04',
      title: 'Industry Portal',
      icon: Building2,
      color: 'from-emerald-500 to-green-500',
      tag: 'Corporate Interface',
      subtitle: 'Recruiter Demand Benchmarks',
      desc: 'Enterprises post live problem statements, required skill weightages (High/Medium/Low), and review auto-vetted talent pipelines.',
      metrics: '620+ Verified Corporates',
      features: ['Dynamic Role Skill Presets', '1-Click Talent Shortlisting', 'Real-time Interview Scheduling']
    },
    {
      id: 'step-5',
      number: '05',
      title: 'Smart Internship Matching',
      icon: Briefcase,
      color: 'from-amber-500 to-orange-500',
      tag: 'Recommendation Engine',
      subtitle: 'Multi-criteria Smart Match %',
      desc: 'Matches candidates with internships using verified skill scores, project portfolios, and location preferences with clear match explanations.',
      metrics: '94.6% Candidate-Role Match Accuracy',
      features: ['Exact vs Missing Skill Breakdown', 'Automated Application Tracking', 'Stipend & PPO Verification']
    },
    {
      id: 'step-6',
      number: '06',
      title: 'Verified Certification',
      icon: Award,
      color: 'from-violet-500 to-purple-500',
      tag: 'Outcome & Credentials',
      subtitle: 'Tamper-proof Digital Portfolio',
      desc: 'Upon project completion, micro-credentials and industry-endorsed verifiable badges are issued to build an unforgeable digital portfolio.',
      metrics: '18,200+ Verifiable Badges Issued',
      features: ['Cryptographically Signed Badges', 'College Credit Recommendation', 'Direct PPO Conversion']
    }
  ];

  const activeStep = steps[activeStepIndex];

  return (
    <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl relative overflow-hidden backdrop-blur-xl">
      
      {/* Background Glow */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Header */}
      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            End-to-End System Architecture
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            How <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">SkillBridge</span> Works
          </h2>
          <p className="text-sm text-slate-400 max-w-xl mt-1">
            Seamless closed-loop journey from initial student diagnostic test to verified corporate certification and placement.
          </p>
        </div>

        {/* Live Status indicator */}
        <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="text-slate-300 font-medium">Real-time Pipeline:</span>
          <span className="text-emerald-400 font-bold">100% Operational</span>
        </div>
      </div>

      {/* Horizontal Step Flow Pipeline */}
      <div className="relative z-10 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          const isSelected = activeStepIndex === idx;

          return (
            <div
              key={step.id}
              onClick={() => setActiveStepIndex(idx)}
              className={`cursor-pointer rounded-2xl p-4 transition-all duration-300 relative border flex flex-col justify-between ${
                isSelected
                  ? 'bg-slate-800/90 border-cyan-500/80 shadow-lg shadow-cyan-500/15 ring-2 ring-cyan-400/30 -translate-y-1'
                  : 'bg-slate-950/50 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
              }`}
            >
              {/* Connector arrow line on desktop */}
              {idx < steps.length - 1 && (
                <div className="hidden lg:block absolute -right-3.5 top-1/2 -translate-y-1/2 z-20 pointer-events-none text-slate-600">
                  <ChevronRight className="w-4 h-4" />
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                    isSelected ? 'bg-cyan-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {step.number}
                  </span>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
                    {step.tag}
                  </span>
                </div>

                <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${step.color} p-0.5 mb-3 shadow-md flex items-center justify-center`}>
                  <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                </div>

                <h4 className="font-bold text-sm text-white leading-snug">
                  {step.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                  {step.subtitle}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between">
                <span className={`text-[10px] font-semibold ${isSelected ? 'text-cyan-400' : 'text-slate-500'}`}>
                  {isSelected ? 'Viewing Details' : 'Click to inspect'}
                </span>
                {isSelected && <Sparkles className="w-3 h-3 text-cyan-400 animate-spin-slow" />}
              </div>
            </div>
          );
        })}
      </div>

      {/* Expanded Active Step Inspector */}
      {activeStep && (
        <div className="relative z-10 p-6 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-cyan-500/30 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            
            <div className="lg:col-span-7 space-y-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 text-xs font-black rounded-md bg-cyan-400 text-slate-950">
                  Step {activeStep.number}
                </span>
                <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
                  {activeStep.tag}
                </span>
                <span className="text-slate-500">•</span>
                <span className="text-xs text-slate-400">{activeStep.subtitle}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-white">
                {activeStep.title}
              </h3>

              <p className="text-sm text-slate-300 leading-relaxed">
                {activeStep.desc}
              </p>

              {/* Core Feature bullets */}
              <div className="pt-2 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {activeStep.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Metric & Interactive Action Banner */}
            <div className="lg:col-span-5 flex flex-col justify-center p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 space-y-4">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Live System Throughput
                </div>
                <div className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400 mt-0.5">
                  {activeStep.metrics}
                </div>
              </div>

              <div className="text-xs text-slate-400 leading-relaxed">
                Seamlessly integrated with industry-standard telemetry, verifiable credential stores, and national education databases.
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => setActiveStepIndex((prev) => (prev + 1) % steps.length)}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
                >
                  Next Step: {steps[(activeStepIndex + 1) % steps.length].title}
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <span className="text-xs font-mono text-slate-500">
                  {activeStepIndex + 1} / {steps.length}
                </span>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
