import React, { useState } from 'react';
import { Scan, Eye, EyeOff, Upload, Sparkles, CheckCircle2, AlertCircle, RefreshCcw, Layers } from 'lucide-react';

export default function VisionScanner({ sampleScans = [], onAnalyzeScan }) {
  const [selectedScanIndex, setSelectedScanIndex] = useState(0);
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [customImage, setCustomImage] = useState(null);

  const activeScan = sampleScans[selectedScanIndex] || sampleScans[0];

  const handleSelectPreset = (idx) => {
    setSelectedScanIndex(idx);
    setCustomImage(null);
    setAnalysisResult(null);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setCustomImage(event.target.result);
        setAnalysisResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRunVisionAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scanId: customImage ? null : activeScan.id,
          customImage,
          scanType: activeScan ? activeScan.type : 'Radiography'
        })
      });
      const data = await res.json();
      if (data.success) {
        setAnalysisResult(data.scanAnalysis);
      }
    } catch (err) {
      console.error("Vision scan failed:", err);
      // Fallback
      setAnalysisResult(activeScan);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const currentFindings = analysisResult ? analysisResult.findings : activeScan?.findings || [];
  const currentSeverity = analysisResult ? analysisResult.severity : activeScan?.severity || 'Moderate';

  return (
    <div class="glass-panel p-6 space-y-6 border border-slate-800">
      
      {/* Header */}
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div class="flex items-center gap-3">
          <div class="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Scan class="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 class="text-xl font-extrabold text-white">AI Medical Vision & Radiology Scanner</h2>
            <p class="text-xs text-slate-400">Automated diagnostic feature extractions for X-Rays, CT Scans, MRIs & Lesions</p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowHeatmap(!showHeatmap)}
            class={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
              showHeatmap
                ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            {showHeatmap ? <Eye class="w-4 h-4" /> : <EyeOff class="w-4 h-4" />}
            3D Heatmap Overlay
          </button>
        </div>
      </div>

      {/* Preset Selector Grid */}
      <div class="space-y-2">
        <label class="text-xs font-bold text-slate-300 uppercase tracking-wider">Select Sample Diagnostic Scan or Upload Custom:</label>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {sampleScans.map((scan, idx) => (
            <button
              key={scan.id}
              type="button"
              onClick={() => handleSelectPreset(idx)}
              class={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 ${
                selectedScanIndex === idx && !customImage
                  ? 'bg-cyan-500/15 border-cyan-500 text-white shadow-lg shadow-cyan-500/10'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <img src={scan.imageUrl} alt={scan.title} class="w-10 h-10 rounded-lg object-cover border border-slate-800" />
              <div class="overflow-hidden">
                <h4 class="text-xs font-bold truncate text-white">{scan.type}</h4>
                <p class="text-[10px] text-slate-400 truncate">{scan.title.split('-')[0]}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Image Inspector & Findings Grid */}
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left: Scan Preview Canvas Frame */}
        <div class="relative w-full h-80 sm:h-96 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center group shadow-2xl">
          <img
            src={customImage || activeScan?.imageUrl}
            alt="Medical Scan Preview"
            class="w-full h-full object-cover opacity-90 transition group-hover:scale-105 duration-700"
          />

          {/* Simulated 3D Heatmap Gradient Overlay */}
          {showHeatmap && (
            <div class="absolute inset-0 bg-gradient-to-tr from-cyan-500/30 via-emerald-500/20 to-transparent mix-blend-overlay pointer-events-none animate-pulse-slow">
              <div class="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full bg-rose-500/30 blur-2xl animate-ping" style={{ animationDuration: '4s' }} />
            </div>
          )}

          {/* Holographic Target Reticle */}
          <div class="absolute inset-0 border-2 border-cyan-500/20 pointer-events-none flex items-center justify-center">
            <div class="w-32 h-32 border border-cyan-400/40 rounded-full flex items-center justify-center animate-spin-slow">
              <div class="w-2 h-2 rounded-full bg-cyan-400"></div>
            </div>
          </div>

          {/* Upload overlay trigger */}
          <label class="absolute bottom-4 right-4 px-3.5 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-white text-xs font-bold cursor-pointer transition flex items-center gap-2 shadow-xl">
            <Upload class="w-4 h-4 text-cyan-400" /> Upload DICOM / Image
            <input type="file" accept="image/*" onChange={handleFileUpload} class="hidden" />
          </label>
        </div>

        {/* Right: AI Vision Analysis Findings */}
        <div class="space-y-4">
          <div class="glass-card p-4 space-y-3">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles class="w-4 h-4" /> AI Computer Vision Analysis
              </span>
              <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-slate-900 border border-slate-800 text-slate-300">
                ResNet-50 / ViT Model
              </span>
            </div>

            <h3 class="text-lg font-bold text-white">
              {customImage ? "Custom Uploaded Scan Analysis" : activeScan?.title}
            </h3>

            <div class="flex items-center gap-3">
              <span class="text-xs font-semibold text-slate-400">Severity Classification:</span>
              <span class="px-2.5 py-1 text-xs font-extrabold rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {currentSeverity}
              </span>
            </div>
          </div>

          {/* Key Findings List */}
          <div class="space-y-2">
            <h4 class="text-xs font-bold uppercase tracking-wider text-slate-300">Extracted Radiographic Findings:</h4>
            <div class="space-y-2">
              {currentFindings.map((finding, i) => (
                <div key={i} class="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 leading-relaxed flex items-start gap-2.5">
                  <CheckCircle2 class="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{finding}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Execute Vision Re-Analysis Button */}
          <button
            type="button"
            onClick={handleRunVisionAnalysis}
            disabled={isAnalyzing}
            class="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-400 text-slate-950 font-bold text-xs hover:opacity-95 transition shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
          >
            {isAnalyzing ? (
              <>
                <RefreshCcw class="w-4 h-4 animate-spin" /> Analyzing Image Convolution Feature Maps...
              </>
            ) : (
              <>
                <Sparkles class="w-4 h-4" /> Run Deep Learning Feature Extraction Scan
              </>
            )}
          </button>
        </div>

      </div>

    </div>
  );
}
