import React, { useState } from 'react';
import { UserCheck, BookOpen, Award, FileText, CheckCircle2, ArrowUpRight, Zap, Users, Sparkles } from 'lucide-react';

export default function AcademicianPortal({ fdps = [] }) {
  const [appliedFdpSet, setAppliedFdpSet] = useState(new Set());

  const handleFdpApply = (id) => {
    setAppliedFdpSet((prev) => new Set(prev).add(id));
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Banner */}
      <div className="glass-panel p-6 sm:p-8 border border-purple-500/30 relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-bold uppercase tracking-wider">
            <UserCheck className="w-3.5 h-3.5" /> Core Feature #5 • Dedicated Academician & Faculty Portal
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Faculty Industrial Immersion & <span className="gradient-text">Research Collaboration</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Connecting academicians with industrial immersion programs, Faculty Development Programs (FDPs), joint industry-funded consultancy projects, and curriculum modernization grants.
          </p>
        </div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="glass-card flex items-center gap-4 border border-purple-500/20">
          <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400">Active FDP Immersion Grants</p>
            <h3 className="text-xl font-bold text-white">12 Available</h3>
            <span className="text-[10px] text-purple-400 font-semibold">CSIR & ICMR Sponsored</span>
          </div>
        </div>

        <div className="glass-card flex items-center gap-4 border border-cyan-500/20">
          <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400">Joint Industry R&D Grants</p>
            <h3 className="text-xl font-bold text-white">₹1.5 Crores</h3>
            <span className="text-[10px] text-emerald-400 font-semibold">Ministry of Ayush Seed Fund</span>
          </div>
        </div>

        <div className="glass-card flex items-center gap-4 border border-emerald-500/20">
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400">Faculty Enrolled Nationwide</p>
            <h3 className="text-xl font-bold text-white">840+ Professors</h3>
            <span className="text-[10px] text-cyan-400 font-semibold">140+ Institutions</span>
          </div>
        </div>

      </div>

      {/* Active Faculty Programs List */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          <span>Active Faculty Development & Industrial Immersion Programs</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {fdps.map((fdp) => {
            const isApplied = appliedFdpSet.has(fdp.id);
            return (
              <div key={fdp.id} className="glass-panel p-6 border border-slate-800 space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  
                  <div className="flex justify-between items-start">
                    <span className="px-2.5 py-1 rounded text-[10px] font-bold bg-purple-500/20 text-purple-400 border border-purple-500/30">
                      {fdp.grantStipend}
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold">{fdp.seats} Available</span>
                  </div>

                  <h4 className="text-base font-bold text-white leading-snug">{fdp.title}</h4>
                  <p className="text-xs text-cyan-400 font-semibold">{fdp.organizer}</p>

                  <div className="space-y-1 bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-xs">
                    <div className="flex justify-between text-slate-300">
                      <span>Dates / Window:</span>
                      <span className="font-bold text-white">{fdp.dates}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Eligibility:</span>
                      <span className="font-bold text-emerald-400">{fdp.eligibility}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {fdp.focusArea}
                  </p>

                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-medium">
                    👥 {fdp.appliedCount + (isApplied ? 1 : 0)} Faculty Candidates
                  </span>

                  <button
                    type="button"
                    onClick={() => handleFdpApply(fdp.id)}
                    disabled={isApplied}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                      isApplied
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
                    }`}
                  >
                    {isApplied ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" /> Applied
                      </>
                    ) : (
                      <>
                        <span>Apply for Fellowship</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
