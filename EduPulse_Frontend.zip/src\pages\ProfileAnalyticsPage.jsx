import React, { useState } from 'react';
import {
  User,
  Award,
  Clock,
  TrendingUp,
  Sliders,
  Sparkles,
  Flame,
  CheckCircle2,
  BrainCircuit,
  Calendar,
  Save,
  Plus,
  X,
  Target,
  BarChart3,
  Cpu,
  ShieldCheck,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import ProgressBar from '../components/ProgressBar';
import { careerRolesData } from '../data/mockData';

export default function ProfileAnalyticsPage({
  user,
  onUpdatePreferences,
  onShowToast,
}) {
  const [activeTab, setActiveTab] = useState('analytics'); // 'analytics', 'achievements', 'preferences'

  // Editable Preferences State
  const [targetCareer, setTargetCareer] = useState(
    user.preferences?.targetCareer || user.targetRole || 'AI / Machine Learning Engineer'
  );
  const [preferredDifficulty, setPreferredDifficulty] = useState(
    user.preferences?.preferredDifficulty || 'Intermediate to Advanced'
  );
  const [weeklyCommitment, setWeeklyCommitment] = useState(
    user.preferences?.weeklyCommitmentHours || 10
  );
  const [learningStyle, setLearningStyle] = useState(
    user.preferences?.learningStyle || 'Hands-on Coding Labs & Real-World Projects'
  );
  const [interestTags, setInterestTags] = useState(
    user.preferences?.interestTags || [
      'Deep Learning',
      'PyTorch',
      'Large Language Models',
      'MLOps',
      'Vector Databases',
      'Computer Vision',
    ]
  );
  const [newTagInput, setNewTagInput] = useState('');

  // AI Recommendation Engine Weights
  const [weights, setWeights] = useState(
    user.preferences?.weights || {
      careerGoalMatch: 45,
      skillGapClosure: 35,
      peerPopularity: 10,
      completionPace: 10,
    }
  );

  const handleAddTag = (e) => {
    e.preventDefault();
    if (newTagInput.trim() && !interestTags.includes(newTagInput.trim())) {
      setInterestTags([...interestTags, newTagInput.trim()]);
      setNewTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setInterestTags(interestTags.filter((t) => t !== tagToRemove));
  };

  const handleSavePreferences = () => {
    const updated = {
      targetCareer,
      preferredDifficulty,
      weeklyCommitmentHours: Number(weeklyCommitment),
      learningStyle,
      interestTags,
      weights,
    };
    onUpdatePreferences?.(updated);
    onShowToast?.({
      type: 'success',
      title: 'AI Recommendation Settings Saved',
      message: 'Your neural vector preferences have been updated and synced.',
    });
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Profile Header Banner */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          {/* Avatar and Details */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-indigo-500/50 shadow-xl shadow-indigo-600/20"
              />
              <div
                className="absolute -bottom-2 -right-2 p-1.5 rounded-xl bg-amber-500 text-slate-950 shadow-md font-bold text-xs"
                title="14-Day Streak"
              >
                <Flame className="w-4 h-4 fill-current text-slate-950" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h1 className="text-2xl font-extrabold text-slate-100">{user.name}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Tier 3 Scholar
                </span>
              </div>
              <p className="text-xs text-slate-400">{user.email}</p>
              <p className="text-xs font-semibold text-teal-400 mt-1 flex items-center justify-center sm:justify-start gap-1">
                <Target className="w-3.5 h-3.5" />
                <span>Target: {user.targetRole}</span>
              </p>
            </div>
          </div>

          {/* Quick Stat Badges */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-xl font-extrabold text-slate-100 font-mono">{user.overallSkillScore}</p>
              <p className="text-[10px] text-slate-400">Skill Score</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-xl font-extrabold text-teal-400 font-mono">{user.totalHoursLearned}h</p>
              <p className="text-[10px] text-slate-400">Hours Studied</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-xl font-extrabold text-amber-400 font-mono">{user.streakDays}d</p>
              <p className="text-[10px] text-slate-400">Daily Streak</p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="mt-8 pt-4 border-t border-slate-800/80 flex gap-6 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('analytics')}
            className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'analytics'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Learning Analytics & Trends</span>
          </button>

          <button
            onClick={() => setActiveTab('achievements')}
            className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'achievements'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Badges & Achievements ({user.achievements?.length || 4})</span>
          </button>

          <button
            onClick={() => setActiveTab('preferences')}
            className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'preferences'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>AI Recommendation Engine Settings</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Analytics & Performance Charts */}
      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Weekly Hours Study Chart */}
          <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-100 text-base">Weekly Study Hours vs Target</h3>
                <p className="text-xs text-slate-400">Total 7.5 hrs studied this week (Target: 10 hrs)</p>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                75% of Goal
              </span>
            </div>

            <div className="w-full h-72 pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={user.weeklyStudyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="day" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '0.75rem',
                      fontSize: '11px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  <Bar dataKey="hours" name="Hours Learned" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="targetHours" name="Daily Target" fill="#334155" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 6-Month Skill Growth Progression Chart */}
          <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-100 text-base">6-Month Skill Score Velocity</h3>
                <p className="text-xs text-slate-400">Grew from 54 to 84 (+30 points) since enrollment</p>
              </div>
              <span className="text-xs font-mono font-bold text-teal-400 bg-teal-500/10 px-2.5 py-1 rounded-lg border border-teal-500/20">
                +55% Growth
              </span>
            </div>

            <div className="w-full h-72 pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={user.monthlySkillGrowth} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorSkill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} domain={[40, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '0.75rem',
                      fontSize: '11px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="skillScore"
                    name="Skill Score"
                    stroke="#14b8a6"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#colorSkill)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recent Learning Activity Timeline */}
          <div className="lg:col-span-12 p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-400" />
              <span>Learning Activity History</span>
            </h3>

            <div className="divide-y divide-slate-800/60">
              {(user.recentActivity || []).map((act) => (
                <div key={act.id} className="py-3.5 flex items-center justify-between gap-4 text-xs">
                  <div className="flex items-center gap-3">
                    <span className="w-2 h-2 rounded-full bg-indigo-400" />
                    <div>
                      <p className="font-bold text-slate-200">{act.title}</p>
                      <p className="text-[11px] text-slate-400">{act.courseTitle}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 flex-shrink-0">
                    {act.score && (
                      <span className="font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                        Score: {act.score}
                      </span>
                    )}
                    <span className="text-slate-500 text-[11px]">{act.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Achievements & Badges */}
      {activeTab === 'achievements' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {(user.achievements || []).map((ach) => (
            <div
              key={ach.id}
              className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 transition-all hover:shadow-xl hover:shadow-indigo-500/10 flex flex-col items-center text-center space-y-3 group"
            >
              <div
                className={`w-16 h-16 rounded-2xl bg-gradient-to-tr ${ach.badgeColor} p-0.5 shadow-lg shadow-indigo-600/20 group-hover:scale-110 transition-transform`}
              >
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Award className="w-8 h-8 text-amber-300" />
                </div>
              </div>

              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20">
                {ach.rarity}
              </span>

              <h4 className="font-bold text-slate-100 text-base">{ach.title}</h4>
              <p className="text-xs text-slate-400 leading-relaxed">{ach.description}</p>
              <span className="text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800/80 w-full">
                Unlocked on {ach.earnedDate}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: AI Recommendation Engine Settings */}
      {activeTab === 'preferences' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-8 max-w-4xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-lg">
                Recommendation Algorithm Hyperparameters
              </h3>
              <p className="text-xs text-slate-400">
                Tune how the AI scores, ranks, and filters courses in your personal feed
              </p>
            </div>
          </div>

          <div className="space-y-6 text-xs">
            {/* Target Career Preset */}
            <div>
              <label className="block font-bold text-slate-200 mb-1.5">Target Career Goal</label>
              <select
                value={targetCareer}
                onChange={(e) => setTargetCareer(e.target.value)}
                className="w-full max-w-md px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              >
                {careerRolesData.map((role) => (
                  <option key={role.id} value={role.name}>
                    {role.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Weekly Commitment Slider */}
            <div>
              <div className="flex items-center justify-between max-w-md mb-1.5">
                <label className="font-bold text-slate-200">Weekly Time Commitment</label>
                <span className="font-mono font-bold text-indigo-400">{weeklyCommitment} hrs / week</span>
              </div>
              <input
                type="range"
                min="4"
                max="25"
                step="1"
                value={weeklyCommitment}
                onChange={(e) => setWeeklyCommitment(e.target.value)}
                className="w-full max-w-md accent-indigo-500 cursor-pointer"
              />
            </div>

            {/* AI Scoring Weights Sliders */}
            <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-4 max-w-xl">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 text-sm flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  Neural Match Scoring Weights
                </span>
                <span className="text-[11px] text-slate-400 font-mono">Total: 100%</span>
              </div>

              {/* Weight 1 */}
              <div>
                <div className="flex justify-between mb-1 text-slate-300 font-medium">
                  <span>Target Career Goal Alignment</span>
                  <span className="font-mono text-indigo-400">{weights.careerGoalMatch}%</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="70"
                  value={weights.careerGoalMatch}
                  onChange={(e) => setWeights({ ...weights, careerGoalMatch: Number(e.target.value) })}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              {/* Weight 2 */}
              <div>
                <div className="flex justify-between mb-1 text-slate-300 font-medium">
                  <span>Skill Gap Remediation Priority</span>
                  <span className="font-mono text-teal-400">{weights.skillGapClosure}%</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="60"
                  value={weights.skillGapClosure}
                  onChange={(e) => setWeights({ ...weights, skillGapClosure: Number(e.target.value) })}
                  className="w-full accent-teal-500 cursor-pointer"
                />
              </div>

              {/* Weight 3 */}
              <div>
                <div className="flex justify-between mb-1 text-slate-300 font-medium">
                  <span>Peer Popularity & Ratings</span>
                  <span className="font-mono text-amber-400">{weights.peerPopularity}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="40"
                  value={weights.peerPopularity}
                  onChange={(e) => setWeights({ ...weights, peerPopularity: Number(e.target.value) })}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Topic Interest Tags */}
            <div>
              <label className="block font-bold text-slate-200 mb-1.5">
                Priority Topic Interest Tags
              </label>
              <div className="flex flex-wrap gap-2 mb-3">
                {interestTags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold"
                  >
                    <span>{tag}</span>
                    <button
                      onClick={() => handleRemoveTag(tag)}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
              </div>

              <form onSubmit={handleAddTag} className="flex gap-2 max-w-sm">
                <input
                  type="text"
                  placeholder="Add custom interest tag (e.g. CUDA, vLLM)..."
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add</span>
                </button>
              </form>
            </div>

            {/* Save Button */}
            <div className="pt-4 border-t border-slate-800">
              <button
                onClick={handleSavePreferences}
                className="py-3 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 hover:scale-105 active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>Save & Sync AI Recommendation Engine</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
