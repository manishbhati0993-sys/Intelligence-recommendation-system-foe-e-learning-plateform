import React from 'react';
import {
  Sparkles,
  X,
  Target,
  TrendingUp,
  Brain,
  CheckCircle2,
  Bookmark,
  ExternalLink,
  BookOpen,
  Clock,
  Star,
  Users,
  Award,
  Zap,
  ArrowRight,
  ShieldCheck,
  Cpu
} from 'lucide-react';

export default function AiRecommendationInspector({
  selectedNode,
  user,
  onClose,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onFocusNode,
}) {
  if (!selectedNode) return null;

  const isBookmarked = user?.bookmarkedCourseIds?.includes(selectedNode?.course?.id);
  const isEnrolled = user?.enrolledCourses?.some(
    (enc) => enc.courseId === selectedNode?.course?.id
  );

  return (
    <aside
      className="fixed inset-y-0 right-0 z-50 w-full sm:w-[460px] bg-slate-950/95 backdrop-blur-2xl border-l border-indigo-500/20 shadow-2xl flex flex-col transform transition-transform duration-300 ease-out text-slate-100"
    >
      {/* Top Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/60">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            {selectedNode.type === 'course' && <Sparkles className="w-4 h-4 text-emerald-400" />}
            {selectedNode.type === 'skill' && <Brain className="w-4 h-4 text-amber-400" />}
            {selectedNode.type === 'role' && <Target className="w-4 h-4 text-purple-400" />}
            {selectedNode.type === 'user' && <Cpu className="w-4 h-4 text-cyan-400" />}
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              3D Neural Inspector
            </span>
            <h3 className="text-sm font-bold text-slate-200 capitalize">
              {selectedNode.type} Node Telemetry
            </h3>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          title="Close Inspector"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Scrollable Content Body */}
      <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 no-scrollbar">
        {/* CASE 1: COURSE NODE */}
        {selectedNode.type === 'course' && selectedNode.course && (
          <>
            {/* Match Score & Category Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/50 via-slate-900/80 to-slate-900 border border-indigo-500/20 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
              <div className="flex items-start justify-between gap-3">
                <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {selectedNode.course.category}
                </span>

                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-mono font-bold text-xs shadow-lg shadow-emerald-500/10">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{selectedNode.matchScore || selectedNode.course.matchScore || 94}% AI Match</span>
                </div>
              </div>

              <h2 className="mt-3 text-lg font-bold text-white leading-snug">
                {selectedNode.course.title}
              </h2>

              <p className="mt-2 text-xs text-slate-400 line-clamp-2">
                {selectedNode.course.description}
              </p>

              {/* Quick Meta Stats */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Level</span>
                  <span className="font-semibold text-slate-200">{selectedNode.course.level}</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Duration</span>
                  <span className="font-semibold text-slate-200">{selectedNode.course.durationHours || 24}h</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Rating</span>
                  <span className="font-semibold text-amber-400 flex items-center justify-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    {selectedNode.course.rating}
                  </span>
                </div>
              </div>
            </div>

            {/* Explainable AI (XAI) Vector Rationale */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-emerald-500/30 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <Brain className="w-4 h-4" />
                <span>Explainable AI (XAI) Vector Rationale</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                {selectedNode.aiMatch?.dynamicReason ||
                  selectedNode.course.recommendedReason ||
                  `Engine computed top cosine vector alignment (${selectedNode.matchScore}%) with target career profile: ${user?.targetRole}.`}
              </p>

              {/* Explainable Factor Breakdown */}
              <div className="space-y-2 pt-2 text-xs">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Target Career Affinity</span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {selectedNode.aiMatch?.roleAffinity || 96}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full"
                      style={{ width: `${selectedNode.aiMatch?.roleAffinity || 96}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Skill Deficit Gap Closure</span>
                    <span className="font-mono text-indigo-400 font-bold">
                      {selectedNode.aiMatch?.gapClosureScore || 88}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-indigo-500 h-full rounded-full"
                      style={{ width: `${selectedNode.aiMatch?.gapClosureScore || 88}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Cohort Success & Benchmark</span>
                    <span className="font-mono text-teal-400 font-bold">
                      {selectedNode.aiMatch?.ratingScore || 92}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-teal-400 h-full rounded-full"
                      style={{ width: `${selectedNode.aiMatch?.ratingScore || 92}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Skills Acquired & Competency Uplift */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-indigo-400" />
                Target Skills Uplift
              </h4>
              <div className="flex flex-wrap gap-2">
                {selectedNode.course.skillsTaught?.map((skill, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-xl text-xs bg-slate-900 border border-indigo-500/20 text-indigo-300 flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Instructor Card */}
            {selectedNode.course.instructor && (
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-3">
                <img
                  src={selectedNode.course.instructor.avatar}
                  alt={selectedNode.course.instructor.name}
                  className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                />
                <div className="min-w-0">
                  <h5 className="text-xs font-bold text-slate-200 truncate">
                    {selectedNode.course.instructor.name}
                  </h5>
                  <p className="text-[11px] text-slate-400 truncate">
                    {selectedNode.course.instructor.role}
                  </p>
                </div>
              </div>
            )}
          </>
        )}

        {/* CASE 2: SKILL GAP NODE */}
        {selectedNode.type === 'skill' && (
          <div className="space-y-5">
            <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                Identified Skill Deficit
              </span>
              <h2 className="text-lg font-bold text-white">{selectedNode.label}</h2>
              <p className="text-xs text-slate-300">
                This skill is critical for your target career role of{' '}
                <strong className="text-amber-300">{user?.targetRole}</strong>.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-slate-300">Competency Benchmark</h4>
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Your Current Mastery</span>
                    <span className="font-mono text-amber-400 font-bold">
                      {selectedNode.currentScore || 62}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-amber-400 h-full rounded-full"
                      style={{ width: `${selectedNode.currentScore || 62}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Target Industry Expectation</span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {selectedNode.targetScore || 90}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full rounded-full"
                      style={{ width: `${selectedNode.targetScore || 90}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <h4 className="text-xs font-bold text-slate-200 mb-2">AI Recommendation:</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Check the 3D green energy synapses connected from this node to view the top-scoring courses that specifically bridge this competency gap.
              </p>
            </div>
          </div>
        )}

        {/* CASE 3: TARGET ROLE BEACON */}
        {selectedNode.type === 'role' && (
          <div className="space-y-5">
            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400">
                Career Destination Beacon
              </span>
              <h2 className="text-lg font-bold text-white">{selectedNode.label}</h2>
              <p className="text-xs text-slate-300">
                Your destination milestone. All 3D course nodes radiate gravitational affinity toward this anchor.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Career Readiness Quotient</span>
                <span className="font-mono font-bold text-purple-400 text-sm">78.5%</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div className="bg-gradient-to-r from-purple-500 to-indigo-500 h-full rounded-full w-[78.5%]" />
              </div>
              <p className="text-[11px] text-slate-400">
                Estimated 3 targeted courses remaining to reach 95%+ Industry Ready threshold.
              </p>
            </div>
          </div>
        )}

        {/* CASE 4: USER CORE */}
        {selectedNode.type === 'user' && (
          <div className="space-y-5">
            <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                Learner Digital Twin Core
              </span>
              <h2 className="text-lg font-bold text-white">{user?.name || 'Alex Morgan'}</h2>
              <p className="text-xs text-slate-300">
                Origin point of your 3D Knowledge Universe. High-dimensional latent embedding computed from your completed modules and quiz performance.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Completed Courses</span>
                <span className="text-base font-bold text-slate-200">
                  {user?.completedCourseIds?.length || 4}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Active In-Progress</span>
                <span className="text-base font-bold text-indigo-400">
                  {user?.enrolledCourses?.length || 3}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Footer for Course Nodes */}
      {selectedNode.type === 'course' && selectedNode.course && (
        <div className="p-4 sm:p-5 border-t border-slate-800/80 bg-slate-900/90 space-y-2.5">
          <div className="flex gap-2">
            <button
              onClick={() => onEnroll?.(selectedNode.course.id)}
              disabled={isEnrolled}
              className={`flex-1 py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                isEnrolled
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 cursor-default'
                  : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-600/30 hover:scale-[1.02] active:scale-[0.98]'
              }`}
            >
              {isEnrolled ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Enrolled (Active)</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>Enroll in Course</span>
                </>
              )}
            </button>

            <button
              onClick={() => onToggleBookmark?.(selectedNode.course.id)}
              className={`p-2.5 rounded-xl border transition-colors ${
                isBookmarked
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
              }`}
              title={isBookmarked ? 'Remove Bookmark' : 'Add to Wishlist'}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400' : ''}`} />
            </button>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => onSelectCourse?.(selectedNode.course)}
              className="flex-1 py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span>Full Syllabus & Modules</span>
            </button>

            <button
              onClick={() => onFocusNode?.(selectedNode)}
              className="py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              title="Focus in 3D Universe"
            >
              <Target className="w-3.5 h-3.5 text-cyan-400" />
              <span>Recenter</span>
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
