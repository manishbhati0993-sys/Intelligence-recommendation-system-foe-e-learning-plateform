import React from 'react';
import { INSTITUTION_METRICS } from '../data/portalData';
import { LayoutDashboard, Users, Briefcase, TrendingUp, AlertTriangle, ShieldCheck, Download, CheckCircle2 } from 'lucide-react';

export default function InstitutionDashboard({ metrics = INSTITUTION_METRICS }) {
  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Banner */}
      <div className="glass-panel p-6 sm:p-8 border border-amber-500/30 relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <LayoutDashboard className="w-3.5 h-3.5" /> Core Feature #6 • Institution Analytics & Placement Dashboard
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Institutional Skill Analytics & <span className="gradient-text">Placement Outcome Hub</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Real-time analytics for University Deans, Placement Officers, and Academic Administrators. Track student skill progression, internship conversion rates, and skill deficiency heatmaps.
          </p>
        </div>
      </div>

      {/* Overview KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="glass-card flex items-center gap-4 border border-cyan-500/20">
          <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Enrolled Students</p>
            <h3 className="text-xl font-bold text-white">{metrics.studentsRegistered}</h3>
            <span className="text-[10px] text-cyan-400 font-semibold">100% Profile Verified</span>
          </div>
        </div>

        <div className="glass-card flex items-center gap-4 border border-emerald-500/20">
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400">
            <Briefcase className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Active Internships</p>
            <h3 className="text-xl font-bold text-white">{metrics.activeInternships}</h3>
            <span className="text-[10px] text-emerald-400 font-semibold">24 Partner Companies</span>
          </div>
        </div>

        <div className="glass-card flex items-center gap-4 border border-amber-500/20">
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Placement Rate</p>
            <h3 className="text-xl font-bold text-white">{metrics.placementPercentage}%</h3>
            <span className="text-[10px] text-amber-400 font-semibold">+8.4% YoY Increase</span>
          </div>
        </div>

        <div className="glass-card flex items-center gap-4 border border-purple-500/20">
          <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Active Industry MoUs</p>
            <h3 className="text-xl font-bold text-white">{metrics.partnerCompanies} MoUs</h3>
            <span className="text-[10px] text-purple-400 font-semibold">Ministry Accredited</span>
          </div>
        </div>

      </div>

      {/* Two Column Grid: Placement Trend + Skill Deficiency Heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Monthly Placement Trend Chart (7 cols) */}
        <div className="lg:col-span-7 glass-panel p-6 border border-slate-800 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <span>Monthly Placement & Internship Outcomes (2026 Batch)</span>
            </h3>
            <button className="text-xs font-bold text-cyan-400 hover:underline flex items-center gap-1">
              <Download className="w-3.5 h-3.5" /> Export Report
            </button>
          </div>

          {/* Bar Visualizer */}
          <div className="pt-4 flex items-end justify-between gap-3 h-48 border-b border-slate-800 pb-2">
            {metrics.monthlyPlacementTrend.map((m, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[10px] font-extrabold text-cyan-400 opacity-0 group-hover:opacity-100 transition">
                  {m.placed}
                </span>
                <div
                  className="w-full bg-gradient-to-t from-cyan-600 to-emerald-400 rounded-t-lg transition-all group-hover:brightness-125"
                  style={{ height: `${(m.placed / 150) * 100}%` }}
                />
                <span className="text-[11px] text-slate-400 font-bold">{m.month}</span>
              </div>
            ))}
          </div>

          <p className="text-xs text-slate-400">
            Total candidate placements increased by 68% following the deployment of AI Skill Assessment and Gap Training modules.
          </p>
        </div>

        {/* Top Skill Deficits Heatmap (5 cols) */}
        <div className="lg:col-span-5 glass-panel p-6 border border-amber-500/20 space-y-4">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
            <AlertTriangle className="w-5 h-5" />
            <span>Top Student Skill Deficits (Curriculum Gaps)</span>
          </div>
          <p className="text-xs text-slate-300">
            Aggregated institutional data highlighting skill gaps where student averages lag behind industry demand:
          </p>

          <div className="space-y-3 pt-2">
            {metrics.topDeficientSkills.map((item, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white">{item.skill}</span>
                  <span className="text-amber-400 font-extrabold">{item.deficitPct}% Deficit</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-500 to-rose-500 h-full"
                    style={{ width: `${item.deficitPct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
