import React, { useState } from 'react';
import { BookOpen, Award, Users, Clock, Star, CheckCircle, ArrowUpRight, Zap } from 'lucide-react';

export default function IndustryLearning({ learningPrograms = [], onEnroll }) {
  const [enrolledSet, setEnrolledSet] = useState(new Set());

  const handleEnrollClick = (progId) => {
    setEnrolledSet((prev) => new Set(prev).add(progId));
    if (onEnroll) {
      onEnroll(progId);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Banner */}
      <div className="glass-panel p-6 sm:p-8 border border-purple-500/30 relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-bold uppercase tracking-wider">
            <BookOpen className="w-3.5 h-3.5" /> Core Feature #4 • Industry Training & Certification Programs
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Industry Learning & <span className="gradient-text">Certification Academy</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Co-designed by industrial R&D leaders, top research institutions, and the Ministry of Ayush. Bridge identified skill gaps with certified hands-on workshops and masterclasses.
          </p>
        </div>
      </div>

      {/* Program Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {learningPrograms.map((prog) => {
          const isEnrolled = enrolledSet.has(prog.id);
          return (
            <div
              key={prog.id}
              className="glass-panel p-6 border border-slate-800 hover:border-purple-500/40 transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-purple-500/20 text-purple-400 border border-purple-500/30">
                    {prog.badge}
                  </span>
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{prog.rating}</span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-white leading-snug">{prog.title}</h3>
                <p className="text-xs text-purple-400 font-semibold">{prog.provider}</p>

                <div className="flex flex-wrap gap-2 text-[11px] text-slate-300">
                  <span className="flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    <Clock className="w-3 h-3 text-purple-400" />
                    {prog.duration}
                  </span>
                  <span className="flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    <Users className="w-3 h-3 text-cyan-400" />
                    {prog.enrolledCount} Enrolled
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {prog.description}
                </p>

                {/* Covered Skills */}
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Target Skills:</span>
                  <div className="flex flex-wrap gap-1">
                    {prog.skillsCovered.map((s, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-900 text-slate-300 border border-slate-800">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => handleEnrollClick(prog.id)}
                  disabled={isEnrolled}
                  className={`w-full py-2.5 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-1.5 ${
                    isEnrolled
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
                  }`}
                >
                  {isEnrolled ? (
                    <>
                      <CheckCircle className="w-4 h-4" /> Enrolled Successfully
                    </>
                  ) : (
                    <>
                      <span>Enroll in Program</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
