import React from 'react';
import { X, Printer, Download, ShieldCheck, Activity } from 'lucide-react';

export default function HealthReportModal({ diagnosisResult, vitals, patientData, onClose }) {
  if (!diagnosisResult || !diagnosisResult.primaryDiagnosis) return null;

  const { primaryDiagnosis, differentialDiagnoses = [], analysisId } = diagnosisResult;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div class="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div class="glass-panel w-full max-w-3xl p-8 space-y-6 border border-cyan-500/40 relative text-slate-100 bg-slate-900 shadow-2xl my-8">
        
        {/* Header Bar */}
        <div class="flex items-center justify-between border-b border-slate-800 pb-4 no-print">
          <div class="flex items-center gap-2">
            <Activity class="w-5 h-5 text-cyan-400" />
            <h3 class="text-base font-extrabold text-white">MediPulse AI Official Clinical Report</h3>
          </div>
          <div class="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              class="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 transition flex items-center gap-1.5"
            >
              <Printer class="w-4 h-4" /> Print / Save PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              class="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X class="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Document Body */}
        <div class="space-y-6 font-sans">
          
          {/* Document Header */}
          <div class="flex justify-between items-start border-b border-slate-700 pb-4">
            <div>
              <h1 class="text-2xl font-black text-white tracking-tight">MediPulse <span class="text-cyan-400">AI</span> Clinical Report</h1>
              <p class="text-xs text-slate-400">Next-Generation Diagnostic Decision Support</p>
            </div>
            <div class="text-right text-xs text-slate-400 space-y-0.5 font-mono">
              <p>Report ID: <strong class="text-cyan-400">{analysisId}</strong></p>
              <p>Date: <strong>{new Date().toLocaleDateString()}</strong></p>
              <p>Status: <strong class="text-emerald-400">Verified AI Output</strong></p>
            </div>
          </div>

          {/* Patient Demographics & Vitals Table */}
          <div class="grid grid-cols-2 gap-4 bg-slate-950/80 p-4 rounded-xl border border-slate-800 text-xs">
            <div class="space-y-1">
              <h4 class="font-bold text-cyan-400 uppercase">Patient Information</h4>
              <p>Age: <strong class="text-white">{patientData.age} Years</strong></p>
              <p>Sex: <strong class="text-white">{patientData.gender}</strong></p>
              <p>Triage Status: <strong class="text-amber-400">{primaryDiagnosis.urgency}</strong></p>
            </div>
            <div class="space-y-1 font-mono">
              <h4 class="font-bold text-cyan-400 uppercase font-sans">Telemetry Vitals</h4>
              <p>Heart Rate: <strong>{vitals.heartRate} BPM</strong> | SpO2: <strong>{vitals.spo2}%</strong></p>
              <p>Blood Pressure: <strong>{vitals.bpSystolic}/{vitals.bpDiastolic} mmHg</strong></p>
              <p>Temperature: <strong>{vitals.temp} °F</strong></p>
            </div>
          </div>

          {/* Primary Condition Section */}
          <div class="space-y-2">
            <div class="flex items-center justify-between border-b border-slate-800 pb-1">
              <h3 class="text-sm font-bold uppercase text-slate-400">Primary AI Diagnosis Result</h3>
              <span class="text-xs font-bold text-cyan-400">Match Confidence: {primaryDiagnosis.confidence}%</span>
            </div>
            <div class="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-2">
              <div class="flex justify-between items-center">
                <h2 class="text-xl font-extrabold text-white">{primaryDiagnosis.name}</h2>
                <span class="px-2.5 py-1 text-xs font-mono font-bold rounded bg-cyan-500/20 text-cyan-300">
                  ICD-10: {primaryDiagnosis.icd10}
                </span>
              </div>
              <p class="text-xs text-slate-300 leading-relaxed">{primaryDiagnosis.summary}</p>
            </div>
          </div>

          {/* Protocol & Recommendations */}
          <div class="space-y-2">
            <h4 class="text-xs font-bold uppercase text-emerald-400">Clinical Protocols & Action Steps</h4>
            <ul class="space-y-1 text-xs text-slate-300 list-disc pl-5">
              {primaryDiagnosis.recommendations?.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
          </div>

          {/* Differential Diagnosis Table */}
          <div class="space-y-2">
            <h4 class="text-xs font-bold uppercase text-slate-400">Differential Diagnoses</h4>
            <div class="grid grid-cols-3 gap-2 text-xs">
              {differentialDiagnoses.map((diff) => (
                <div key={diff.id} class="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <p class="font-bold text-white truncate">{diff.name}</p>
                  <p class="text-[10px] text-slate-400">ICD: {diff.icd10} | {diff.confidence}% Match</p>
                </div>
              ))}
            </div>
          </div>

          {/* Sign-off Footer */}
          <div class="pt-6 border-t border-slate-800 flex justify-between items-end text-[10px] text-slate-400">
            <div class="space-y-1">
              <p class="flex items-center gap-1 text-emerald-400 font-bold">
                <ShieldCheck class="w-4 h-4" /> MediPulse Clinical Engine v4.2 Certified
              </p>
              <p>This report is generated for physician review and clinical handoff.</p>
            </div>
            <div class="text-right border-t border-slate-700 pt-2 w-48">
              <p class="font-bold text-white">Attending Clinician Signature</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
