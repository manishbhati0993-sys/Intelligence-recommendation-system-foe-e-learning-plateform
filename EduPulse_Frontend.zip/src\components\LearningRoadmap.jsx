import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  Clock,
  BookOpen,
  FolderGit2,
  ArrowRight,
  Target,
  ExternalLink,
  Award,
  Zap
} from 'lucide-react';
import { AI_RECOMMENDED_ROADMAP } from '../data/portalData';

export default function LearningRoadmap({ roadmap = AI_RECOMMENDED_ROADMAP, setActiveTab }) {
  return (
    <div class="max-w-5xl mx-auto py-4 space-y-6">
      
      {/* Header Banner */}
      <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-3 py-0.5 text-xs font-bold rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                AI Personalized Roadmap
              </span>
              <span class="text-xs text-slate-400">• Estimated Time: {roadmap.estimatedTimeToBridge}</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-white mt-2">
              Learning Pathway: <span class="bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">{roadmap.targetRole}</span>
            </h1>
          </div>

          <div class="px-4 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
            <div class="text-[10px] uppercase font-bold text-slate-400">Current Match Score</div>
            <div class="text-2xl font-black text-cyan-400">{roadmap.overallMatch}%</div>
          </div>
        </div>

        <p class="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
          {roadmap.summary}
        </p>
      </div>

      {/* Step-by-Step Milestones Timeline */}
      <div class="space-y-6">
        <h3 class="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
          <Zap class="w-4 h-4 text-purple-400" /> Milestone Learning Phases (Bridge Detected Gaps)
        </h3>

        <div class="space-y-6 relative before:absolute before:inset-0 before:left-6 before:w-0.5 before:bg-slate-800">
          {roadmap.milestones?.map((milestone) => (
            <div
              key={milestone.step}
              class="relative pl-14 space-y-3"
            >
              {/* Step Number Circle */}
              <div class={`absolute left-3.5 -translate-x-1/2 w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold text-xs ${
                milestone.status === 'In Progress'
                  ? 'bg-cyan-500 border-cyan-300 text-slate-950 shadow-lg shadow-cyan-500/30'
                  : 'bg-slate-900 border-slate-700 text-slate-400'
              }`}>
                {milestone.step}
              </div>

              {/* Milestone Card */}
              <div class="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4 hover:border-purple-500/40 transition">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span class={`px-2.5 py-0.5 text-[10px] font-bold rounded-full uppercase ${
                      milestone.status === 'In Progress' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {milestone.status}
                    </span>
                    <h4 class="text-base font-bold text-white mt-1.5">{milestone.skill}</h4>
                  </div>

                  <div class="flex items-center gap-2 text-xs text-slate-400">
                    <span class="px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 font-semibold text-[10px] border border-rose-500/20">
                      {milestone.gapSeverity}
                    </span>
                    <span class="flex items-center gap-1 font-mono text-cyan-300">
                      <Clock class="w-3.5 h-3.5" /> {milestone.estimatedHours}
                    </span>
                  </div>
                </div>

                <p class="text-xs text-slate-300 leading-relaxed">
                  {milestone.description}
                </p>

                {/* Recommended Courses Grid */}
                <div class="space-y-2 pt-2 border-t border-slate-800/80">
                  <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                    <BookOpen class="w-3.5 h-3.5 text-purple-400" /> Curated Industry Certification Modules:
                  </div>

                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {milestone.courses?.map((crs, cIdx) => (
                      <div key={cIdx} class="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3">
                        <div>
                          <div class="text-xs font-semibold text-slate-200">{crs.name}</div>
                          <div class="text-[10px] text-slate-400">{crs.provider} • {crs.duration}</div>
                        </div>
                        <span class="text-[10px] font-bold text-amber-400 shrink-0">★ {crs.rating}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Hands-on Project Deliverable */}
                <div class="p-3.5 rounded-xl bg-purple-950/20 border border-purple-500/30 flex items-center justify-between gap-3">
                  <div class="flex items-center gap-2.5">
                    <FolderGit2 class="w-4 h-4 text-purple-400 shrink-0" />
                    <div>
                      <div class="text-[10px] uppercase font-bold text-purple-300">Hands-on Portfolio Project:</div>
                      <div class="text-xs font-bold text-white">{milestone.project}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => alert(`Starting repository template for: ${milestone.project}`)}
                    class="px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-[11px] transition shrink-0"
                  >
                    Start Project
                  </button>
                </div>

              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
