import React, { useState } from 'react';
import {
  Sparkles,
  Flame,
  Award,
  BookOpen,
  Clock,
  TrendingUp,
  ArrowRight,
  BrainCircuit,
  Play,
  CheckCircle2,
  ChevronRight,
  Zap,
  Target,
  Layers,
  Video,
  FileQuestion,
  Code2,
  Compass,
  AlertTriangle
} from 'lucide-react';
import CourseCard from '../components/CourseCard';
import ProgressBar from '../components/ProgressBar';
import SkillRadarChart from '../components/SkillRadarChart';
import AdaptiveLearningPath from '../components/AdaptiveLearningPath';
import ExplainableAiModal from '../components/ExplainableAiModal';
import {
  coursesData,
  careerRolesData,
  multiModalRecommendationsData,
} from '../data/mockData';

export default function StudentDashboard({
  user,
  onNavigate,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  recommendedCourses = [],
  isLoadingRecommendations = false,
  onShowToast,
}) {
  const [activeTab, setActiveTab] = useState('courses'); // 'courses', 'lessons', 'videos', 'quizzes', 'projects'
  const [selectedCourseForExplanation, setSelectedCourseForExplanation] = useState(null);

  // Active enrolled courses with full metadata
  const activeEnrolledList = (user.enrolledCourses || [])
    .map((enc) => {
      const fullCourse = coursesData.find((c) => c.id === enc.courseId);
      return {
        ...fullCourse,
        ...enc,
      };
    })
    .filter((c) => Boolean(c.title));

  // Primary course currently being studied (Prompt Section 6: Continue Learning)
  const currentStudyingCourse = activeEnrolledList[0] || {
    id: 'c13',
    title: 'Relational Database Design, SQL & Query Optimization',
    category: 'Data Engineering & Big Data',
    thumbnail: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=800&auto=format&fit=crop&q=80',
    progress: 25,
    nextLesson: 'Lesson 1.3: Multi-Table Joins & Aggregations',
    lastAccessed: 'Yesterday',
  };

  // Top recommendations (excluding completed)
  const topRecommendations = (recommendedCourses.length > 0 ? recommendedCourses : coursesData)
    .filter((c) => !user.completedCourseIds?.includes(c.id))
    .slice(0, 6);

  // Active Role
  const activeRole = careerRolesData.find((r) => r.name === user.targetRole) || careerRolesData[0];

  const handleOpenWhyThis = (course) => {
    setSelectedCourseForExplanation(course);
  };

  const handleFeedbackGiven = (courseId, type) => {
    onShowToast?.({
      type: 'ai',
      title: 'Recommendation Adapted',
      message: `Recorded "${type}" feedback for this recommendation. Future suggestions calibrated.`,
    });
  };

  return (
    <div className="space-y-8 pb-16">
      {/* 1. Welcome Section (Prompt Section 6: "Good morning, Alex 👋", "Your personalized learning journey is ready.") */}
      <div className="relative rounded-3xl bg-gradient-to-r from-indigo-950/90 via-slate-900 to-slate-900 border border-indigo-500/30 p-6 sm:p-8 overflow-hidden shadow-2xl">
        {/* Glow Effects */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400 animate-pulse" />
                <span>{user.streakDays || 14}-Day Streak!</span>
              </span>
              <span className="text-xs text-slate-400 font-medium">Consistent daily habit</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">
              Good morning, <span className="text-indigo-400">{user.name || 'Alex'}</span> 👋
            </h1>

            <p className="text-sm font-semibold text-slate-200">
              Your personalized learning journey is ready.
            </p>

            <p className="text-xs text-slate-400 leading-relaxed">
              Target Goal: <strong className="text-indigo-300 font-semibold">{user.targetRole || 'Become a Data Scientist'}</strong>.
              Your recommendation engine analyzed your recent activity (completed Python Fundamentals, 91% Python Quiz) to sequence your next milestones.
            </p>

            {/* AI Actionable Tip Pill */}
            <div className="pt-2 flex items-center gap-2 text-xs font-medium text-cyan-300">
              <div className="p-1 rounded-lg bg-cyan-500/20 text-cyan-300">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <span>
                <strong>Next Priority:</strong> Reinforce <em>Statistics Foundations</em> to bridge your 61% baseline before Machine Learning.
              </span>
            </div>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="flex flex-row sm:flex-col gap-3 flex-shrink-0">
            <button
              onClick={() => onNavigate('neural-universe')}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 hover:scale-105 active:scale-95"
            >
              <Layers className="w-4 h-4 text-cyan-300" />
              <span>3D Universe</span>
            </button>
            <button
              onClick={() => onNavigate('recommendations')}
              className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Recommendations</span>
            </button>
            <button
              onClick={() => onNavigate('admin')}
              className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center justify-center gap-2"
            >
              <Compass className="w-4 h-4 text-teal-400" />
              <span>Admin Engine</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid (Current Streak, Learning Hours, Courses Completed, Skills Gained, Overall Progress) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Metric 1: Streak */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-amber-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Current Streak</span>
            <Flame className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-100 font-mono">
            {user.streakDays || 14} <span className="text-xs text-slate-400 font-normal">days</span>
          </p>
          <span className="text-[10px] text-amber-400 font-medium block mt-1">Velocity Unbroken</span>
        </div>

        {/* Metric 2: Learning Hours */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-teal-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Learning Hours</span>
            <Clock className="w-4 h-4 text-teal-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-100 font-mono">
            {user.totalHoursLearned || 48.6}h
          </p>
          <span className="text-[10px] text-teal-400 font-medium block mt-1">+{user.hoursLearnedThisWeek || 7.5}h this week</span>
        </div>

        {/* Metric 3: Courses Completed */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-indigo-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Courses Completed</span>
            <Award className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-100 font-mono">
            {user.coursesCompletedCount || 1}
          </p>
          <span className="text-[10px] text-emerald-400 font-medium block mt-1">Python Fundamentals</span>
        </div>

        {/* Metric 4: Skills Gained */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-purple-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Skills Assessed</span>
            <BrainCircuit className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-100 font-mono">
            5 <span className="text-xs text-slate-400 font-normal">domains</span>
          </p>
          <span className="text-[10px] text-purple-400 font-medium block mt-1">Python: 82% • SQL: 74%</span>
        </div>

        {/* Metric 5: Overall Progress */}
        <div className="col-span-2 lg:col-span-1 p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-cyan-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Goal Readiness</span>
            <Target className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-100 font-mono">
            65%
          </p>
          <span className="text-[10px] text-cyan-400 font-medium block mt-1">2 Remedial Gaps Left</span>
        </div>
      </div>

      {/* 2. Continue Learning Section (Prompt Section 6) */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-400" />
              <span>Continue Learning</span>
            </h2>
            <p className="text-xs text-slate-400">Pick up right where you left off</p>
          </div>
          <span className="text-xs font-semibold text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-lg border border-indigo-500/20 self-start sm:self-auto">
            {activeEnrolledList.length} Active Courses
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeEnrolledList.slice(0, 2).map((course) => (
            <div
              key={course.id}
              className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-indigo-500/40 transition-all space-y-4 group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3.5 min-w-0">
                  <img
                    src={course.thumbnail}
                    alt={course.title}
                    className="w-14 h-14 rounded-xl object-cover flex-shrink-0 border border-slate-700"
                  />
                  <div className="min-w-0">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                      {course.category}
                    </span>
                    <h3
                      onClick={() => onSelectCourse?.(course)}
                      className="font-bold text-slate-100 text-sm truncate group-hover:text-indigo-400 transition-colors cursor-pointer"
                      title={course.title}
                    >
                      {course.title}
                    </h3>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {course.currentModule || 'Module in Progress'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onSelectCourse?.(course)}
                  className="py-2 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5 flex-shrink-0 hover:scale-105 active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Resume</span>
                </button>
              </div>

              {/* Progress & Next Lesson */}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 text-[11px] truncate mr-2">
                    Next: <strong className="text-slate-200">{course.nextLesson || 'Next lesson ready'}</strong>
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">{course.progress}%</span>
                </div>
                <ProgressBar progress={course.progress} variant="emerald" size="sm" showPercentage={false} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Adaptive Learning Path (Prompt Section 8) */}
      <AdaptiveLearningPath
        user={user}
        onSelectCourse={onSelectCourse}
        onEnroll={onEnroll}
      />

      {/* 4. AI Recommendations Carousel / Grid (Prompt Section 6) */}
      <div className="space-y-6 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <Sparkles className="w-4 h-4" />
              </span>
              <h2 className="text-xl font-extrabold text-white">Recommended for You</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                6-Signal AI Matched
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Personalized suggestions tailored to your <strong className="text-slate-200">{user.targetRole || 'Data Scientist'}</strong> path, prerequisite diagnostic scores, and weekly activity.
            </p>
          </div>

          {/* Navigation Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-2xl text-xs overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveTab('courses')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'courses' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Courses
            </button>
            <button
              onClick={() => setActiveTab('lessons')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'lessons' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Lessons & Videos
            </button>
            <button
              onClick={() => setActiveTab('quizzes')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'quizzes' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Quizzes & Labs
            </button>
            <button
              onClick={() => setActiveTab('projects')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'projects' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Projects & Practice
            </button>
          </div>
        </div>

        {/* Tab 1: Course Cards Grid */}
        {activeTab === 'courses' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topRecommendations.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                onSelectCourse={onSelectCourse}
                onToggleBookmark={onToggleBookmark}
                onEnroll={onEnroll}
                onWhyThis={handleOpenWhyThis}
                isBookmarked={user.bookmarkedCourseIds?.includes(course.id)}
                isEnrolled={user.enrolledCourses?.some((enc) => enc.courseId === course.id)}
                enrolledProgress={
                  user.enrolledCourses?.find((enc) => enc.courseId === course.id)?.progress || 0
                }
                showAiMatch={true}
              />
            ))}
          </div>
        )}

        {/* Tab 2: Recommended Lessons & Videos */}
        {activeTab === 'lessons' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {multiModalRecommendationsData.lessons.map((les) => (
              <div
                key={les.id}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 transition-all space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="px-2.5 py-0.5 rounded-full font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 text-[10px]">
                      {les.type}
                    </span>
                    <span className="font-mono font-bold text-emerald-400">{les.matchScore}% Match</span>
                  </div>

                  <h3 className="font-bold text-white text-sm leading-snug">
                    {les.title}
                  </h3>
                  <p className="text-xs text-slate-400">
                    From: {les.courseTitle} • {les.duration}
                  </p>
                  <p className="text-[11px] text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    🎯 {les.matchReason}
                  </p>
                </div>

                <button
                  onClick={() => onShowToast?.({
                    type: 'success',
                    title: 'Lesson Loaded',
                    message: `Streaming "${les.title}". Interactive environment ready.`,
                  })}
                  className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Lesson</span>
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: Recommended Quizzes & Drills */}
        {activeTab === 'quizzes' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {multiModalRecommendationsData.quizzes.map((quiz) => (
              <div
                key={quiz.id}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 transition-all space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 text-[10px]">
                      {quiz.urgency}
                    </span>
                    <span className="font-mono text-xs text-slate-400">{quiz.estimatedTime}</span>
                  </div>

                  <h3 className="font-bold text-white text-sm leading-snug">
                    {quiz.title}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {quiz.questionsCount} Multiple-Choice & Coding Questions
                  </p>
                  <p className="text-[11px] text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    💡 {quiz.matchReason}
                  </p>
                </div>

                <button
                  onClick={() => onShowToast?.({
                    type: 'ai',
                    title: 'Diagnostic Quiz Initiated',
                    message: `Starting "${quiz.title}". Re-calibrates your skill score upon completion.`,
                  })}
                  className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <FileQuestion className="w-3.5 h-3.5" />
                  <span>Take Assessment</span>
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Tab 4: Projects & Practice Exercises */}
        {activeTab === 'projects' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {multiModalRecommendationsData.projects.map((proj) => (
              <div
                key={proj.id}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-purple-500/40 transition-all space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="px-2.5 py-0.5 rounded-full font-bold bg-purple-500/10 text-purple-300 border border-purple-500/20 text-[10px]">
                      Portfolio Project
                    </span>
                    <span className="font-mono font-bold text-emerald-400">{proj.matchScore}% Match</span>
                  </div>

                  <h3 className="font-bold text-white text-sm leading-snug">
                    {proj.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {proj.description}
                  </p>
                  <div className="flex flex-wrap gap-1 pt-1">
                    {proj.skills.map((s, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-950 text-indigo-300 border border-slate-800">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => onShowToast?.({
                    type: 'success',
                    title: 'Workspace Provisioned',
                    message: `Jupyter Notebook & dataset loaded for "${proj.title}".`,
                  })}
                  className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Launch Project Workspace</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 5. Explainable AI Modal ("Why this?") */}
      <ExplainableAiModal
        course={selectedCourseForExplanation}
        user={user}
        isOpen={Boolean(selectedCourseForExplanation)}
        onClose={() => setSelectedCourseForExplanation(null)}
        onEnroll={onEnroll}
        onToggleBookmark={onToggleBookmark}
        onFeedbackGiven={handleFeedbackGiven}
      />
    </div>
  );
}
