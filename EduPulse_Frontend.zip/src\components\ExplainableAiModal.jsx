import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Target,
  Brain,
  TrendingUp,
  CheckCircle2,
  ThumbsUp,
  ThumbsDown,
  Bookmark,
  Play,
  ArrowRight,
  Info,
  Clock,
  Layers,
  Award,
  AlertCircle
} from 'lucide-react';
import { recordRecommendationFeedback } from '../services/recommendationEngine';

export default function ExplainableAiModal({
  course,
  user,
  isOpen,
  onClose,
  onEnroll,
  onToggleBookmark,
  onFeedbackGiven,
}) {
  const [feedbackState, setFeedbackState] = useState(course?.userFeedback || null);
  const [feedbackToast, setFeedbackToast] = useState(null);

  if (!isOpen || !course) return null;

  const aiMetrics = course.aiMetrics || {};
  const factors = aiMetrics.factors || course.factors || {
    interestMatch: 92,
    skillMatch: 88,
    performanceRelevance: 95,
    learningGoalMatch: 98,
    difficultyFit: 90,
    behavioralRelevance: 85,
  };
  const weights = aiMetrics.weightsUsed || {
    interestMatch: 0.25,
    skillMatch: 0.20,
    performanceRelevance: 0.20,
    learningGoalMatch: 0.15,
    difficultyFit: 0.10,
    behavioralRelevance: 0.10,
  };

  const isBookmarked = user?.bookmarkedCourseIds?.includes(course.id);
  const isEnrolled = user?.enrolledCourses?.some((e) => e.courseId === course.id);

  const handleFeedback = (type, label) => {
    setFeedbackState(type);
    recordRecommendationFeedback(course.id, type);
    setFeedbackToast(`Feedback recorded: "${label}". Recommendation weights calibrated.`);
    setTimeout(() => setFeedbackToast(null), 3500);
    onFeedbackGiven?.(course.id, type);
  };

  const factorList = [
    {
      key: 'interestMatch',
      name: 'Interest Match',
      weight: `${Math.round(weights.interestMatch * 100)}%`,
      score: factors.interestMatch,
      color: 'bg-emerald-500',
      description: 'Matches your topics, tags, and search keywords',
    },
    {
      key: 'skillMatch',
      name: 'Skill Deficit Match',
      weight: `${Math.round(weights.skillMatch * 100)}%`,
      score: factors.skillMatch,
      color: 'bg-cyan-500',
      description: 'Directly addresses identified competency gaps',
    },
    {
      key: 'performanceRelevance',
      name: 'Performance Relevance',
      weight: `${Math.round(weights.performanceRelevance * 100)}%`,
      score: factors.performanceRelevance,
      color: 'bg-indigo-500',
      description: 'Calibrated to your quiz scores and prerequisite test results',
    },
    {
      key: 'learningGoalMatch',
      name: 'Learning Goal Match',
      weight: `${Math.round(weights.learningGoalMatch * 100)}%`,
      score: factors.learningGoalMatch,
      color: 'bg-purple-500',
      description: `Aligned to your milestone path: ${user?.targetRole || user?.goal || 'Data Science'}`,
    },
    {
      key: 'difficultyFit',
      name: 'Difficulty Fit',
      weight: `${Math.round(weights.difficultyFit * 100)}%`,
      score: factors.difficultyFit,
      color: 'bg-amber-500',
      description: `Matches your current readiness (${course.level} level)`,
    },
    {
      key: 'behavioralRelevance',
      name: 'Behavioral Relevance',
      weight: `${Math.round(weights.behavioralRelevance * 100)}%`,
      score: factors.behavioralRelevance,
      color: 'bg-rose-500',
      description: 'Reflects watch completion, bookmarks, and study pace',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-indigo-500/30 rounded-3xl shadow-2xl overflow-hidden my-8 text-slate-100 flex flex-col">
        {/* Top Header Glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-0 left-0 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-start justify-between relative z-10">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Explainable AI Recommendation Telemetry</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              Why this course?
            </h2>
            <p className="text-xs text-slate-400">
              Transparent breakdown of the signals and mathematical weights behind this recommendation
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto max-h-[70vh] no-scrollbar relative z-10">
          {/* Target Course Summary Card */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={course.thumbnail}
                alt={course.title}
                className="w-14 h-14 rounded-xl object-cover border border-slate-700 flex-shrink-0"
              />
              <div className="min-w-0">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 block">
                  {course.category} • {course.level}
                </span>
                <h3 className="font-bold text-white text-sm sm:text-base truncate">
                  {course.title}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Instructor: {course.instructor?.name} • {course.duration}
                </p>
              </div>
            </div>

            <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800 flex-shrink-0">
              <span className="text-[10px] uppercase font-bold text-slate-400">Recommendation Fit</span>
              <div className="flex items-center gap-1 text-emerald-400 font-mono font-extrabold text-xl sm:text-2xl">
                <span>{course.matchPercentage || 95}%</span>
              </div>
            </div>
          </div>

          {/* Primary Explainable AI Bullets (Prompt Section 7) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/20 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-2">
              <Target className="w-4 h-4 text-emerald-400" />
              <span>Primary Decision Rationale</span>
            </h4>

            <div className="space-y-2 text-xs sm:text-sm text-slate-200">
              {(course.explanationBulletPoints || [
                `✓ Matches your selected goal: ${user?.targetRole || 'Become a Data Scientist'}`,
                `✓ Builds on Python skills you already learned (${user?.skills?.Python || 82}% mastery)`,
                `✓ Your recent quiz results (91% in Python Quiz) show you are ready for this topic`,
                `✓ Statistics is one of your weaker prerequisite skills (${user?.skills?.Statistics || 61}%) - foundational review`,
                `✓ Similar learners often study this topic next`,
              ]).map((bullet, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <span className="text-emerald-400 font-bold mt-0.5 flex-shrink-0">✓</span>
                  <span className="text-slate-300 leading-relaxed">{bullet.replace(/^✓\s*/, '')}</span>
                </div>
              ))}
            </div>

            {aiMetrics.dynamicReason && (
              <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-400 italic">
                "{aiMetrics.dynamicReason}"
              </div>
            )}
          </div>

          {/* 6-Factor Mathematical Decomposition (Prompt Section 5) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Brain className="w-4 h-4 text-purple-400" />
                <span>6-Factor Score Decomposition</span>
              </h4>
              <span className="text-[10px] text-slate-500 font-mono">
                Formula: ∑ (Factor Score × Configured Weight)
              </span>
            </div>

            <div className="space-y-3">
              {factorList.map((factor) => (
                <div
                  key={factor.key}
                  className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-200">{factor.name}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-400 rounded">
                        Weight: {factor.weight}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-slate-100">{factor.score}/100</span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${factor.color} transition-all duration-700`}
                      style={{ width: `${factor.score}%` }}
                    />
                  </div>

                  <p className="text-[11px] text-slate-400">{factor.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Feedback & Adaptation Section (Prompt Section 12) */}
          <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Was this recommendation helpful?</span>
              </h4>
              <span className="text-[10px] text-slate-500">Adapts your AI model in real time</span>
            </div>

            {feedbackToast && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{feedbackToast}</span>
              </div>
            )}

            <div className="flex flex-wrap gap-2 text-xs">
              <button
                onClick={() => handleFeedback('useful', 'Useful')}
                className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all ${
                  feedbackState === 'useful'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                }`}
              >
                <ThumbsUp className="w-3.5 h-3.5" />
                <span>Useful</span>
              </button>

              <button
                onClick={() => handleFeedback('not_useful', 'Not useful')}
                className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all ${
                  feedbackState === 'not_useful'
                    ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                }`}
              >
                <ThumbsDown className="w-3.5 h-3.5" />
                <span>Not useful</span>
              </button>

              <button
                onClick={() => handleFeedback('not_interested', 'Not interested')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  feedbackState === 'not_interested'
                    ? 'bg-amber-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                Not interested
              </button>

              <button
                onClick={() => handleFeedback('already_know', 'Already know this')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  feedbackState === 'already_know'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                Already know this
              </button>

              <button
                onClick={() => handleFeedback('too_difficult', 'Too difficult')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  feedbackState === 'too_difficult'
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                Too difficult
              </button>

              <button
                onClick={() => handleFeedback('too_easy', 'Too easy')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  feedbackState === 'too_easy'
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                Too easy
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-5 sm:p-6 border-t border-slate-800 bg-slate-900/80 flex flex-col sm:flex-row items-center justify-between gap-3 relative z-10">
          <button
            onClick={() => onToggleBookmark?.(course.id)}
            className={`w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              isBookmarked
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            <span>{isBookmarked ? 'Bookmarked' : 'Save for Later'}</span>
          </button>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-1/2 sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
            >
              Close
            </button>

            <button
              onClick={() => {
                onEnroll?.(course.id);
                onClose();
              }}
              className="w-1/2 sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-1.5 hover:scale-105 active:scale-95"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isEnrolled ? 'Resume Course' : 'Start Course'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
