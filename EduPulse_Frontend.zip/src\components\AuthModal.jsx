import React, { useState } from 'react';
import {
  X,
  GraduationCap,
  Building2,
  ShieldAlert,
  Cpu,
  Sparkles,
  User,
  ArrowRight,
  Mail,
  Lock,
  CheckCircle2
} from 'lucide-react';
import { USER_ROLES } from '../data/portalData';

export default function AuthModal({ isOpen, onClose, onSelectPersona }) {
  if (!isOpen) return null;

  const [authMode, setAuthMode] = useState('demo'); // 'demo' | 'login' | 'signup'
  const [selectedRoleForAuth, setSelectedRoleForAuth] = useState(USER_ROLES.STUDENT);
  const [authSuccess, setAuthSuccess] = useState(false);

  const handleCustomAuth = (e) => {
    e.preventDefault();
    setAuthSuccess(true);
    setTimeout(() => {
      onSelectPersona(selectedRoleForAuth);
      setAuthSuccess(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in">
      <div className="p-6 sm:p-8 max-w-lg w-full rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 p-0.5">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Cpu className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <h2 className="text-xl font-black text-white">SkillBridge Access</h2>
              <p className="text-xs text-slate-400">Team Terminal Titan • Smart India Hackathon</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="flex p-1 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setAuthMode('demo')}
            className={`flex-1 py-2 rounded-xl transition ${
              authMode === 'demo'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ⚡ 1-Click Role Demo
          </button>
          <button
            onClick={() => setAuthMode('login')}
            className={`flex-1 py-2 rounded-xl transition ${
              authMode === 'login'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => setAuthMode('signup')}
            className={`flex-1 py-2 rounded-xl transition ${
              authMode === 'signup'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Mode A: 1-Click Demo Personas */}
        {authMode === 'demo' && (
          <div className="space-y-3">
            <p className="text-xs text-slate-300">
              Select any pre-configured stakeholder persona to immediately inspect the live portal workflows:
            </p>

            <div className="space-y-2.5">
              <button
                onClick={() => {
                  onSelectPersona(USER_ROLES.STUDENT);
                  onClose();
                }}
                className="w-full p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-left transition flex items-center gap-3.5 group"
              >
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-white group-hover:text-cyan-400 transition flex items-center gap-1.5">
                    Student: Aarav Sharma
                    <span className="px-1.5 py-0.5 text-[9px] rounded bg-cyan-500/20 text-cyan-300 font-mono">B.Tech NITK</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">Target: Java Backend Engineer • 78% Match</div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 transition" />
              </button>

              <button
                onClick={() => {
                  onSelectPersona(USER_ROLES.INDUSTRY);
                  onClose();
                }}
                className="w-full p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-blue-500/50 text-left transition flex items-center gap-3.5 group"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Building2 className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-white group-hover:text-blue-400 transition flex items-center gap-1.5">
                    Industry Recruiter: Priya Nambiar
                    <span className="px-1.5 py-0.5 text-[9px] rounded bg-blue-500/20 text-blue-300 font-mono">Infosys</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">Talent Acquisition & Candidate Shortlisting</div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 transition" />
              </button>

              <button
                onClick={() => {
                  onSelectPersona(USER_ROLES.COLLEGE);
                  onClose();
                }}
                className="w-full p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/50 text-left transition flex items-center gap-3.5 group"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-white group-hover:text-emerald-400 transition flex items-center gap-1.5">
                    College / TPO: Dr. Ramesh Sundaram
                    <span className="px-1.5 py-0.5 text-[9px] rounded bg-emerald-500/20 text-emerald-300 font-mono">NITK TPO</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">Curriculum Gap Heatmaps & MoU Management</div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-emerald-400 transition" />
              </button>

              <button
                onClick={() => {
                  onSelectPersona(USER_ROLES.ADMIN);
                  onClose();
                }}
                className="w-full p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 text-left transition flex items-center gap-3.5 group"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-white group-hover:text-amber-400 transition flex items-center gap-1.5">
                    SIH Super Admin
                    <span className="px-1.5 py-0.5 text-[9px] rounded bg-amber-500/20 text-amber-300 font-mono">Central Cell</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">National Skill Registry & Audit Logs</div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 transition" />
              </button>
            </div>
          </div>
        )}

        {/* Mode B & C: Sign In / Sign Up with Role Selection */}
        {(authMode === 'login' || authMode === 'signup') && (
          <form onSubmit={handleCustomAuth} className="space-y-4 text-xs">
            {/* Role Selection Tabs */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1.5">Select Your Stakeholder Category:</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedRoleForAuth(USER_ROLES.STUDENT)}
                  className={`p-2 rounded-xl border text-center transition ${
                    selectedRoleForAuth === USER_ROLES.STUDENT
                      ? 'bg-cyan-500/15 border-cyan-500/60 text-cyan-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Student
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRoleForAuth(USER_ROLES.INDUSTRY)}
                  className={`p-2 rounded-xl border text-center transition ${
                    selectedRoleForAuth === USER_ROLES.INDUSTRY
                      ? 'bg-blue-500/15 border-blue-500/60 text-blue-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Industry
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRoleForAuth(USER_ROLES.COLLEGE)}
                  className={`p-2 rounded-xl border text-center transition ${
                    selectedRoleForAuth === USER_ROLES.COLLEGE
                      ? 'bg-emerald-500/15 border-emerald-500/60 text-emerald-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  College / TPO
                </button>
              </div>
            </div>

            {/* Email Field */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Institutional / Work Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  placeholder={
                    selectedRoleForAuth === USER_ROLES.STUDENT
                      ? 'student@nitk.edu.in'
                      : selectedRoleForAuth === USER_ROLES.INDUSTRY
                      ? 'recruiter@infosys.com'
                      : 'tpo@college.ac.in'
                  }
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {authSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Authentication verified! Redirecting...
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-black text-xs hover:opacity-95 transition shadow-lg shadow-cyan-500/20"
            >
              {authMode === 'login' ? 'Authenticate & Enter' : 'Create Verified Account'}
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
