import React, { useState } from 'react';
import {
  X,
  User,
  Settings,
  Bell,
  Shield,
  Palette,
  CheckCircle2,
  Save,
  Key,
  Briefcase,
  GraduationCap
} from 'lucide-react';

export default function SettingsModal({ isOpen, onClose, currentUser, onUpdateUser, theme, toggleTheme }) {
  if (!isOpen) return null;

  const [activeSubTab, setActiveSubTab] = useState('profile');
  const [formData, setFormData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    targetRole: currentUser?.targetRole || 'Full Stack / Backend Engineer',
    bio: currentUser?.bio || '',
    college: currentUser?.college || '',
    department: currentUser?.department || '',
    location: currentUser?.location || 'Bangalore, Karnataka',
    emailAlerts: true,
    matchingAlerts: true,
    weeklyDigest: false,
    autoShortlistNotification: true
  });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    if (onUpdateUser) {
      onUpdateUser({
        ...currentUser,
        ...formData
      });
    }
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Platform Settings & Profile</h3>
              <p className="text-xs text-slate-400">Manage your SkillBridge preferences & credentials</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-slate-800 bg-slate-950/30 gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveSubTab('profile')}
            className={`py-3 flex items-center gap-1.5 border-b-2 transition ${
              activeSubTab === 'profile'
                ? 'border-cyan-400 text-cyan-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" /> Profile Info
          </button>

          <button
            onClick={() => setActiveSubTab('notifications')}
            className={`py-3 flex items-center gap-1.5 border-b-2 transition ${
              activeSubTab === 'notifications'
                ? 'border-cyan-400 text-cyan-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bell className="w-3.5 h-3.5" /> Notifications
          </button>

          <button
            onClick={() => setActiveSubTab('appearance')}
            className={`py-3 flex items-center gap-1.5 border-b-2 transition ${
              activeSubTab === 'appearance'
                ? 'border-cyan-400 text-cyan-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" /> Theme & Appearance
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSave} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
          {activeSubTab === 'profile' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Full Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Registered Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Target Role / Career Aspiration</label>
                <input
                  type="text"
                  value={formData.targetRole}
                  onChange={(e) => setFormData({ ...formData, targetRole: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 transition"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">College / Institution</label>
                  <input
                    type="text"
                    value={formData.college}
                    onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Department</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Professional Bio</label>
                <textarea
                  rows="3"
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 transition"
                />
              </div>
            </div>
          )}

          {activeSubTab === 'notifications' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <div className="font-bold text-white">Smart Match Alerts</div>
                  <div className="text-[11px] text-slate-400">Get notified when a new opening matches &gt;80% with your skill profile</div>
                </div>
                <input
                  type="checkbox"
                  checked={formData.matchingAlerts}
                  onChange={(e) => setFormData({ ...formData, matchingAlerts: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500 accent-cyan-500"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <div className="font-bold text-white">Recruiter Interview Invites</div>
                  <div className="text-[11px] text-slate-400">Instant email & in-app alerts when an interview slot is scheduled</div>
                </div>
                <input
                  type="checkbox"
                  checked={formData.autoShortlistNotification}
                  onChange={(e) => setFormData({ ...formData, autoShortlistNotification: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500 accent-cyan-500"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <div className="font-bold text-white">Weekly Skill Gap Progress Digest</div>
                  <div className="text-[11px] text-slate-400">Receive weekly curated courses and roadmap milestones summary</div>
                </div>
                <input
                  type="checkbox"
                  checked={formData.weeklyDigest}
                  onChange={(e) => setFormData({ ...formData, weeklyDigest: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500 accent-cyan-500"
                />
              </div>
            </div>
          )}

          {activeSubTab === 'appearance' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">Interface Theme</div>
                  <div className="text-[11px] text-slate-400">Current mode: {theme === 'dark' ? 'Dark Mode (Default)' : 'Light Mode'}</div>
                </div>
                <button
                  type="button"
                  onClick={toggleTheme}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition"
                >
                  Switch to {theme === 'dark' ? 'Light Theme' : 'Dark Theme'}
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="font-bold text-white mb-1">Color Scheme</div>
                <div className="text-[11px] text-slate-400 mb-3">Primary system accents for SIH presentation</div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="w-3 h-3 rounded-full bg-[#0A2540] border border-white/20"></span>
                    <span className="text-[11px] text-slate-300">Deep Blue</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="w-3 h-3 rounded-full bg-[#3B82F6]"></span>
                    <span className="text-[11px] text-slate-300">Electric Blue</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="w-3 h-3 rounded-full bg-[#10B981]"></span>
                    <span className="text-[11px] text-slate-300">Accent Teal</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="w-3 h-3 rounded-full bg-[#F59E0B]"></span>
                    <span className="text-[11px] text-slate-300">Gold Highlight</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
            {savedSuccess ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Preferences Saved!
              </span>
            ) : (
              <span className="text-slate-500 text-[11px]">Changes apply instantly</span>
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition font-medium"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-bold hover:opacity-95 transition shadow-lg shadow-cyan-500/20 flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" /> Save Changes
              </button>
            </div>
          </div>
        </form>

      </div>
    </div>
  );
}
