import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  X,
  MessageSquare,
  ChevronDown,
  User,
  Zap,
  Target,
  BookOpen,
  ArrowRight,
  TrendingUp,
  Brain
} from 'lucide-react';

export default function AILearningAssistant({
  user,
  isOpen,
  onToggle,
  onSelectCourse,
  onNavigate,
}) {
  const [messages, setMessages] = useState([
    {
      id: 'msg_init',
      sender: 'ai',
      text: `Hello ${user?.name || 'Alex'}! 👋 I am your **EduPulse AI Learning Advisor**. 

I have analyzed your real-time learning data:
- **Target Goal**: ${user?.targetRole || user?.goal || 'Become a Data Scientist'}
- **Current Strengths**: Python (${user?.skills?.Python || 82}%), SQL (${user?.skills?.SQL || 74}%)
- **Prerequisite Focus**: Statistics (${user?.skills?.Statistics || 61}%), Machine Learning (${user?.skills?.['Machine Learning'] || 42}%)
- **Recent Milestone**: 91% on Python Fundamentals Quiz!

How can I accelerate your learning trajectory today?`,
      timestamp: 'Just now',
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const promptChips = [
    'What should I learn next?',
    'Why are you recommending this course?',
    "I'm weak in SQL. What should I study?",
    'Create a 30-day learning plan for me.',
    'Which skills am I missing for becoming a data scientist?',
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Context-aware AI response generator using student actual learning data
  const generateAssistantResponse = (query) => {
    const q = query.toLowerCase();
    const targetGoal = user?.targetRole || user?.goal || 'Become a Data Scientist';
    const pyScore = user?.skills?.Python || 82;
    const statScore = user?.skills?.Statistics || 61;
    const sqlScore = user?.skills?.SQL || 74;
    const mlScore = user?.skills?.['Machine Learning'] || 42;
    const vizScore = user?.skills?.['Data Visualization'] || 68;

    if (q.includes('learn next') || q.includes('what should i study next')) {
      return {
        text: `Based on your diagnostic profile, your **highest priority next step is [Practical Statistics & Probability for Data Science]**.

Here is why:
1. You scored **91% on Python Fundamentals** and hold an **${pyScore}% Python mastery**, so your programming foundation is solid.
2. However, your **Statistics score is currently ${statScore}%**, which is a prerequisite for Machine Learning algorithms (where your current baseline is ${mlScore}%).
3. Closing your Statistics gap to ≥80% will unlock advanced regression diagnostics, hypothesis testing, and A/B experimentation.

Would you like me to open the Statistics course or queue its Module 1 diagnostic quiz?`,
        suggestedAction: { label: 'Open Statistics Course', courseId: 'c_stats' },
      };
    }

    if (q.includes('why are you recommending') || q.includes('why this course')) {
      return {
        text: `Our recommendation engine evaluates **6 transparent signals**:
- **Interest Match (25%)**: Cross-referenced with your search history (e.g. *Hypothesis testing*, *Pandas*)
- **Skill Match (20%)**: Directly targets your biggest gap (${statScore}% in Statistics vs 90% benchmark)
- **Performance Relevance (20%)**: Recommends foundational review because prerequisite diagnostic was <70%
- **Goal Match (15%)**: 100% aligned with your **${targetGoal}** trajectory
- **Difficulty Fit (10%)**: Beginner/Intermediate balance
- **Behavioral Relevance (10%)**: Matches your 7.5 weekly study hours pace

It never suggests courses at random—each recommendation is tied to concrete competencies you need next!`,
      };
    }

    if (q.includes('weak in sql') || q.includes('sql')) {
      return {
        text: `You currently have a solid **${sqlScore}% in SQL**, but to reach senior Data Science standards (90%+), you should target:

1. **Complex Window Functions**: \`ROW_NUMBER()\`, \`DENSE_RANK()\`, and \`LAG/LEAD\` for time-series analysis.
2. **Recursive Common Table Expressions (CTEs)**: For hierarchical data and graph traversals.
3. **Query Optimization**: Understanding \`EXPLAIN ANALYZE\` and index selection.

Recommended course: **[Relational Database Design, SQL & Query Optimization]** (You are already 25% complete—resume Module 1!).`,
        suggestedAction: { label: 'Resume SQL Course', courseId: 'c13' },
      };
    }

    if (q.includes('30-day') || q.includes('learning plan')) {
      return {
        text: `Here is your customized **30-Day Data Science Acceleration Plan**:

- **Week 1 (Days 1–7): Statistics Prerequisite Remediation**
  - Complete *Probability Distributions & Central Limit Theorem*
  - Lab: Simulating coin flips in NumPy & SciPy
  - Target: Elevate Statistics from ${statScore}% → 75%

- **Week 2 (Days 8–14): Intermediate SQL & Analytical Queries**
  - Finish Module 2 of *Relational Database Design* (Window functions & recursive CTEs)
  - Target: Elevate SQL from ${sqlScore}% → 85%

- **Week 3 (Days 15–21): Supervised Machine Learning**
  - Start *Applied Machine Learning: From Regression to Ensembles*
  - Build regularized Ridge/Lasso models on housing data

- **Week 4 (Days 22–30): Interactive Capstone Project**
  - Build an end-to-end A/B Testing Customer Churn dashboard with Plotly
  - Earn Verified Data Science Specialization Credential!`,
      };
    }

    if (q.includes('missing') || q.includes('skills am i missing')) {
      return {
        text: `Comparing your profile against the **${targetGoal}** benchmark (target 90%+ across core domains):

1. **Machine Learning (${mlScore}% vs 85% Target)**: Missing 43% gap in decision tree ensembles, gradient boosting, and SHAP explainability.
2. **Statistics (${statScore}% vs 90% Target)**: Missing 29% gap in hypothesis testing and A/B test sample sizing.
3. **Data Visualization (${vizScore}% vs 85% Target)**: Missing 17% gap in interactive Plotly/Dash storytelling.
4. **SQL (${sqlScore}% vs 90% Target)**: Missing 16% gap in window functions and database indexing.
5. **Python (${pyScore}% vs 95% Target)**: Near target! (Only 13% gap remaining).

Focusing on **Statistics + Machine Learning** will yield the highest return for your profile right now.`,
      };
    }

    // Default response
    return {
      text: `Great question regarding **${query}**! 

Given your active goal of **${targetGoal}**, I recommend pairing conceptual theory with hands-on coding exercises. Your current streak is **${user?.streakDays || 14} days**—completing today's recommended module will keep that velocity intact!

Can I help you review your learning path, test your skills with a quick quiz, or inspect why a specific course was recommended?`,
    };
  };

  const handleSend = (textToSend) => {
    const text = (textToSend || inputValue).trim();
    if (!text) return;

    const userMsg = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    setTimeout(() => {
      const responseData = generateAssistantResponse(text);
      const aiMsg = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: responseData.text,
        suggestedAction: responseData.suggestedAction,
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 600);
  };

  return (
    <>
      {/* Floating Launcher Button */}
      <button
        onClick={onToggle}
        className="fixed bottom-6 right-6 z-40 p-4 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-500 text-white shadow-2xl shadow-indigo-600/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2.5 font-bold text-xs"
        aria-label="Toggle AI Advisor"
      >
        <Bot className="w-5 h-5 text-cyan-300 animate-pulse" />
        <span className="hidden sm:inline">AI Learning Advisor</span>
        <span className="w-2 h-2 rounded-full bg-emerald-400" />
      </button>

      {/* Slide-over Drawer */}
      {isOpen && (
        <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[460px] bg-slate-950/95 backdrop-blur-2xl border-l border-indigo-500/20 shadow-2xl flex flex-col text-slate-100 animate-slide-left">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/20">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Bot className="w-5 h-5 text-cyan-300" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-sm text-white">AI Learning Advisor</h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Live Telemetry
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Contextual to Alex • Data Science Path</p>
              </div>
            </div>

            <button
              onClick={onToggle}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Prompt Chips Bar */}
          <div className="px-4 py-2.5 border-b border-slate-800/80 bg-slate-950/60 overflow-x-auto no-scrollbar flex items-center gap-2">
            {promptChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(chip)}
                className="px-3 py-1 rounded-full text-[11px] whitespace-nowrap bg-slate-900 hover:bg-indigo-600/30 text-slate-300 hover:text-indigo-300 border border-slate-800 hover:border-indigo-500/40 transition-all font-medium"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Chat Messages Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 no-scrollbar">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'ai' && (
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 flex-shrink-0 mt-0.5">
                    <Bot className="w-4 h-4 text-cyan-300" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed space-y-2 ${
                    msg.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-br-none shadow-md shadow-indigo-600/20'
                      : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-bl-none shadow-md'
                  }`}
                >
                  <div className="whitespace-pre-line">{msg.text}</div>

                  {msg.suggestedAction && (
                    <div className="pt-2 border-t border-slate-800 mt-2">
                      <button
                        onClick={() => {
                          onSelectCourse?.({ id: msg.suggestedAction.courseId });
                          onToggle();
                        }}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1.5 transition-all text-[11px]"
                      >
                        <span>{msg.suggestedAction.label}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <span className="text-[10px] text-slate-500 block text-right mt-1">
                    {msg.timestamp}
                  </span>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 flex-shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 flex-shrink-0">
                  <Bot className="w-4 h-4 text-cyan-300" />
                </div>
                <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                  <span>Synthesizing student learning telemetry...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Box Footer */}
          <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-900/90">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="Ask about recommendations, skill gaps, or a study plan..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isTyping}
                className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white transition-all shadow-md shadow-indigo-600/30"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
