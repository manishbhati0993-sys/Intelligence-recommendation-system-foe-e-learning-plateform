import React, { useState } from 'react';
import {
  Sparkles,
  Clock,
  BookOpen,
  Star,
  Users,
  Award,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Play,
  FileCode,
  HelpCircle,
  Bookmark,
  Share2,
  ArrowLeft,
  Target,
  BrainCircuit,
  Lock,
  Zap,
} from 'lucide-react';
import ProgressBar from '../components/ProgressBar';
import CourseCard from '../components/CourseCard';
import { coursesData } from '../data/mockData';

export default function CourseDetailPage({
  course,
  user,
  onBack,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onShowToast,
}) {
  const [expandedModules, setExpandedModules] = useState([1]); // First module open by default
  const [activeTab, setActiveTab] = useState('syllabus'); // 'syllabus', 'overview', 'instructor', 'reviews'

  if (!course) {
    return (
      <div className="text-center py-20">
        <p className="text-slate-400">Course not found.</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 bg-indigo-600 rounded-xl text-white text-xs font-bold"
        >
          Return to Catalog
        </button>
      </div>
    );
  }

  const isEnrolled = user.enrolledCourses?.some((enc) => enc.courseId === course.id);
  const enrolledData = user.enrolledCourses?.find((enc) => enc.courseId === course.id);
  const isBookmarked = user.bookmarkedCourseIds?.includes(course.id);

  const toggleModule = (moduleNum) => {
    if (expandedModules.includes(moduleNum)) {
      setExpandedModules(expandedModules.filter((m) => m !== moduleNum));
    } else {
      setExpandedModules([...expandedModules, moduleNum]);
    }
  };

  const expandAllModules = () => {
    if (course.syllabus) {
      setExpandedModules(course.syllabus.map((m) => m.moduleNumber));
    }
  };

  const collapseAllModules = () => {
    setExpandedModules([]);
  };

  const matchScore = course.matchPercentage || course.baseRelevanceScore || 92;

  // Similar courses
  const similarCourses = coursesData
    .filter((c) => c.id !== course.id && (c.category === course.category || c.level === course.level))
    .slice(0, 3);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    onShowToast?.({
      type: 'info',
      title: 'Link Copied',
      message: 'Course link copied to your clipboard!',
    });
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Previous View</span>
      </button>

      {/* Course Hero Banner */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 overflow-hidden relative shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 sm:p-8 lg:p-10">
          {/* Left Info */}
          <div className="lg:col-span-7 space-y-5">
            {/* AI Recommendation Banner */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{matchScore}% AI Affinity for {user.targetRole}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-100 leading-tight">
              {course.title}
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              {course.description}
            </p>

            {/* Meta Tags Bar */}
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 pt-2 border-t border-slate-800/80">
              <div className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-4 h-4 fill-current" />
                <span>{course.rating.toFixed(2)}</span>
                <span className="text-slate-400 font-normal">
                  ({course.reviewCount.toLocaleString()} reviews)
                </span>
              </div>

              <div className="flex items-center gap-1 text-slate-300">
                <Users className="w-4 h-4 text-indigo-400" />
                <span>{course.enrolledCount.toLocaleString()} learners</span>
              </div>

              <div className="flex items-center gap-1 text-slate-300">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>{course.duration}</span>
              </div>

              <div className="flex items-center gap-1 text-slate-300">
                <BookOpen className="w-4 h-4 text-teal-400" />
                <span>{course.modulesCount} Modules</span>
              </div>
            </div>

            {/* Instructor Mini Badge */}
            <div className="flex items-center gap-3 pt-2">
              <img
                src={course.instructor.avatar}
                alt={course.instructor.name}
                className="w-10 h-10 rounded-xl object-cover border border-slate-700"
              />
              <div>
                <p className="text-xs font-bold text-slate-200">
                  Taught by {course.instructor.name}
                </p>
                <p className="text-[11px] text-slate-400">{course.instructor.role}</p>
              </div>
            </div>
          </div>

          {/* Right Video / Enrollment Card */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-800 border border-slate-700/80 group">
              <img
                src={course.thumbnail}
                alt={course.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <div className="w-14 h-14 rounded-full bg-indigo-600/90 text-white flex items-center justify-center shadow-xl shadow-indigo-600/40 group-hover:scale-110 transition-transform cursor-pointer">
                  <Play className="w-6 h-6 fill-current ml-1" />
                </div>
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-center">
                <span className="px-3 py-1 rounded-lg bg-slate-950/80 backdrop-blur-md text-[11px] font-semibold text-slate-200 border border-slate-800">
                  Preview Course Trailer (2:45)
                </span>
              </div>
            </div>

            {/* Enrollment / Progress Box */}
            <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
              {isEnrolled ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      Currently Enrolled
                    </span>
                    <span className="font-mono font-bold text-emerald-400">
                      {enrolledData?.progress || 0}% Complete
                    </span>
                  </div>
                  <ProgressBar
                    progress={enrolledData?.progress || 0}
                    variant="emerald"
                    size="md"
                    showPercentage={false}
                  />
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                    <p className="text-slate-400">Next Lesson Up:</p>
                    <p className="font-semibold text-indigo-300 truncate">
                      {enrolledData?.nextLesson || 'Lesson 1.1: Getting Started'}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      onShowToast?.({
                        type: 'success',
                        title: 'Resuming Course Player',
                        message: `Loaded ${enrolledData?.nextLesson || 'Next Lesson'} in workspace player.`,
                      });
                    }}
                    className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/25 transition-all flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Continue Lesson</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-400">Access Included</span>
                      <p className="text-lg font-extrabold text-slate-100">{course.price}</p>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                      Certificate Included
                    </span>
                  </div>

                  <button
                    onClick={() => onEnroll?.(course.id)}
                    className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-98"
                  >
                    <Zap className="w-4 h-4 text-amber-300" />
                    <span>Enroll Now & Start Learning</span>
                  </button>
                </div>
              )}

              {/* Utility actions */}
              <div className="flex items-center justify-between pt-1 text-xs text-slate-400">
                <button
                  onClick={() => onToggleBookmark?.(course.id)}
                  className="flex items-center gap-1.5 hover:text-white transition-colors"
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-indigo-500 text-indigo-500' : ''}`} />
                  <span>{isBookmarked ? 'Saved to Wishlist' : 'Save for Later'}</span>
                </button>
                <button
                  onClick={handleShare}
                  className="flex items-center gap-1.5 hover:text-white transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Share Course</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Recommendation Engine Deep Dive Box */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/30 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <BrainCircuit className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">
                Why the AI Recommends This Course for You
              </h3>
              <p className="text-xs text-slate-400">
                Neural vector alignment with {user.name}'s profile & target role ({user.targetRole})
              </p>
            </div>
          </div>
          <span className="font-mono text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            {matchScore}% Alignment
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs space-y-1">
            <div className="flex items-center gap-1.5 text-indigo-400 font-semibold">
              <Target className="w-3.5 h-3.5" />
              <span>Skill Gap Closure</span>
            </div>
            <p className="text-slate-300">
              Directly addresses your primary competency deficit in <strong>{course.skillsTaught[0]}</strong> (+24% target gain).
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Prerequisites Satisfied</span>
            </div>
            <p className="text-slate-300">
              You scored 94% on required foundational modules, ensuring 100% prerequisite readiness.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs space-y-1">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Cohort Affinity</span>
            </div>
            <p className="text-slate-300">
              88% of peers transitioning into {user.targetRole} rated this course as their most impactful milestone.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="border-b border-slate-800 flex gap-6 text-sm font-semibold">
        <button
          onClick={() => setActiveTab('syllabus')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'syllabus'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Curriculum & Syllabus ({course.modulesCount} Modules)</span>
        </button>

        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'overview'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>What You Will Learn</span>
        </button>

        <button
          onClick={() => setActiveTab('instructor')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'instructor'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Instructor</span>
        </button>

        <button
          onClick={() => setActiveTab('reviews')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'reviews'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Star className="w-4 h-4" />
          <span>Student Reviews ({course.reviews?.length || 2})</span>
        </button>
      </div>

      {/* Tab Content Panels */}
      {activeTab === 'syllabus' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>
              {course.syllabus?.length || 3} Detailed Modules • {course.lessonsCount || 42} Lessons & Hands-on Labs
            </span>
            <div className="flex items-center gap-3">
              <button
                onClick={expandAllModules}
                className="text-indigo-400 hover:text-indigo-300 font-semibold"
              >
                Expand All
              </button>
              <span>•</span>
              <button
                onClick={collapseAllModules}
                className="text-slate-400 hover:text-slate-200"
              >
                Collapse All
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {(course.syllabus || []).map((mod) => {
              const isOpen = expandedModules.includes(mod.moduleNumber);
              return (
                <div
                  key={mod.moduleNumber}
                  className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden transition-all"
                >
                  <button
                    onClick={() => toggleModule(mod.moduleNumber)}
                    className="w-full p-4 text-left flex items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-7 h-7 rounded-xl bg-slate-800 text-indigo-400 font-mono font-bold text-xs flex items-center justify-center border border-slate-700 flex-shrink-0">
                        {mod.moduleNumber}
                      </span>
                      <div className="min-w-0">
                        <p className="font-bold text-slate-100 text-sm truncate">{mod.title}</p>
                        <p className="text-xs text-slate-400">{mod.lessons.length} lessons • {mod.duration}</p>
                      </div>
                    </div>

                    <div className="text-slate-400 p-1">
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 pt-1 border-t border-slate-800/60 divide-y divide-slate-800/40">
                      {mod.lessons.map((lesson, idx) => (
                        <div
                          key={idx}
                          className="py-3 flex items-center justify-between gap-3 text-xs text-slate-300 hover:text-white"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {lesson.type === 'lab' && <FileCode className="w-4 h-4 text-teal-400 flex-shrink-0" />}
                            {lesson.type === 'video' && <Play className="w-4 h-4 text-indigo-400 flex-shrink-0" />}
                            {lesson.type === 'project' && <Award className="w-4 h-4 text-amber-400 flex-shrink-0" />}
                            {lesson.type === 'quiz' && <HelpCircle className="w-4 h-4 text-purple-400 flex-shrink-0" />}
                            <span className="truncate">{lesson.title}</span>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                              {lesson.type}
                            </span>
                            <span className="font-mono text-slate-500 text-[11px]">{lesson.duration}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Learning Outcomes */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h3 className="font-bold text-slate-100 text-base">Key Learning Outcomes</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(course.learningOutcomes || []).map((outcome, idx) => (
                <div key={idx} className="flex items-start gap-3 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{outcome}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Prerequisites */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <h3 className="font-bold text-slate-100 text-base">Prerequisites & Target Audience</h3>
            <ul className="list-disc list-inside space-y-1 text-xs text-slate-300">
              {(course.prerequisites || []).map((req, idx) => (
                <li key={idx}>{req}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {activeTab === 'instructor' && (
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row gap-6 items-start">
          <img
            src={course.instructor.avatar}
            alt={course.instructor.name}
            className="w-24 h-24 rounded-2xl object-cover border-2 border-indigo-500/40 flex-shrink-0"
          />
          <div className="space-y-3">
            <div>
              <h3 className="font-bold text-slate-100 text-lg">{course.instructor.name}</h3>
              <p className="text-xs text-indigo-400 font-semibold">{course.instructor.role}</p>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{course.instructor.bio}</p>
            <div className="flex flex-wrap gap-4 text-xs text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>{course.instructor.rating} Instructor Rating</span>
              </div>
              <div className="flex items-center gap-1 text-slate-300">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                <span>{course.instructor.students.toLocaleString()} Students Taught</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'reviews' && (
        <div className="space-y-4">
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="text-center sm:text-left">
              <p className="text-3xl font-extrabold text-slate-100 font-mono">
                {course.rating.toFixed(2)}
              </p>
              <div className="flex items-center justify-center sm:justify-start gap-1 text-amber-400 my-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <p className="text-xs text-slate-400">Based on {course.reviewCount.toLocaleString()} student reviews</p>
            </div>

            <div className="flex-1 max-w-sm space-y-1.5 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span>5 ★</span>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full w-[88%]" />
                </div>
                <span>88%</span>
              </div>
              <div className="flex items-center gap-2">
                <span>4 ★</span>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full w-[10%]" />
                </div>
                <span>10%</span>
              </div>
              <div className="flex items-center gap-2">
                <span>3 ★</span>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full w-[2%]" />
                </div>
                <span>2%</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {(course.reviews || []).map((rev, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={rev.avatar}
                      alt={rev.author}
                      className="w-7 h-7 rounded-full object-cover"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-200">{rev.author}</p>
                      <p className="text-[10px] text-slate-500">{rev.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center text-amber-400">
                    {Array.from({ length: rev.rating }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{rev.comment}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Similar / Related Courses */}
      <div className="pt-8 border-t border-slate-800/80 space-y-4">
        <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-400" />
          <span>Similar AI-Recommended Courses</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {similarCourses.map((sim) => (
            <CourseCard
              key={sim.id}
              course={sim}
              onSelectCourse={onSelectCourse}
              onToggleBookmark={onToggleBookmark}
              onEnroll={onEnroll}
              isBookmarked={user.bookmarkedCourseIds?.includes(sim.id)}
              isEnrolled={user.enrolledCourses?.some((enc) => enc.courseId === sim.id)}
              enrolledProgress={
                user.enrolledCourses?.find((enc) => enc.courseId === sim.id)?.progress || 0
              }
              showAiMatch={true}
              compact={true}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
