import React from 'react';
import {
  Sparkles,
  Clock,
  BookOpen,
  Star,
  Users,
  Bookmark,
  ArrowRight,
  CheckCircle2,
  TrendingUp,
  Award,
} from 'lucide-react';

export default function CourseCard({
  course,
  onSelectCourse,
  onToggleBookmark,
  onEnroll,
  onWhyThis,
  isBookmarked = false,
  isEnrolled = false,
  enrolledProgress = 0,
  showAiMatch = true,
  compact = false,
}) {
  const getLevelBadgeClass = (level) => {
    switch (level) {
      case 'Beginner':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'Intermediate':
        return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
      case 'Advanced':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  const matchScore = course.matchPercentage || 85;
  const isHighMatch = matchScore >= 90;

  return (
    <div className="group relative flex flex-col bg-slate-900/90 dark:bg-slate-900/90 rounded-2xl border border-slate-800 hover:border-indigo-500/50 transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-1 overflow-hidden">
      {/* Top Banner: AI Recommendation Score & Reason */}
      {showAiMatch && (
        <div className="relative bg-gradient-to-r from-indigo-950/80 via-slate-900 to-slate-950 px-4 py-2.5 border-b border-indigo-500/20 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="flex h-2 w-2 relative flex-shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <p className="text-xs font-medium text-slate-300 truncate" title={course.dynamicReason || course.recommendedReason}>
              {course.dynamicReason || course.recommendedReason || `AI Personalized Match for Your Path`}
            </p>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onWhyThis?.(course);
              }}
              className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 px-2 py-0.5 rounded-md bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 transition-colors flex items-center gap-1"
              title="Explainable AI Telemetry"
            >
              <span>Why this?</span>
            </button>
            <div
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold border ${
                isHighMatch
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
              }`}
            >
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>{matchScore}% Match</span>
            </div>
          </div>
        </div>
      )}

      {/* Course Thumbnail Image */}
      <div className="relative aspect-video w-full overflow-hidden bg-slate-800 cursor-pointer" onClick={() => onSelectCourse?.(course)}>
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-black/20" />

        {/* Category Badge & Duration Pill */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-950/80 backdrop-blur-md text-indigo-300 border border-slate-700/60">
            {course.category}
          </span>
        </div>

        {/* Bookmark Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleBookmark?.(course.id);
          }}
          className={`absolute top-3 right-3 p-2 rounded-xl backdrop-blur-md transition-all ${
            isBookmarked
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-950/70 text-slate-300 hover:text-white hover:bg-slate-900 border border-slate-700/60'
          }`}
          title={isBookmarked ? 'Remove Bookmark' : 'Bookmark Course'}
          aria-label="Bookmark"
        >
          <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
        </button>

        {/* Bottom overlay metadata */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-800 font-medium">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-800 font-medium">
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>{course.modulesCount} Modules</span>
          </div>
        </div>
      </div>

      {/* Course Body Content */}
      <div className="flex flex-col flex-1 p-5">
        {/* Level and Rating Header */}
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <span
            className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getLevelBadgeClass(
              course.level
            )}`}
          >
            {course.level}
          </span>

          <div className="flex items-center gap-1 text-xs">
            <div className="flex items-center text-amber-400 font-semibold">
              <Star className="w-3.5 h-3.5 fill-current mr-0.5" />
              <span>{course.rating.toFixed(2)}</span>
            </div>
            <span className="text-slate-500">({course.reviewCount.toLocaleString()})</span>
          </div>
        </div>

        {/* Title */}
        <h3
          onClick={() => onSelectCourse?.(course)}
          className="font-bold text-slate-100 text-base leading-snug group-hover:text-indigo-400 transition-colors line-clamp-2 cursor-pointer mb-2"
          title={course.title}
        >
          {course.title}
        </h3>

        {/* Description snippet */}
        {!compact && (
          <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
            {course.description}
          </p>
        )}

        {/* Skills Taught Chips */}
        <div className="flex flex-wrap gap-1.5 mb-4 mt-auto">
          {course.skillsTaught?.slice(0, 3).map((skill, idx) => (
            <span
              key={idx}
              className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800/80 text-slate-300 border border-slate-700/50"
            >
              {skill}
            </span>
          ))}
          {course.skillsTaught?.length > 3 && (
            <span className="text-[11px] px-1.5 py-0.5 rounded-md bg-slate-800/40 text-slate-400">
              +{course.skillsTaught.length - 3} more
            </span>
          )}
        </div>

        {/* Active Enrollment Progress or Footer Actions */}
        {isEnrolled ? (
          <div className="pt-3 border-t border-slate-800/80 mt-auto">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-slate-400 font-medium flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                In Progress
              </span>
              <span className="text-emerald-400 font-mono font-bold">{enrolledProgress}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden mb-3">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${enrolledProgress}%` }}
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onWhyThis?.(course);
                }}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold transition-all border border-indigo-500/20"
              >
                Why this?
              </button>
              <button
                onClick={() => onSelectCourse?.(course)}
                className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-indigo-600/20"
              >
                <span>Resume Learning</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3 mt-auto">
            <div className="flex items-center gap-2 min-w-0">
              <img
                src={course.instructor.avatar}
                alt={course.instructor.name}
                className="w-6 h-6 rounded-full object-cover border border-slate-700 flex-shrink-0"
              />
              <span className="text-xs text-slate-400 truncate">
                {course.instructor.name}
              </span>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onWhyThis?.(course);
                }}
                className="py-1.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold transition-all border border-indigo-500/20"
                title="View 6-Factor AI Explanation"
              >
                Why this?
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEnroll?.(course.id);
                }}
                className="py-1.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1 hover:scale-105 active:scale-95"
              >
                <span>Start Course</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
